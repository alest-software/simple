
const socket = io();

socket.on("connect", () => {
  console.log("connected...");
});

socket.on("disconnect", () => {
  console.log("disconnected...");
});

socket.on("$SYS/broker/uptime", (arg) => {
  //console.log(arg["uptime"]);
  $("#sys_broker_uptime").val(arg["uptime"]);
});

socket.on("inclination/loadavg/load1", (arg) => {
  //console.log(arg);
  $("#loadavg_load1").val(arg);
});

socket.on("inclination/loadavg/load5", (arg) => {
  //console.log(arg);
  $("#loadavg_load5").val(arg);
});

socket.on("inclination/loadavg/load15", (arg) => {
  //console.log(arg);
  $("#loadavg_load15").val(arg);
});

socket.on("inclination/price/okx/BTC-USD", (arg) => {
  //console.log(arg);
  $("#price_okx_btcusd").val(arg);
});

$(document).ready(function() {
    console.log("ready")
});

