
const socket = io();

socket.on("connect", () => {
  console.log("connected...");
});

socket.on("disconnect", () => {
  console.log("disconnected...");
});

socket.on("$SYS/broker/uptime", (arg) => {
  //console.log(arg["uptime"]);
  $("#sys_broker_uptime").val(arg["uptime"]);
});

socket.on("inclination/loadavg/load1", (arg) => {
  $("#loadavg_load1").val(parseFloat(arg * 100).toFixed(1));
});

socket.on("inclination/loadavg/load5", (arg) => {
  $("#loadavg_load5").val(parseFloat(arg * 100).toFixed(1));
});

socket.on("inclination/loadavg/load15", (arg) => {
  $("#loadavg_load15").val(parseFloat(arg * 100).toFixed(1));
});

socket.on("inclination/price/okx/BTC-USD", (arg) => {
  //console.log(arg);
  $("#price_okx_btcusd").val(arg);
});

socket.on("inclination/price/okx/ETH-USD", (arg) => {
  //console.log(arg);
  $("#price_okx_ethusd").val(arg);
});

socket.on("inclination/price/okx/ETH-BTC", (arg) => {
  //console.log(arg);
  $("#price_okx_ethbtc").val(arg);
});

socket.on("inclination/price/okx/SOL-USD", (arg) => {
  //console.log(arg);
  $("#price_okx_solusd").val(arg);
});

socket.on("inclination/price/okx/SOL-BTC", (arg) => {
  //console.log(arg);
  $("#price_okx_solbtc").val(arg);
});

socket.on("inclination/price/okx/SOL-ETH", (arg) => {
  //console.log(arg);
  $("#price_okx_soleth").val(arg);
});

$(document).ready(function() {
    console.log("ready")
});

