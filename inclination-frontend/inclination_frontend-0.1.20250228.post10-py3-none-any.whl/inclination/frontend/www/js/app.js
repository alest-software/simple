
/*
function onLoadavgMessage({loadavg}, pl) {
	pl = pl * 100;
	console.log('Loadavg...' + loadavg + ' ' + pl);
	var xxx = '#loadavg_' + loadavg;
	$(xxx).text(pl)
}
*/

const socket = io();

socket.on("connect", () => {
  console.log("connected...");
});

socket.on("disconnect", () => {
  console.log("disconnected...");
});

socket.on("echo", (arg) => {
  //console.log(arg["uptime"]);
  $("#loadavg_5m").text(arg["uptime"])
});

$(document).ready(function() {
    console.log("ready")
});

