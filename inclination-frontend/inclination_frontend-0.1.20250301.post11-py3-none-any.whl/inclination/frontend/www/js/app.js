
const socket = io();

socket.on("connect", () => {
  console.log("connected...");
});

socket.on("disconnect", () => {
  console.log("disconnected...");
});

socket.on("$SYS/broker/uptime", (arg) => {
  //console.log(arg["uptime"]);
  $("#sys_broker_uptime").val(arg["uptime"]);
});

socket.on("inclination/loadavg/load1m", (arg) => {
  //console.log(arg);
  $("#loadavg_load1m").val(arg);
});

socket.on("inclination/loadavg/load5m", (arg) => {
  //console.log(arg);
  $("#loadavg_load5m").val(arg);
});

socket.on("inclination/loadavg/load15m", (arg) => {
  //console.log(arg);
  $("#loadavg_load15m").val(arg);
});

$(document).ready(function() {
    console.log("ready")
});

