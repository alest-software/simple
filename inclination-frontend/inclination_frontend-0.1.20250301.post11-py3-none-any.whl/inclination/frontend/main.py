import re
import signal
import json
from functools import partial
import asyncio
from aiohttp import web, ClientSession, WSMsgType, WSCloseCode
import socketio
import pkgutil
from .mqtt import Client

sio = socketio.AsyncServer(async_mode='aiohttp', cors_allowed_origins='*')

@sio.event
async def connect(sid, environ, auth):
    print('socketio connect', sid)

@sio.event
async def disconnect(sid, reason):
    print('socketio disconnect', sid, reason)


#@web.middleware
#async def my_middleware(request, handler):
#    print(request.method, request.url)
#    response = await handler(request)
#    return response


class IndexEndpoint(web.View):
    async def get(self):
        #print('IndexEndpoint.get')
        data = pkgutil.get_data(__name__, 'www/index.html')
        return web.Response(text=data.decode('UTF-8'), content_type='text/html')
        #return web.FileResponse('www/index.html')
        #return web.Response(text=text, content_type='text/html')

class JsAppEndpoint(web.View):
    async def get(self):
        #print('JsAppEndpoint.get')
        data = pkgutil.get_data(__name__, 'www/js/app.js')
        return web.Response(text=data.decode('UTF-8'), content_type='application/javascript')
        #return web.FileResponse('www/js/app.js')


#class WsEndpoint(web.View):
#    async def get(self):
#        print('get')
#        ws = web.WebSocketResponse(heartbeat=5)
#        await ws.prepare(self.request)
#
#        self.request.app['websockets'].add(ws)
#
#        print('for')
#        try:
#            async for msg in ws:
#                if msg.type == WSMsgType.TEXT:
#                    await ws.send_str(msg.data / '/answer')
#                elif msg.type == WSMsgType.ERROR:
#                    print('excp')
#                else:
#                    print(msg.type)
#        finally:
#            print('remove')
#            self.request.app['websockets'].remove(ws)
#
#        print('closed')
#
#        return ws


class IndexApplication(web.Application):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.add_routes([
            web.view('/', IndexEndpoint),
            web.view('/js/app.js', JsAppEndpoint),
#            web.view('/ws', WsEndpoint),
            ])


async def on_startup(app):
    print('aiohttp startup')

async def on_shutdown(app):
    print('aiohttp shutdown')
#    for ws in app['websockets'].copy():
#        print('close-ws')
#        await ws.close(code=WSCloseCode.GOING_AWAY, message='Server shutdown')

async def on_cleanup(app):
    print('aiohttp cleanup')

async def on_sigint(runner, future, client):
    print('sigint')
    await runner.cleanup()
    await client.disconnect()
    future.set_result(0)

async def on_connect(client, userdata, flags, rc):
    print('mqtt connect')
    asyncio.gather(*[
        client.subscribe('$SYS/broker/uptime'),
        client.subscribe('inclination/loadavg/#')
        ])

async def on_loadavg_1m(client, userdata, msg, app):
    #print('msg', msg.payload)
    val = json.loads(msg.payload)
    await sio.emit('inclination/loadavg/load1m', val)

async def on_loadavg_5m(client, userdata, msg, app):
    #print('msg', msg.payload)
    val = json.loads(msg.payload)
    await sio.emit('inclination/loadavg/load5m', val)

async def on_loadavg_15m(client, userdata, msg, app):
    #print('msg', msg.payload)
    val = json.loads(msg.payload)
    await sio.emit('inclination/loadavg/load15m', val)

async def on_sys_broker_uptime(client, userdata, msg, app):
    #print('msg', msg.payload)
    r = re.compile(r'([0-9]*) seconds')
    m = r.match(msg.payload.decode('UTF-8'))
    uptime = int(m.group(1))
    await sio.emit('$SYS/broker/uptime', {'uptime': uptime})

async def main(host='0.0.0.0', port=8080):
    loop = asyncio.get_event_loop()

    client = Client()
    client.on_connect = on_connect
    client.loop = loop
    await client.connect('localhost', 1883, 60)

    future = loop.create_future()

    app = IndexApplication() #middlewares=[my_middleware])
    app.on_startup.append(on_startup)
    app.on_shutdown.append(on_shutdown)
    app.on_cleanup.append(on_cleanup)
#    app['websockets'] = set()

    sio.attach(app)

    client.message_callback_add('$SYS/broker/uptime', lambda a, b, c: on_sys_broker_uptime(a, b, c, app))
    client.message_callback_add('inclination/loadavg/load1', lambda a, b, c: on_loadavg_1m(a, b, c, app))
    client.message_callback_add('inclination/loadavg/load5', lambda a, b, c: on_loadavg_5m(a, b, c, app))
    client.message_callback_add('inclination/loadavg/load15', lambda a, b, c: on_loadavg_15m(a, b, c, app))

    runner = web.AppRunner(app)
    await runner.setup()

    loop.add_signal_handler(signal.SIGINT, lambda: asyncio.create_task(partial(on_sigint, runner=runner, future=future, client=client)()))

    site = web.TCPSite(runner, host=host, port=port)
    await site.start()

    await asyncio.gather(*[future, client.loop_forever()])


def cmd():
    asyncio.run(main())

if __name__ == '__main__':
    cmd()

