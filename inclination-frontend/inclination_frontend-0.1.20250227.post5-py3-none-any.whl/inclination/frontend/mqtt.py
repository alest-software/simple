import asyncio
import paho.mqtt.client as mqtt


class _OnConnectWrapper:
    def __init__(self, client):
        self._client = client

    async def _on_connect(self, userdata, flags, rc):
        if self._client.on_connect:
            try:
                await self._client.on_connect(self._client, userdata, flags, rc)
            except Exception as e:
                print(e)
        self._client._connected.set_result(rc)

    def __call__(self, client, userdata, flags, rc):
        task = self._client.loop.create_task(self._on_connect(userdata, flags, rc))


class _OnDisconnectWrapper:
    def __init__(self, client):
        self._client = client

    async def _on_disconnect(self, userdata, rc):
        if self._client.on_disconnect:
            try:
                await self._client.on_disconnect(self._client, userdata, rc)
            except Exception as e:
                print(e)
        if rc == 0:
            self._client._disconnected.set_result(rc)
            if (rc == mqtt.MQTT_ERR_SUCCESS) and (self._client._forever):
                self._client._forever.set_result(None)
        else:
            await asyncio.sleep(1)
            await self._client.reconnect()

    def __call__(self, client, userdata, rc):
        task = self._client.loop.create_task(self._on_disconnect(userdata, rc))


class _OnMessageWrapper:
    def __init__(self, client):
        self._client = client

    async def _on_message(self, userdata, msg):
        if self._client.on_message:
            try:
                await self._client.on_message(self._client, userdata, msg)
            except Exception as e:
                print(e)

    def __call__(self, client, userdata, msg):
        task = self._client.loop.create_task(self._on_message(userdata, msg))


class _OnMessageCallbackWrapper:
    def __init__(self, client, callback):
        self._client = client
        self._callback = callback

    async def _handle(self, userdata, msg):
        try:
            await self._callback(self._client, userdata, msg)
        except Exception as e:
            print(e)

    def __call__(self, client, userdata, msg):
        task = self._client.loop.create_task(self._handle(userdata, msg))


class _OnPublishWrapper:
    def __init__(self, client):
        self._client = client

    async def _on_publish(self, userdata, mid):
        if self._client.on_publish:
            try:
                await self._client.on_publish(self._client, userdata, mid)
            except Exception as e:
                print(e)
        self._client._publish_mids[mid].set_result(None)

    def __call__(self, client, userdata, mid):
        task = self._client.loop.create_task(self._on_publish(userdata, mid))


class _OnSubscribeWrapper:
    def __init__(self, client):
        self._client = client

    async def _on_subscribe(self, userdata, mid, granted_qos):
        if self._client.on_subscribe:
            try:
                await self._client.on_subscribe(self._client, userdata, mid, granted_qos)
            except Exception as e:
                print(e)
        self._client._subscribe_mids[mid].set_result(None)

    def __call__(self, client, userdata, mid, granted_qos):
        task = self._client.loop.create_task(self._on_subscribe(userdata, mid, granted_qos))


class _OnUnsubscribeWrapper:
    def __init__(self, client):
        self._client = client

    async def _on_unsubscribe(self, userdata, mid):
        if self._client.on_unsubscribe:
            try:
                await self._client.on_unsubscribe(self._client, userdata, mid)
            except Exception as e:
                print(e)
        self._client._unsubscribe_mids[mid].set_result(None)

    def __call__(self, client, userdata, mid):
        task = self._client.loop.create_task(self._on_unsubscribe(userdata, mid))


class _OnLogWrapper:
    def __init__(self, client):
        self._client = client

    async def _on_log(self, userdata, level, buf):
        if self._client.on_log:
            try:
                await self._client.on_log(self._client, userdata, level, buf)
            except Exception as e:
                print(e)

    def __call__(self, client, userdata, level, buf):
        task = self._client.loop.create_task(self._on_log(userdata, level, buf))


class _AsyncioHelper:
    def __init__(self, loop, client):
        self.loop = loop
        self.client = client
        self.client.on_socket_open = self.on_socket_open
        self.client.on_socket_close = self.on_socket_close
        self.client.on_socket_register_write = self.on_socket_register_write
        self.client.on_socket_unregister_write = self.on_socket_unregister_write

    def on_socket_open(self, client, userdata, sock):
        #print("Socket opened")

        def cb():
            #print("Socket is readable, calling loop_read")
            client.loop_read()

        self.loop.add_reader(sock, cb)
        self.misc = self.loop.create_task(self.misc_loop())

    def on_socket_close(self, client, userdata, sock):
        #print("Socket closed")
        self.loop.remove_reader(sock)
        self.misc.cancel()

    def on_socket_register_write(self, client, userdata, sock):
        #print("Watching socket for writability.")

        def cb():
            #print("Socket is writable, calling loop_write")
            client.loop_write()

        self.loop.add_writer(sock, cb)

    def on_socket_unregister_write(self, client, userdata, sock):
        #print("Stop watching socket for writability.")
        self.loop.remove_writer(sock)

    async def misc_loop(self):
        #print("misc_loop started")
        while self.client.loop_misc() == mqtt.MQTT_ERR_SUCCESS:
            try:
                await asyncio.sleep(1)
            except asyncio.CancelledError:
                break
        #print("misc_loop finished")


class Client:
    def __init__(self, *args, **kwargs):
        self._client = mqtt.Client(*args, **kwargs)
        self.on_connect = None
        self.on_disconnect = None
        self.on_message = None
        self.on_publish = None
        self.on_subscribe = None
        self.on_unsubscribe = None
        self.on_log = None
        self._message_callbacks = {}
        self._publish_mids = {}
        self._subscribe_mids = {}
        self._unsubscribe_mids = {}
        self._connected = None
        self._disconnected = None
        self._forever = None

        self._client.on_connect = _OnConnectWrapper(self)
        self._client.on_disconnect = _OnDisconnectWrapper(self)
        self._client.on_message = _OnMessageWrapper(self)
        self._client.on_publish = _OnPublishWrapper(self)
        self._client.on_subscribe = _OnSubscribeWrapper(self)
        self._client.on_unsubscribe = _OnUnsubscribeWrapper(self)
        self._client.on_log = _OnLogWrapper(self)

    @property
    def loop(self):
        return asyncio.get_running_loop()

    @loop.setter
    def loop(self, loop):
        self._aioh = _AsyncioHelper(loop, self._client)

    async def loop_forever(self):
        #loop = asyncio.get_running_loop()
        self._forever = self.loop.create_future()
        await self._forever

    def reinitialise(self):
        raise NotImplemented('reinitialise')

    def max_inflight_messages_set(self, *args, **kwargs):
        return self._client.max_inflight_messages_set(*args, **kwargs)

    def max_queued_messages_set(self, *args, **kwargs):
        return self._client.max_queued_messages_set(*args, **kwargs)

    def message_retry_set(self, *args, **kwargs):
        return self._client.message_retry_set(*args, **kwargs)

    def ws_set_options(self, *args, **kwargs):
        return self._client.ws_set_options(*args, **kwargs)

    def tls_set(self, *args, **kwargs):
        return self._client.tls_set(*args, **kwargs)

    def tls_set_context(self, *args, **kwargs):
        return self._client.tls_set_context(*args, **kwargs)

    def tls_insecure_set(self, *args, **kwargs):
        return self._client.tls_insecure_set(*args, **kwargs)

    def enable_logger(self, *args, **kwargs):
        return self._client.enable_logger(*args, **kwargs)

    def disable_logger(self, *args, **kwargs):
        return self._client.disable_logger(*args, **kwargs)

    def username_pw_set(self, *args, **kwargs):
        return self._client.username_pw_set(*args, **kwargs)

    def user_data_set(self, *args, **kwargs):
        return self._client.user_data_set(*args, **kwargs)

    def will_set(self, *args, **kwargs):
        return self._client.will_set(*args, **kwargs)

    def reconnect_delay_set(self, *args, **kwargs):
        return self._client.reconnect_delay_set(*args, **kwargs)

    async def connect(self, *args, **kwargs):
        rval = self._client.connect(*args, **kwargs)
        if rval == 0:
            self._connected = self.loop.create_future()
            try:
                await asyncio.wait_for(self._connected, timeout=None)
                rc = self._connected.result()
            except TimeoutError as e:
                rc = -1 #raise e
            finally:
                self._connected = None
        return rval, rc

    async def reconnect(self, *args, **kwargs):
        rval = self._client.reconnect(*args, **kwargs)
        if rval == 0:
            self._connected = self.loop.create_future()
            try:
                await asyncio.wait_for(self._connected, timeout=None)
                rc = self._connected.result()
            finally:
                self._connected = None
        return rval, rc

    async def disconnect(self, *args, **kwargs):
        rc = self._client.disconnect(*args, **kwargs)
        if rc != 0:
            raise Exception()
        else:
            self._disconnected = self.loop.create_future()
            await self._disconnected
            self._disconnected = None
        return 0

    async def publish(self, *args, **kwargs):
        rc, mid = self._client.publish(*args, **kwargs)
        if rc != 0:
            raise Exception('blub')
        else:
            if mid in self._publish_mids:
                raise Exception('blub')
            else:
                published = self.loop.create_future()
                self._publish_mids[mid] = published
                await asyncio.wait_for(published, timeout=None)
                rc = published.result()
                del self._publish_mids[mid]
        return rc

    async def subscribe(self, *args, **kwargs):
        rc, mid = self._client.subscribe(*args, **kwargs)
        if rc != 0:
            raise Exception(f"Cannot subscribe")
        else:
            if mid in self._subscribe_mids:
                raise Exception(f"Illegal message ID {mid}")
            else:
                subscribed = self.loop.create_future()
                self._subscribe_mids[mid] = subscribed
                await subscribed #await asyncio.wait_for(subscribed, timeout=None)
                rc = subscribed.result()
                del self._subscribe_mids[mid]
        return rc

    async def unsubscribe(self, *args, **kwargs):
        rc, mid = self._client.unsubscribe(*args, **kwargs)
        if rc != 0:
            raise Exception(f"Cannot unsubscribe")
        else:
            if mid in self._subscribe_mids:
                raise Exception(f"Illegal message ID {mid}")
            else:
                unsubscribed = self.loop.create_future()
                self._unsubscribe_mids[mid] = unsubscribed
                await unsubscribed #await asyncio.wait_for(subscribed, timeout=None)
                rc = unsubscribed.result()
                del self._unsubscribe_mids[mid]
        return rc

    def message_callback_add(self, sub, callback):
        cb = _OnMessageCallbackWrapper(self, callback)
        self._message_callbacks[sub] = cb
        return self._client.message_callback_add(sub, cb)

    def message_callback_remove(self, sub):
        rc = self._client.message_callback_remove(self._message_callbacks[sub])
        del self._message_callbacks[sub]
        return rc


def connack_string(rc):
    return mqtt.connack_string(rc)

def error_string(rc):
    return mqtt.error_string(rc)


def main():
    async def on_connect(client, userdata, flags, rc):
        print(f'on_connect (userdata={userdata}, flags={flags}, rc={rc}/"{connack_string(rc)}")')
        await asyncio.sleep(0.5)
        #client._connected.set_result(rc)
        #await asyncio.gather(*[
            #client.subscribe('$SYS/broker/uptime'),
            #client.subscribe('test/#')
            #])

    async def on_disconnect(client, userdata, rc):
        print(f'on_disconnect (userdata={userdata}, rc="{rc}")')
        await asyncio.sleep(0.5)
        #client._forever.set_result(rc)

    async def on_message(client, userdata, msg):
        print('on_message', msg.topic, str(msg.payload))
        await asyncio.sleep(0.5)

    async def on_sys_broker_uptime(client, userdata, msg):
        print('on_sys_broker_uptime', msg.topic, str(msg.payload))
        await client.publish('test/publish', 'ABC')

    async def on_test_publish(client, userdata, msg):
        print('on_test_publish', msg.topic, str(msg.payload))
        await asyncio.gather(*[
            client.publish('test/next', 'ABC'),
            client.unsubscribe('test/publish')
            ])

    async def on_test_next(client, userdata, msg):
        print('on_test_next', msg.topic, str(msg.payload))
        #await client.publish('test/next2', 'ABC')
        #print('~on_test_publish')
        await client.disconnect()

    async def on_publish(client, userdata, mid):
        print(f'on_publish (userdata={userdata}, mid={mid})')
        await asyncio.sleep(0.5)

    async def on_subscribe(client, userdata, mid, granted_qos):
        print(f'on_subscribe (userdata={userdata}, mid={mid}, granted_qos={granted_qos})')
        await asyncio.sleep(0.5)

    async def on_unsubscribe(client, userdata, mid):
        print('on_unsubscribe ({userdata}, {mid})')
        await asyncio.sleep(0.5)

    async def on_log(client, userdata, level, buf):
        print('==', userdata, level, buf)


    async def main():
        client = Client()
        client.on_connect = on_connect
        client.on_disconnect = on_disconnect
        client.on_message = on_message
        client.on_publish = on_publish
        client.on_subscribe = on_subscribe
        client.on_unsubscribe = on_unsubscribe
        #client.on_log = on_log

        client.message_callback_add('$SYS/broker/uptime', on_sys_broker_uptime)
        client.message_callback_add('test/publish', on_test_publish)
        client.message_callback_add('test/next', on_test_next)

        #aioh = _AsyncioHelper(asyncio.get_running_loop(), client._client)
        client.loop = asyncio.get_running_loop()

        print('----------------------------------------')
        rval = await client.connect('localhost', 1883, 60)
        print('Connected...', rval)
        print('----------------------------------------')
        rc = await client.subscribe('$SYS/broker/uptime')
        print('Subscribed...', rc)
        print('----------------------------------------')
        rc = await asyncio.gather(*[
            client.subscribe('test/next'),
            client.subscribe('test/publish'),
            ])
        print('Subscribed...', rc)
        print('----------------------------------------')

        await client.loop_forever()


    asyncio.run(main())

if __name__ == '__main__':
    main()

