import signal
import json
from functools import partial
import asyncio
from aiohttp import web, ClientSession, WSMsgType, WSCloseCode
try:
    from .mqtt import Client
except ImportError:
    from mqtt import Client
import socketio

sio = socketio.AsyncServer(async_mode='aiohttp')


#@web.middleware
#async def my_middleware(request, handler):
#    print(request.method, request.url)
#    response = await handler(request)
#    return response


text = '''<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script>

function main() {
    let ws = new WebSocket("wss://inclination.de-wit.name/ws")
    //let ws = new WebSocket("ws://localhost/ws")

    ws.onopen = function(event) {
        console.log("type: " + event.type)
        console.log("timeStamp: " + event.timeStamp)
        $('#connection').text("open")
    }

    ws.onmessage = function(event) {
        console.log("type: " + event.type)
        console.log("timeStamp: " + event.timeStamp)
        console.log("data: " + event.data)
        //console.log(event.origin)
        //console.log(event.lastEventId)
        //console.log(event.source)
        //console.log(event.ports)

        msg = JSON.parse(event.data)
        $('#message').text(msg['loadavg-1m'])
    }

    ws.onclose = function(event) {
        console.log("type: " + event.type)
        console.log("timeStamp: " + event.timeStamp)
        console.log("code: " + event.code)
        console.log("reason: " + event.reason)
        console.log("wasClean: " + event.wasClean)

        $('#connection').text(event.reason)
    }

    ws.onerror = function(event) {
        $('#error').text(event)
    }
}

</script>
</head>
<body onload="main()">
  <div>
    <div id='connection'>-</div>
    <div id='error'>-</div>
    <div id='message'>-</div>
    <div class="progress">
      <div class="progress-bar" role="progress-bar" area-valuenow="70" area-valuemin="0" area-valuemax="100" style="width:70%">
        <span class="sr-only">70% Complete</span>
    </div>
  </div>
</body>
</html>'''

import pkgutil

class IndexEndpoint(web.View):
    async def get(self):
        data = pkgutil.get_data(__name__, 'www/index.html')
        return web.Response(text=data.decode('UTF-8'), content_type='text/html')
        #return web.FileResponse('www/index.html')
        #return web.Response(text=text, content_type='text/html')

class JsAppEndpoint(web.View):
    async def get(self):
        data = pkgutil.get_data(__name__, 'www/js/app.js')
        return web.Response(text=data.decode('UTF-8'), content_type='application/javascript')
        #return web.FileResponse('www/js/app.js')


#class WsEndpoint(web.View):
#    async def get(self):
#        print('get')
#        ws = web.WebSocketResponse(heartbeat=5)
#        await ws.prepare(self.request)
#
#        self.request.app['websockets'].add(ws)
#
#        print('for')
#        try:
#            async for msg in ws:
#                if msg.type == WSMsgType.TEXT:
#                    await ws.send_str(msg.data / '/answer')
#                elif msg.type == WSMsgType.ERROR:
#                    print('excp')
#                else:
#                    print(msg.type)
#        finally:
#            print('remove')
#            self.request.app['websockets'].remove(ws)
#
#        print('closed')
#
#        return ws


class IndexApplication(web.Application):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.add_routes([
            web.view('/', IndexEndpoint),
            web.view('/js/app.js', IndexEndpoint),
#            web.view('/ws', WsEndpoint),
            ])


async def on_startup(app):
    print('startup')

async def on_shutdown(app):
    print('shutdown')
#    for ws in app['websockets'].copy():
#        print('close-ws')
#        await ws.close(code=WSCloseCode.GOING_AWAY, message='Server shutdown')

async def on_cleanup(app):
    print('cleanup')

async def on_sigint(runner, future, client):
    print('sigint')
    await runner.cleanup()
    await client.disconnect()
    future.set_result(0)

async def on_connect(client, userdata, flags, rc):
    print('connect')
#    asyncio.gather(*[
#        client.subscribe('inclination/loadavg/1m')
#        ])

#async def on_loadavg_1m(client, userdata, msg, app):
#    print('msg', msg.payload)
#    message = {
#            'loadavg-1m': json.loads(msg.payload)
#            }
#    for ws in app['websockets'].copy():
#        await ws.send_json(message)

async def main(host='localhost', port=8002):
    loop = asyncio.get_event_loop()

    client = Client()
    client.on_connect = on_connect
    client.loop = loop
    await client.connect('localhost', 1883, 60)

    future = loop.create_future()

    app = IndexApplication() #middlewares=[my_middleware])
    app.on_startup.append(on_startup)
    app.on_shutdown.append(on_shutdown)
    app.on_cleanup.append(on_cleanup)
#    app['websockets'] = set()

#    client.message_callback_add('inclination/loadavg/1m', lambda a, b, c: on_loadavg_1m(a, b, c, app))

    runner = web.AppRunner(app)
    await runner.setup()

    loop.add_signal_handler(signal.SIGINT, lambda: asyncio.create_task(partial(on_sigint, runner=runner, future=future, client=client)()))

    site = web.TCPSite(runner, host=host, port=port)
    await site.start()

    await asyncio.gather(*[future, client.loop_forever()])


def cmd():
    asyncio.run(main())

if __name__ == '__main__':
    cmd()

