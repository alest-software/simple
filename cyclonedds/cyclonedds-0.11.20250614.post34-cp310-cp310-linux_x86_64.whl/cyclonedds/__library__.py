in_wheel = False
library_path = r'/opt/inclination/lib/libddsc.so'
