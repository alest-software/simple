in_wheel = False
library_path = r'/opt/cyclonedds/lib/libddsc.so'
