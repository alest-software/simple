import argparse
import logging
import asyncio
import signal
import json
import telegram
from functools import partial
from telegram import Update
from telegram.ext import ApplicationBuilder, ContextTypes, CommandHandler, MessageHandler, filters
try:
    import mqtt
except Exception as e:
    print(e)
    from . import mqtt


logging.basicConfig(
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        level=logging.INFO
)


class Main:
    def __init__(self):
        self._users = set()
        self._chats = set()

    async def on_sigint(self, future1, future2):
        print('SIGINT')
        future1.set_result(0)
        future2.set_result(0)

    async def on_connect(self, client, userdata, flags, rc):
        print('on_connect', rc)
        await self._mqtt.subscribe('inclination/config/telegram/0/api_token')
        await self._mqtt.subscribe('inclination/config/telegram/0/port')
        await self._mqtt.subscribe('inclination/config/telegram/0/url_path')
        await self._mqtt.subscribe('inclination/config/telegram/0/webhook_url')
        await self._mqtt.subscribe('inclination/config/telegram/0/users/+')
        await self._mqtt.subscribe('inclination/telegram/chats/+')
        await self._mqtt.subscribe('inclination/telegram/message')

    async def on_disconnect(self, client, userdata, rc):
        print('on_disconnect', rc)

    async def on_conf_api_token(self, topic, payload, qos, retain):
        #print(topic, payload, qos, retain)
        self._config_token.set_result(payload)

    async def on_conf_port(self, topic, payload, qos, retain):
        self._config_port.set_result(payload)

    async def on_conf_url_path(self, topic, payload, qos, retain):
        self._config_url_path.set_result(payload)

    async def on_conf_webhook_url(self, topic, payload, qos, retain):
        self._config_webhook_url.set_result(payload)

    async def on_conf_users(self, topic, payload, qos, retain):
        #print(topic, payload, qos, retain)
        user = topic.split('/')[5]
        if payload:
            self._users.add(user)
        else:
            self._users.discard(user)

    async def on_message(self, topic, payload, qos, retain):
        #print(topic, payload, qos, retain)
        for chat in self._chats:
            await self._bot.bot.send_message(chat_id=chat, text=payload)

    async def on_chats(self, topic, payload, qos, retain):
        #print(topic, payload, qos, retain)
        chat_id = topic.split('/')[3]
        if payload:
            self._chats.add(chat_id)
        else:
            self._chats.discard(chat_id)

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.message.chat.username in self._users:
            await self._mqtt.publish(f'inclination/telegram/chats/{update.effective_chat.id}', 'true', retain=True)
            await context.bot.send_message(chat_id=update.effective_chat.id, text='Welcome!')
        else:
            await context.bot.send_message(chat_id=update.effective_chat.id, text='Not registered')

    async def stop(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.message.chat.username in self._users:
            await self._mqtt.publish(f'inclination/telegram/chats/{update.effective_chat.id}', None, retain=True)
            await context.bot.send_message(chat_id=update.effective_chat.id, text='Silenced..')
        else:
            await context.bot.send_message(chat_id=update.effective_chat.id, text='Not registered')

    async def echo(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        print(update)
        await context.bot.send_message(chat_id=update.effective_chat.id, text=update.message.text)

    async def bot_runner(self, telegram_done, **kwargs):
        print('Telegram running...')

        await self._config_token
        token = self._config_token.result()

        self._bot = ApplicationBuilder().token(token).build()

        start_handler = CommandHandler('start', self.start)
        stop_handler = CommandHandler('stop', self.stop)
        echo_handler = MessageHandler(filters.TEXT & (~filters.COMMAND), self.echo)
        self._bot.add_handler(start_handler)
        self._bot.add_handler(stop_handler)
        self._bot.add_handler(echo_handler)

        await self._config_port
        telegram_port = self._config_port.result()
        await self._config_url_path
        telegram_url_path = self._config_url_path.result()
        await self._config_webhook_url
        telegram_webhook_url = self._config_webhook_url.result()

        await self._bot.initialize()
        await self._bot.updater.start_webhook(port=telegram_port, url_path=telegram_url_path, webhook_url=telegram_webhook_url)
        await self._bot.start()

        await telegram_done

        await self._bot.updater.stop()
        await self._bot.stop()
        await self._bot.shutdown()

        print('Telegram done.')

    async def mqtt_runner(self, mqtt_done, mqtt_host, **kwargs):
        def _(client, userdata, msg, handler):
            payload = json.loads(msg.payload) if msg.payload else None
            return handler(msg.topic, payload, msg.qos, msg.retain)

        print('MQTT running...')

        loop = asyncio.get_running_loop()

        self._mqtt = mqtt.Client()
        self._mqtt.on_connect = self.on_connect
        self._mqtt.on_disconnect = self.on_disconnect
        self._mqtt.message_callback_add('inclination/config/telegram/0/api_token', lambda c, u, m: _(c, u, m, self.on_conf_api_token))
        self._mqtt.message_callback_add('inclination/config/telegram/0/port', lambda c, u, m: _(c, u, m, self.on_conf_port))
        self._mqtt.message_callback_add('inclination/config/telegram/0/url_path', lambda c, u, m: _(c, u, m, self.on_conf_url_path))
        self._mqtt.message_callback_add('inclination/config/telegram/0/webhook_url', lambda c, u, m: _(c, u, m, self.on_conf_webhook_url))
        self._mqtt.message_callback_add('inclination/config/telegram/0/users/+', lambda c, u, m: _(c, u, m, self.on_conf_users))
        self._mqtt.message_callback_add('inclination/telegram/chats/+', lambda c, u, m: _(c, u, m, self.on_chats))
        self._mqtt.message_callback_add('inclination/telegram/message', lambda c, u, m: _(c, u, m, self.on_message))

        self._mqtt.loop = loop
        await self._mqtt.connect(mqtt_host)

        await mqtt_done

        await self._mqtt.disconnect()

        print('MQTT done.')

    async def __call__(self, **kwargs):
        loop = asyncio.get_running_loop()

        self._mqtt_done = loop.create_future()
        self._telegram_done = loop.create_future()
        self._config_token = loop.create_future()
        self._config_port = loop.create_future()
        self._config_url_path = loop.create_future()
        self._config_webhook_url = loop.create_future()

        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(self.on_sigint, self._mqtt_done, self._telegram_done)()))

        self._task1 = asyncio.get_running_loop().create_task(self.bot_runner(self._telegram_done, **kwargs))
        self._task2 = asyncio.get_running_loop().create_task(self.mqtt_runner(self._mqtt_done, **kwargs))

        await self._task2
        await self._task1
        await asyncio.sleep(1)
        print('Done.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mqtt-host', default='localhost')
    args = parser.parse_args()
    
    asyncio.run(Main()(**vars(args)))


if __name__ == '__main__':
    main()

