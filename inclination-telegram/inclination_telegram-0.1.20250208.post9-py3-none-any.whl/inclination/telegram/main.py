import argparse
import os
import logging
import asyncio
import signal
import json
from pathlib import Path
import tomllib
import telegram
from functools import partial
from telegram import Update
from telegram.ext import ApplicationBuilder, ContextTypes, CommandHandler, MessageHandler, filters
from pprint import pprint
from attrs import define, field
from . import mqtt


logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
#ch.setLevel(logging.INFO)
#formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
#formatter = logging.Formatter('%(asctime)-23s - %(levelname)-8s - %(message)s')
formatter = logging.Formatter('%(asctime)-23s - %(levelname).1s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)


@define(kw_only=True)
class BotRunner:
    main:          int
    name:          str
    bot:           int = None
    chats:         set = field(factory=set)
    telegram_done: asyncio.Future = field(factory=lambda: asyncio.get_running_loop().create_future())
    port:          asyncio.Future = field(factory=lambda: asyncio.get_running_loop().create_future())
    webhook_url:   asyncio.Future = field(factory=lambda: asyncio.get_running_loop().create_future())
    url_path:      asyncio.Future = field(factory=lambda: asyncio.get_running_loop().create_future())
    token:         asyncio.Future = field(factory=lambda: asyncio.get_running_loop().create_future())

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        #print(update, context)
        logger.info(f'{update}, {context}')
        try:
            await self.main.start(self.name, update.message.chat.username, update.effective_chat.id)
            await context.bot.send_message(chat_id=update.effective_chat.id, text='Welcome!')
        except Exception as e:
            await context.bot.send_message(chat_id=update.effective_chat.id, text='Not registered')

    async def stop(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        #print(update, context)
        logger.info(f'{update}, {context}')
        try:
            await self.main.stop(self.name, update.message.chat.username, update.effective_chat.id)
            await context.bot.send_message(chat_id=update.effective_chat.id, text='Silenced..')
        except Exception as e:
            await context.bot.send_message(chat_id=update.effective_chat.id, text='Not registered')

    #async def echo(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
    #    print(update)
    #    logger.info(f'{update}, {context}')
    #    await context.bot.send_message(chat_id=update.effective_chat.id, text=update.message.text)

    async def send_message(self, topic, payload, qos, retain):
        #print(topic, payload, qos, retain)
        logger.info(f'{topic}, {payload}')
        for chat in self.chats:
            await self.bot.bot.send_message(chat_id=chat, text=payload)

    async def __call__(self, loop, **kwargs):
        logger.info('Telegram running...')

        self.telegram_done = loop.create_future()

        await self.token
        token = self.token.result()

        self.bot = ApplicationBuilder().token(token).build()

        start_handler = CommandHandler('start', self.start)
        stop_handler = CommandHandler('stop', self.stop)
        #echo_handler = MessageHandler(filters.TEXT & (~filters.COMMAND), self.echo)
        self.bot.add_handler(start_handler)
        self.bot.add_handler(stop_handler)
        #self.bot.add_handler(echo_handler)

        await self.port
        telegram_port = self.port.result()
        logger.info(f'Port set to {telegram_port}')

        await self.url_path
        telegram_url_path = self.url_path.result()
        logger.info(f'URL path set to "{telegram_url_path}"')

        await self.webhook_url
        telegram_webhook_url = self.webhook_url.result()
        logger.info(f'Webhook URL path set to "{telegram_webhook_url}"')

        logger.info(f'Initializing telegram bot...')
        await self.bot.initialize()

        logger.info(f'Staring webhook...')
        await self.bot.updater.start_webhook(listen='0.0.0.0', port=telegram_port, url_path=telegram_url_path, webhook_url=telegram_webhook_url)

        logger.info(f'Starting bot...')
        await self.bot.start()

        web_info = await self.bot.bot.get_webhook_info()
        print(web_info)

        for chat in self.chats:
            await self.bot.bot.send_message(chat_id=chat, text='Starting process...')

        await self.telegram_done

        for chat in self.chats:
            await self.bot.bot.send_message(chat_id=chat, text='Stopping process...')

        logger.info(f'Stopping webhook...')
        await self.bot.updater.stop()

        logger.info(f'Stopping bot...')
        await self.bot.stop()

        logger.info(f'Shutting down bot...')
        await self.bot.shutdown()

        logger.info('Telegram done.')


@define(kw_only=True)
class Main:
    users:      set = field(factory=set)
    mqtt_done:  asyncio.Future = None #field(factory=lambda: asyncio.get_running_loop().create_future())
    bot_runner: BotRunner = None
    mqtt:       int = None

    async def on_sigint(self, future1, future2):
        print('SIGINT')
        future1.set_result(0)
        self.bot_runner.telegram_done.set_result(0)
        #future2.set_result(0)

    async def on_connect(self, client, userdata, flags, rc):
        print('on_connect', rc)
        await self.mqtt.subscribe('inclination/config/telegram/0/api_token')
        await self.mqtt.subscribe('inclination/config/telegram/0/port')
        await self.mqtt.subscribe('inclination/config/telegram/0/url_path')
        await self.mqtt.subscribe('inclination/config/telegram/0/webhook_url')
        await self.mqtt.subscribe('inclination/config/telegram/0/users/+')
        await self.mqtt.subscribe('inclination/telegram/chats/+')
        await self.mqtt.subscribe('inclination/telegram/message')

    async def on_disconnect(self, client, userdata, rc):
        print('on_disconnect', rc)

    async def on_conf_api_token(self, topic, payload, qos, retain):
        #print(topic, payload, qos, retain)
        logger.info(f'{topic}, {payload}')
        self.bot_runner.token.set_result(payload)

    async def on_conf_port(self, topic, payload, qos, retain):
        logger.info(f'{topic}, {payload}')

        self.bot_runner.port.set_result(payload)

    async def on_conf_url_path(self, topic, payload, qos, retain):
        logger.info(f'{topic}, {payload}')

        self.bot_runner.url_path.set_result(payload)

    async def on_conf_webhook_url(self, topic, payload, qos, retain):
        logger.info(f'{topic}, {payload}')

        self.bot_runner.webhook_url.set_result(payload)

    async def on_conf_users(self, topic, payload, qos, retain):
        logger.info(f'{topic}, {payload}')

        user = topic.split('/')[5]
        if payload:
            self.users.add(user)
        else:
            self.users.discard(user)

    async def on_message(self, topic, payload, qos, retain):
        logger.info(f'{topic}, {payload}')

        await self.bot_runner.send_message(topic, payload, qos, retain)

    async def on_chats(self, topic, payload, qos, retain):
        logger.info(f'{topic}, {payload}')

        chat_id = topic.split('/')[3]
        if payload:
            self.bot_runner.chats.add(chat_id)
        else:
            self.bot_runner.chats.discard(chat_id)

    async def start(self, botname, username, userid):
        if username in self.users:
            await self.mqtt.publish(f'inclination/telegram/chats/{userid}', 'true', retain=True)
        else:
            raise Exception('Not authorized')

    async def stop(self, botname, username, userid):
        if username in self.users:
            await self.mqtt.publish(f'inclination/telegram/chats/{userid}', None, retain=True)
        else:
            raise Exception('Not authorized')

    async def mqtt_runner(self, mqtt_done, mqtt_host, **kwargs):
        def _(client, userdata, msg, handler):
            payload = json.loads(msg.payload) if msg.payload else None
            return handler(msg.topic, payload, msg.qos, msg.retain)

        logger.info('MQTT running...')

        loop = asyncio.get_running_loop()

        self.mqtt = mqtt.Client()
        self.mqtt.on_connect = self.on_connect
        self.mqtt.on_disconnect = self.on_disconnect
        self.mqtt.message_callback_add('inclination/config/telegram/0/api_token', lambda c, u, m: _(c, u, m, self.on_conf_api_token))
        self.mqtt.message_callback_add('inclination/config/telegram/0/port', lambda c, u, m: _(c, u, m, self.on_conf_port))
        self.mqtt.message_callback_add('inclination/config/telegram/0/url_path', lambda c, u, m: _(c, u, m, self.on_conf_url_path))
        self.mqtt.message_callback_add('inclination/config/telegram/0/webhook_url', lambda c, u, m: _(c, u, m, self.on_conf_webhook_url))
        self.mqtt.message_callback_add('inclination/config/telegram/0/users/+', lambda c, u, m: _(c, u, m, self.on_conf_users))
        self.mqtt.message_callback_add('inclination/telegram/chats/+', lambda c, u, m: _(c, u, m, self.on_chats))
        self.mqtt.message_callback_add('inclination/telegram/message', lambda c, u, m: _(c, u, m, self.on_message))

        self.mqtt.loop = loop
        await self.mqtt.connect(mqtt_host)

        await mqtt_done

        await self.mqtt.disconnect()

        logger.info('MQTT done.')

    async def __call__(self, **kwargs):
        loop = asyncio.get_running_loop()

        self.mqtt_done = loop.create_future()

        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(self.on_sigint, self.mqtt_done, None)()))

        self.bot_runner = BotRunner(main=self, name='inclination-test-bot')

        task1 = loop.create_task(self.bot_runner(loop, **kwargs))
        task2 = loop.create_task(self.mqtt_runner(self.mqtt_done, **kwargs))

        await task2
        await task1
        await asyncio.sleep(1)

        logger.info('Done.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-H', '--mqtt-host',   default=os.environ.get('MQTT_HOST', 'localhost'))
    parser.add_argument('-p', '--mqtt-port',   default=os.environ.get('MQTT_PORT', 1883), type=int)
    parser.add_argument('-u', '--mqtt-user',   default=os.environ.get('MQTT_USER', None))
    parser.add_argument('-P', '--mqtt-passwd', default=os.environ.get('MQTT_PASSWD', None))
    parser.add_argument('-f', '--file',        default=str(Path.home() / '.inclination' / 'telegram.toml'))
    args = parser.parse_args()
    
    #with open(args.file, 'rb') as f:
    #    config = tomllib.load(f)
    #    pprint(config)

    asyncio.run(Main()(**vars(args)))


if __name__ == '__main__':
    main()

