import os
import re
import time
from datetime import datetime, timezone
import signal
import json
import sqlite3
import logging
from functools import partial
from argparse import ArgumentParser
import asyncio
#import async_timer
from pprint import pprint
from . import mqtt


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.DEBUG)


class Main:
    def __init__(self):
        con = sqlite3.connect(':memory:')
        cur = con.cursor()
        cur.execute('CREATE TABLE value (id, base, quote, timeframe, value)')
        self._series = {}
        self._series[('btc', 'usdt', '1m')] = {'con': con, 'cur': cur}

    async def on_mqtt_connect(self, client, userdata, flags, rc):
        logger.debug('mqtt connected')
        await self._mqtt.subscribe('inclination/kline/+/+/+/+/close')

    async def on_mqtt_disconnect(self, client, userdata, rc):
        logger.debug('mqtt disconnected')

    async def on_conf_timeout(self, payload, *, base, quote, timeframe, timestamp):
        sample = int(timestamp) // 60
        logger.debug(f'close @ {base} {quote} {timeframe} {sample} {payload}')

        s = (base, quote, timeframe)
        if s in self._series:
            con = self._series[s]['con']
            cur = self._series[s]['cur']

            data = {'id': sample, 'base': base, 'quote': quote, 'timeframe': timeframe, 'value': payload}
            cur.execute('INSERT INTO value VALUES (:id, :base, :quote, :timeframe, :value)', data)
            con.commit()

            #data = {'base': base, 'quote': quote, 'timeframe': timeframe, 'value': payload}
            for row in cur.execute('SELECT * FROM value WHERE base = :base AND quote = :quote', data):
                pprint(row)
            print()

            t = int(datetime.now().timestamp()) // 60
            expiry = {'t': t}
            cur.execute('DELETE FROM value WHERE id < :t - 10 AND base = :base AND quote = :quote', {**expiry, **data})
            con.commit()

    async def mqtt_runner(self, *, mqtt_done, mqtt_host, mqtt_port, mqtt_user, mqtt_passwd):
        class _:
            def __init__(self, handler, regex=None, do_qos=False, do_retain=False):
                self._handler = handler
                self._regex = re.compile(regex) if regex else None
                self._do_qos = do_qos
                self._do_retain = do_retain
            async def __call__(self, client, userdata, msg):
                params = {}
                if self._do_qos:
                    params['qos'] = msg.qos
                if self._do_retain:
                    params['retain'] = msg.retain
                instance = self._regex.match(msg.topic).groupdict() if self._regex else {'topic': msg.topic}
                payload = json.loads(msg.payload) if msg.payload else None
                await self._handler(payload, **params, **instance)

        logger.debug('mqtt started')
        self._mqtt = mqtt.Client()
        self._mqtt.username_pw_set(username=mqtt_user, password=mqtt_passwd)
        self._mqtt.on_connect = self.on_mqtt_connect
        self._mqtt.on_disconnect = self.on_mqtt_disconnect
        self._mqtt.message_callback_add('inclination/kline/+/+/+/+/close',
                _(self.on_conf_timeout, r'inclination/kline/(?P<base>[^/]+)/(?P<quote>[^/]+)/(?P<timeframe>[^/]+)/(?P<timestamp>[^/]+)/close'))
        loop = asyncio.get_running_loop()
        self._mqtt.loop = loop
        await self._mqtt.connect(host=mqtt_host, port=mqtt_port)
        await mqtt_done
        await self._mqtt.disconnect()
        logger.debug('mqtt done')

    async def on_sigint(self):
        logger.debug('sigint')
        self._mqtt_done.set_result(0)

    async def __call__(self, *, mqtt_host=None, mqtt_port=None, mqtt_user=None, mqtt_passwd=None):
        loop = asyncio.get_running_loop()
        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(self.on_sigint)()))

        self._mqtt_done = loop.create_future()

        t0 = asyncio.create_task(self.mqtt_runner(mqtt_done=self._mqtt_done, mqtt_host=mqtt_host, mqtt_port=mqtt_port,
                                                  mqtt_user=mqtt_user, mqtt_passwd=mqtt_passwd))

        await asyncio.gather(t0)


def main():
    parser = ArgumentParser()
    parser.add_argument('-H', '--mqtt-host', default=os.environ.get('MQTT_HOST', 'localhost'))
    parser.add_argument('-p', '--mqtt-port', type=int, default=os.environ.get('MQTT_PORT', 1883))
    parser.add_argument('-u', '--mqtt-user', default=os.environ.get('MQTT_USER', None))
    parser.add_argument('-P', '--mqtt-passwd', default=os.environ.get('MQTT_PASSWD', None))
    args = parser.parse_args()

    x = Main()
    asyncio.run(x(**vars(args)))

