import asyncio
import signal
import sys
from pathlib import Path

import fastdds
import numpy as np
import pandas as pd
import tomli

from inclination.idl_ex.ohlcv import Series, SeriesPubSubType
from inclination.series.listeners import SeriesListener


_INTERVAL_MAP = {
    "m": 60, "h": 3600, "d": 86400, "w": 604800, "M": 2592000,
}

def _interval_to_seconds(interval_id: str) -> int:
    num = int(interval_id[:-1])
    unit = interval_id[-1]
    return num * _INTERVAL_MAP[unit]


_fuzzy_and = lambda xs: np.prod(xs, axis=1)


def handle_series(data: Series, topic_name: str, fft_len: int = 16, top_start: int = 1, top_end: int | None = None):
    values = list(reversed(data.data()))[-64:]
    interval = _interval_to_seconds(data.interval_id())
    end_ts = data.timestamp()
    n = len(values)
    start_ts = end_ts - (n - 1) * interval
    timestamps = [start_ts + i * interval for i in range(n)]
    df = pd.DataFrame({"value": values}, index=pd.to_datetime(timestamps, unit="s"))
    arr = np.array(values)
    n_half = fft_len // 2
    selected = list(range(top_start, (top_end if top_end is not None else n_half - 1) + 1))
    fft_cols = np.full((n, fft_len), np.nan, dtype=complex)
    for i in range(fft_len - 1, n):
        segment = arr[i - (fft_len - 1):i + 1].copy().astype(float)
        segment -= segment.mean()
        coeffs = np.polyfit(np.arange(fft_len), segment, 1)
        segment -= np.polyval(coeffs, np.arange(fft_len))
        segment *= np.hanning(fft_len)
        fft_cols[i] = np.fft.fft(segment)
    for j in selected:
        col = fft_cols[:, j]
        angle = np.angle(col)
        cos = np.cos(angle)
        df[f"cos_{j}"] = cos
        df[f"top_{j}"] = (1 + cos) / 2
        df[f"bottom_{j}"] = (1 - cos) / 2
    top_cols = [f"top_{j}" for j in selected]
    bottom_cols = [f"bottom_{j}" for j in selected]
    df["top"] = _fuzzy_and(df[top_cols].values)
    df["bottom"] = _fuzzy_and(df[bottom_cols].values)
    df["top_s"] = np.where(df["top"] > 0.2, "^", "")
    df["bottom_s"] = np.where(df["bottom"] > 0.2, "v", "")
    df.drop(columns=top_cols + bottom_cols, inplace=True)
    print(f"\n{topic_name}")
    print(df.to_string())


async def run_dds(
    loop: asyncio.AbstractEventLoop,
    queue: asyncio.Queue,
    shutdown: asyncio.Event,
    series_topic: str,
    fft_len: int = 16,
    top_start: int = 1,
    top_end: int | None = None,
) -> None:
    factory = fastdds.DomainParticipantFactory.get_instance()
    participant = factory.create_participant(0, fastdds.PARTICIPANT_QOS_DEFAULT)
    if participant is None:
        raise RuntimeError("Failed to create DomainParticipant")

    pubsub_type = SeriesPubSubType()
    pubsub_type.set_name('ohlcv_values')
    ts = fastdds.TypeSupport(pubsub_type)
    if participant.register_type(ts) != fastdds.RETCODE_OK:
        raise RuntimeError("Failed to register Series type")

    subscriber = participant.create_subscriber(fastdds.SUBSCRIBER_QOS_DEFAULT)
    if subscriber is None:
        raise RuntimeError("Failed to create subscriber")

    topic_obj = participant.create_topic(
        series_topic, pubsub_type.get_name(), fastdds.TOPIC_QOS_DEFAULT)
    if topic_obj is None:
        raise RuntimeError(f"Failed to create topic '{series_topic}'")

    reader = subscriber.create_datareader(
        topic_obj, fastdds.DATAREADER_QOS_DEFAULT,
        SeriesListener(series_topic, queue, loop))
    if reader is None:
        raise RuntimeError(f"Failed to create DataReader for '{series_topic}'")

    print(f"Listening on '{series_topic}'... (Ctrl+C to stop)")

    while not shutdown.is_set():
        try:
            topic_name, data = await asyncio.wait_for(queue.get(), timeout=1.0)
        except asyncio.TimeoutError:
            continue

        handle_series(data, topic_name, fft_len, top_start, top_end)

    participant.delete_contained_entities()
    factory.delete_participant(participant)


_CONFIG_FILE = ".inclination-fft.cnf"


def _load_config(section: str) -> dict:
    paths = [Path.cwd() / _CONFIG_FILE, Path.home() / _CONFIG_FILE]
    for p in paths:
        if p.exists():
            with p.open("rb") as f:
                cfg = tomli.load(f)
            if section not in cfg:
                raise SystemExit(f"Section '{section}' not found in {p}")
            return cfg[section]
    raise SystemExit(f"Config file '{_CONFIG_FILE}' not found in {[str(p) for p in paths]}")


async def main() -> None:
    if len(sys.argv) < 2:
        raise SystemExit("Usage: python -m inclination.fft.main SECTION")

    section = _load_config(sys.argv[1])
    exchange = section["exchange"]
    symbol = section["symbol"]
    interval = section["interval"]
    topic = section["topic"]
    fft_len = int(section.get("fft_len", 16))
    top_start = int(section.get("top_start", 1))
    top_end_str = section.get("top_end")
    top_end = int(top_end_str) if top_end_str is not None else None
    series_topic = f"{topic}_s"

    loop = asyncio.get_running_loop()
    queue: asyncio.Queue = asyncio.Queue()
    shutdown = asyncio.Event()

    def handle_sigint() -> None:
        print("\nShutting down reader...")
        shutdown.set()

    loop.add_signal_handler(signal.SIGINT, handle_sigint)

    await run_dds(loop, queue, shutdown, series_topic, fft_len, top_start, top_end)


def cmd():
    try:
        asyncio.run(main())
    except Exception:
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    cmd()

