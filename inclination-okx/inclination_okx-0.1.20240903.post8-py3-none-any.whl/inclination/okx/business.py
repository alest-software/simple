import time
import hmac
import base64
from typing import Optional
from attrs import frozen, field
#from attrs.validators import instance_of
from yarl import URL
from aiohttp import WSMsgType, WSCloseCode
from .context_manager import RequestContextManager
from .type import *
from .operation import *


milliseconds = lambda x: float(x) / 1000.0
confirm = lambda x: x == '1'

_str = lambda x: str(x) if x != '' else None
_float = lambda x: float(x) if x != '' else None
_int = lambda x: int(x) if x != '' else None
_bool = lambda x: (True if x == 'true' else False) if x != '' else None
_milliseconds = lambda x: milliseconds(x) if x != '' else None


class POS_SIDE(Enum):
    net   = 'net'
    long  = 'long'
    short = 'short'
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    __repr__ = lambda self: str(self)
    p = lambda x: POS_SIDE(x) if x != '' else None


class TD_MODE(Enum):
    cross    = 'cross'
    isolated = 'isolated'
    cash     = 'cash'
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    __repr__ = lambda self: str(self)
    p = lambda x: TD_MODE(x) if x != '' else None


class TGT_CCY(Enum):
    base_ccy  = 'base_ccy'
    quote_ccy = 'quote_ccy'
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    __repr__ = lambda self: str(self)
    p = lambda x: TGT_CCY(x) if x != '' else None


class BOOL(Enum):
    false = 'false'
    true  = 'true'
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    __repr__ = lambda self: str(self)
    p = lambda x: BOOL(x) if x != '' else None


class STATE(Enum):
    live             = 'live'
    effective        = 'effective'
    canceled         = 'canceled'
    order_failed     = 'order_failed'
    partially_failed = 'partially_failed'
    partially_filled = 'partially_filled'
    filled           = 'filled'
    mmp_canceled     = 'mmp_canceled'
    pause            = 'pause'
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    __repr__ = lambda self: str(self)
    p = lambda x: STATE(x) if x != '' else None


class TRIGGER_PRICE_TYPE(Enum):
    last  = 'last'
    index = 'index'
    mark  = 'mark'
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    __repr__ = lambda self: str(self)
    p = lambda x: TRIGGER_PRICE_TYPE(x) if x != '' else None


class EVENT_TYPE(Enum):
    snapshot = 'snapshot'
    filled   = 'filled'
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    __repr__ = lambda self: str(self)
    p = lambda x: EVENT_TYPE(x) if x != '' else None


class CATEGORY(Enum):
    normal              = 'normal'
    twap                = 'twap'
    adl                 = 'adl'
    full_liquidation    = 'full_liquidation'
    partial_liquidation = 'partial_liquidation'
    delivery            = 'delivery'
    ddh                 = 'ddh'
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    __repr__ = lambda self: str(self)
    p = lambda x: CATEGORY(x) if x != '' else None


class STP_MODE(Enum):
    cancel_maker = 'cancel_maker'
    cancel_taker = 'cancel_taker'
    cancel_both  = 'cancel_both'
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    __repr__ = lambda self: str(self)
    p = lambda x: STP_MODE(x) if x != '' else None


class EXEC_TYPE(Enum):
    M = 'M'
    T = 'T'
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    __repr__ = lambda self: str(self)
    p = lambda x: EXEC_TYPE(x) if x != '' else None


class ACTUAL_SIDE(Enum):
    tp = 'tp'
    sl = 'sl'
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    __repr__ = lambda self: str(self)
    p = lambda x: ACTUAL_SIDE(x) if x != '' else None


@frozen(kw_only=True)
class EventArg:
    channel:  CHANNEL = field(converter=CHANNEL)
    instType: str = None
    instId:   str = None
    #uid:     str = None


@frozen(kw_only=True)
class DataArg:
    channel:  CHANNEL = field(converter=CHANNEL)
    instId:   str = None
    instType: str = None
    uid:      str = None


@frozen(kw_only=True)
class ErrorEvent:
    event:  EVENT = field(converter=EVENT)
    code:   str
    msg:    str
    connId: str


@frozen(kw_only=True)
class SubscribeEvent:
    event:  EVENT = field(converter=EVENT)
    arg:    EventArg = field(default=None, converter=lambda x: EventArg(**x))
    connId: str = field(default=None)


@frozen(order=True)
class IndexChannel:
    ts:      float = field(converter=milliseconds)
    o:       float = field(converter=float)
    h:       float = field(converter=float)
    l:       float = field(converter=float)
    c:       float = field(converter=float)
    confirm: bool = field(converter=confirm)


@frozen(kw_only=True)
class IndexChannelData:
    arg:  DataArg = field(converter=lambda x: DataArg(**x))
    data: List[IndexChannel] = field(converter=lambda x: [IndexChannel(*i) for i in x])


@frozen(kw_only=True)
class LoginEvent:
    event:  EVENT = field(converter=EVENT)
    code:   int = field(converter=int)
    msg:    Optional[str] = field(converter=_str)
    connId: str


@frozen(kw_only=True)
class OrdersEvent:
    event:  EVENT = field(converter=EVENT)


@frozen(kw_only=True)
class ChannelConnCount:
    event:     EVENT = field(converter=EVENT)
    channel:   CHANNEL = field(converter=CHANNEL)
    connCount: int = field(converter=int)
    connId:    str


@frozen(kw_only=True)
class BalanceData:
    cashBal: float = field(converter=float)
    ccy:     str
    uTime:   float = field(converter=float)


@frozen(kw_only=True)
class PosData:
    posId:    str
    tradeId:  str
    instId:   str
    instType: str
    mgnMode:  str
    posSide:  str
    pos:      str
    ccy:      str
    posCcy:   str
    avgPx:    float = field(converter=_float)
    uTime:    str


@frozen(kw_only=True)
class Trade:
    instId:  str
    tradeId: str


@frozen(kw_only=True)
class BalanceAndPosition:
    balData:   List[BalanceData] = field(converter=lambda x: [BalanceData(**i) for i in x])
    posData:   List[PosData] = field(converter=lambda x: [PosData(**i) for i in x])
    trades:    List[Trade] = field(converter=lambda x: [Trade(**i) for i in x])
    eventType: EVENT_TYPE = field(converter=EVENT_TYPE)
    pTime:     int = field(converter=int)


@frozen(kw_only=True)
class BalanceAndPositionData:
    arg:  DataArg = field(converter=lambda x: DataArg(**x))
    data: BalanceAndPosition = field(converter=lambda x: [BalanceAndPosition(**i) for i in x])


@frozen(order=True)
class Candlestick:
    ts:          float = field(converter=milliseconds)
    o:           float = field(converter=float)
    h:           float = field(converter=float)
    l:           float = field(converter=float)
    c:           float = field(converter=float)
    vol:         float = field(converter=float)
    volCcy:      float = field(converter=float)
    volCcyQuote: float = field(converter=float)
    confirm:     bool = field(converter=confirm)


@frozen(kw_only=True)
class CandlesticksData:
    arg:  DataArg = field(converter=lambda x: DataArg(**x))
    data: Candlestick = field(converter=lambda x: [Candlestick(*i) for i in x])


@frozen(kw_only=True)
class Order:
    accFillSz:           float = field(converter=_float)
    algoClOrdId:         str
    algoId:              str
    amendResult:         str
    amendSource:         str
    avgPx:               float = field(converter=_float)
    cancelSource:        str
    category:            CATEGORY = field(converter=CATEGORY.p)
    ccy:                 str = field(converter=_str)
    clOrdId:             str
    code:                int = field(converter=_int)
    cTime:               float = field(converter=_milliseconds)
    execType:            EXEC_TYPE = field(converter=EXEC_TYPE.p)
    fee:                 float = field(converter=_float)
    feeCcy:              str = field(converter=_str)
    fillFee:             float = field(converter=_float)
    fillFeeCcy:          str = field(converter=_str)
    fillNotionalUsd:     float = field(converter=_float)
    fillPx:              float = field(converter=_float)
    fillSz:              float = field(converter=_float)
    fillPnl:             str
    fillTime:            float = field(converter=_milliseconds)
    fillPxVol:           str
    fillPxUsd:           float = field(converter=_float)
    fillFwdPx:           float = field(converter=_float)
    fillMarkPx:          float = field(converter=_float)
    fillMarkVol:         str
    instId:              str
    instType:            INST_TYPE = field(converter=INST_TYPE.p)
    lever:               float = field(converter=_float)
    msg:                 str = field(converter=_str)
    notionalUsd:         float = field(converter=_float)
    ordId:               str
    ordType:             ORD_TYPE = field(converter=ORD_TYPE.p)
    pnl:                 str
    posSide:             str
    px:                  float = field(converter=_float)
    pxUsd:               float = field(converter=_float)
    pxVol:               str
    pxType:              str
    quickMgnType:        str
    rebate:              str
    rebateCcy:           str
    reduceOnly:          bool = field(converter=_bool)
    reqId:               str
    side:                SIDE = field(converter=SIDE.p)
    attachAlgoClOrdId:   str
    slOrdPx:             float = field(converter=_float)
    slTriggerPx:         float = field(converter=_float)
    slTriggerPxType:     TRIGGER_PRICE_TYPE = field(converter=TRIGGER_PRICE_TYPE.p)
    source:              str
    state:               STATE = field(converter=STATE)
    stpId:               str
    stpMode:             STP_MODE = field(converter=STP_MODE.p)
    sz:                  float = field(converter=_float)
    tag:                 str
    tdMode:              TD_MODE = field(converter=TD_MODE.p)
    tgtCcy:              TGT_CCY = field(converter=TGT_CCY.p)
    tpOrdPx:             float = field(converter=_float)
    tpTriggerPx:         float = field(converter=_float)
    tpTriggerPxType:     TRIGGER_PRICE_TYPE = field(converter=TRIGGER_PRICE_TYPE.p)
    attachAlgoOrds:      str
    tradeId:             str
    lastPx:              float = field(converter=_float)
    uTime:               float = field(converter=_milliseconds)
    isTpLimit:           bool = field(converter=_bool)
    linkedAlgoOrd:       str


@frozen(kw_only=True)
class OrdersData:
    arg:  DataArg = field(converter=lambda x: DataArg(**x))
    data: List[Order] = field(converter=lambda x: [Order(**i) for i in x])


@frozen(kw_only=True)
class OrderAlgo:
    actualPx:             float = field(converter=_float)
    actualSide:           ACTUAL_SIDE = field(converter=ACTUAL_SIDE.p)
    actualSz:             float = field(converter=_float)
    algoClOrdId:          str
    algoId:               str
    amendResult:          int = field(converter=_int)
    cTime:                float = field(converter=_milliseconds)
    uTime:                float = field(converter=_milliseconds)
    ccy:                  str
    clOrdId:              str
    closeFraction:        str
    failCode:             str
    instId:               str
    instType:             INST_TYPE = field(converter=INST_TYPE.p)
    last:                 float = field(converter=_float)
    lever:                float = field(converter=_float)
    notionalUsd:          float = field(converter=_float)
    ordId:                str
    ordIdList:            list
    ordPx:                float = field(converter=_float)
    ordType:              ORD_TYPE = field(converter=ORD_TYPE.p)
    posSide:              POS_SIDE = field(converter=POS_SIDE.p)
    quickMgnType:         str
    reduceOnly:           BOOL = field(converter=BOOL.p)
    reqId:                str
    side:                 SIDE = field(converter=SIDE.p)
    slOrdPx:              float = field(converter=_float)
    slTriggerPx:          float = field(converter=_float)
    slTriggerPxType:      TRIGGER_PRICE_TYPE = field(converter=TRIGGER_PRICE_TYPE.p)
    state:                STATE = field(converter=STATE)
    sz:                   float = field(converter=_float)
    tag:                  str
    tdMode:               TD_MODE = field(converter=TD_MODE.p)
    tgtCcy:               TGT_CCY = field(converter=TGT_CCY.p)
    tpOrdPx:              float = field(converter=_float)
    tpTriggerPx:          float = field(converter=_float)
    tpTriggerPxType:      TRIGGER_PRICE_TYPE = field(converter=TRIGGER_PRICE_TYPE.p)
    triggerPx:            float = field(converter=_float)
    triggerTime:          float = field(converter=_milliseconds)
    amendPxOnTriggerType: int = field(converter=_int)
    linkedOrd:            dict


@frozen(kw_only=True)
class OrdersAlgoData:
    arg:  DataArg = field(converter=lambda x: DataArg(**x))
    data: List[OrderAlgo] = field(converter=lambda x: [OrderAlgo(**i) for i in x])


@frozen(kw_only=True)
class WebSocketResponse:
    response: int

#    def __getattr__(self, method):
#        return getattr(self.response, method)

    def __aiter__(self):
        return self

    async def __anext__(self):
        rval = None
        msg = await self.response.__anext__()
        #print(msg)
        if msg.type == WSMsgType.TEXT:
            data = msg.json()
            #print(data)
            if 'event' in data:
                switch = {
                    EVENT.subscribe:          SubscribeEvent,
                    EVENT.error:              ErrorEvent,
                    EVENT.login:              LoginEvent,
                    EVENT.orders:             OrdersEvent,
                    EVENT.channel_conn_count: ChannelConnCount,
                }
                Class = switch.get(EVENT(data['event']))
                if not Class:
                    raise Exception(f'Illegal event type ("{data["event"]}")')
                rval = Class(**data)
            elif 'data' in data:
                switch = {
                    CHANNEL.index_candle1m:       IndexChannelData,
                    CHANNEL.candle1m:             CandlesticksData,
                    CHANNEL.candle1D:             CandlesticksData,
                    CHANNEL.balance_and_position: BalanceAndPositionData,
                    CHANNEL.orders:               OrdersData,
                    CHANNEL.orders_algo:          OrdersAlgoData,
                }
                Class = switch.get(CHANNEL(data['arg']['channel']))
                if not Class:
                    raise Exception(f'Illegal channel ("{data["arg"]["channel"]}")')
                rval = Class(**data)
            else:
                raise Exception(f'Illegal text message ({data})')
        elif msg.type == WSMsgType.PONG:
            pass #print(msg) # type, data, extra
        elif msg.type == WSMsgType.ERROR:
            print(msg)
        else:
            raise Exception(f'Illegal message type ({msg.type.__repr__()})')
        return rval

    async def close(self, *, code=WSCloseCode.OK, message=b''):
        await self.response.close(code=code, message=message)

#    async def send_json(self, *args, **kwargs):
#        return await self.response.send_json(*args, **kwargs)

    async def login(self, *, apikey, secret, passphrase):
        timestamp = str(int(time.time()))
        msg = timestamp + 'GET' + '/users/self/verify'
        mac = hmac.new(bytes(secret, 'utf-8'), bytes(msg, 'utf-8'), digestmod='sha256')
        digest = mac.digest()
        base = base64.b64encode(digest)
        sign = base.decode('utf-8')
        arg = LoginArgs(apiKey=apikey, passphrase=passphrase, timestamp=timestamp, sign=sign)
        login = LoginOperation(op=OP.login, args=[arg])
        return await self.response.send_json(encode(login))


@frozen
class BusinessWebSocketResponse(WebSocketResponse):
    async def index_candlestick(self, *, channel, instId):
        arg = SubscribeArgs(channel=channel, instId=instId)
        subscribe = Operation(op=OP.subscribe, args=[arg])
        return await self.response.send_json(encode(subscribe))

    async def candlesticks(self, *, channel, instId):
        arg = SubscribeArgs(channel=channel, instId=instId)
        subscribe = Operation(op=OP.subscribe, args=[arg])
        return await self.response.send_json(encode(subscribe))

    async def algo_order_channel(self, *, channel, instType, instFamily, instId):
        arg = OrdersArgs(channel=channel, instType=instType, instFamily=instFamily, instId=instId)
        orders = Operation(op=OP.subscribe, args=[arg])
        return await self.response.send_json(encode(orders))


@frozen
class PrivateWebSocketResponse(WebSocketResponse):
#    async def login(self, *, apikey, secret, passphrase):
#        timestamp = str(int(time.time()))
#        msg = timestamp + 'GET' + '/users/self/verify'
#        mac = hmac.new(bytes(secret, 'utf-8'), bytes(msg, 'utf-8'), digestmod='sha256')
#        digest = mac.digest()
#        base = base64.b64encode(digest)
#        sign = base.decode('utf-8')
#        arg = LoginArgs(apiKey=apikey, passphrase=passphrase, timestamp=timestamp, sign=sign)
#        login = LoginOperation(op=OP.login, args=[arg])
#        return await self.response.send_json(encode(login))

    async def balance_and_position(self, *, channel):
        arg = BalanceAndPositionArgs(channel=channel)
        subscribe = Operation(op=OP.subscribe, args=[arg])
        return await self.response.send_json(encode(subscribe))

    async def order_channel(self, *, channel, instType, instFamily, instId):
        arg = OrdersArgs(channel=channel, instType=instType, instFamily=instFamily, instId=instId)
        orders = Operation(op=OP.subscribe, args=[arg])
        return await self.response.send_json(encode(orders))


@frozen(kw_only=True)
class BusinessRequest:
    base: URL

    def __call__(self, *, session, **kwargs):
        url = self.base / 'ws/v5/business'
        return RequestContextManager(
                session.ws_connect(url, **kwargs),
                BusinessWebSocketResponse)


@frozen(kw_only=True)
class PrivateRequest:
    base: URL

    def __call__(self, *, session, **kwargs):
        url = self.base / 'ws/v5/private'
        return RequestContextManager(
                session.ws_connect(url, **kwargs),
                PrivateWebSocketResponse)

