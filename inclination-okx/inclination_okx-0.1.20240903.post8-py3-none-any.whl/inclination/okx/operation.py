from attrs import frozen, field
from enum import Enum
from typing import List
from functools import singledispatch


class OP(Enum):
    subscribe   = 'subscribe'
    unsubscribe = 'unsubscribe'
    login       = 'login'
    order       = 'order'
    __repr__ = lambda self: str(self)
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    p = lambda x: OP(x) if x != '' else None


class CHANNEL(Enum):
    index_candle1m       = 'index-candle1m'
    balance_and_position = 'balance_and_position'
    orders               = 'orders'
    orders_algo          = 'orders-algo'
    candle1m             = 'candle1m'
    candle1D             = 'candle1D'
    __repr__ = lambda self: str(self)
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    p = lambda x: CHANNEL(x) if x != '' else None


class SIDE(Enum):
    buy  = 'buy'
    sell = 'sell'
    __repr__ = lambda self: str(self)
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    p = lambda x: SIDE(x) if x != '' else None


class TD_MODE(Enum):
    cash          = 'cash'
    cross         = 'cross'
    isolated      = 'isolated'
    spot_isolated = 'spot_isolated'
    __repr__ = lambda self: str(self)
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    p = lambda x: TD_MODE(x) if x != '' else None


class ORD_TYPE(Enum):
    market            = 'market'
    limit             = 'limit'
    post_only         = 'post_only'
    fok               = 'fok'
    ioc               = 'ioc'
    optimal_limit_ioc = 'optimal_limit_ioc'
    mmp               = 'mmp'
    mmp_and_post_only = 'mmp_and_post_only'
    op_fok            = 'op_fok'
    conditional       = 'conditional'
    oco               = 'oco'
    trigger           = 'trigger'
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    __repr__ = lambda self: str(self)
    p = lambda x: ORD_TYPE(x) if x != '' else None


class INST_TYPE(Enum):
    spot    = 'SPOT'
    margin  = 'MARGIN'
    swap    = 'SWAP'
    futures = 'FUTURES'
    option  = 'OPTION'
    any     = 'ANY'
    __repr__ = lambda self: str(self)
    __format__ = lambda self, format_spec: self.name if format_spec == 'n' else self.value if format_spec == 'v' else super().__format__(format_spec)
    p = lambda x: INST_TYPE(x) if x != '' else None


@frozen(kw_only=True)
class LoginArgs:
    apiKey:     str
    passphrase: str
    timestamp:  str
    sign:       str


@frozen(kw_only=True)
class LoginOperation:
    op:   OP
    args: LoginArgs


@frozen(kw_only=True)
class SubscribeArgs:
    channel: CHANNEL
    instId:  str


@frozen(kw_only=True)
class BalanceAndPositionArgs:
    channel: CHANNEL


@frozen(kw_only=True)
class OrdersArgs:
    channel:    CHANNEL
    instType:   INST_TYPE
    instFamily: str
    instId:     str


@frozen(kw_only=True)
class Operation:
    op:   OP
    args: List[SubscribeArgs] = field(factory=list)


@singledispatch
def encode(x):
    raise NotImplementedError(f'{type(x)}')

@encode.register
def _(x: list):
    return [encode(i) for i in x]

@encode.register
def _(x: OP):
    return x.name

@encode.register
def _(x: CHANNEL):
    return x.value

@encode.register
def _(x: SubscribeArgs):
    return {'channel': x.channel.value, 'instId': x.instId}

@encode.register
def _(x: BalanceAndPositionArgs):
    return {'channel': 'balance_and_position'}

@encode.register
def _(x: OrdersArgs):
    data = {
            'channel': x.channel.value,
            'instType': x.instType.value
            }
    return data

@encode.register
def _(x: LoginArgs):
    return {'apiKey': x.apiKey, 'passphrase': x.passphrase, 'timestamp': x.timestamp, 'sign': x.sign}

@encode.register
def _(x: Operation):
    return { 'op': x.op.name, 'args': [encode(i) for i in x.args] }

@encode.register
def _(x: LoginOperation):
    return { 'op': encode(x.op), 'args': encode(x.args) }

