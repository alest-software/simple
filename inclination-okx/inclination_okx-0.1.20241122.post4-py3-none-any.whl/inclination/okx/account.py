import datetime
import base64
import hmac
import hashlib
from typing import List
from attrs import frozen, field
##from attrs.validators import instance_of
from yarl import URL
from aiohttp import WSMsgType, WSCloseCode
from .context_manager import RequestContextManager
#from .type import *
import math


def precision_and_scale(x):
    max_digits = 14
    int_part = int(abs(x))
    magnitude = 1 if int_part == 0 else int(math.log10(int_part)) + 1
    if magnitude >= max_digits:
        return (magnitude, 0)
    frac_part = abs(x) - int_part
    multiplier = 10 ** (max_digits - magnitude)
    frac_digits = multiplier + int(multiplier * frac_part + 0.5)
    while frac_digits % 10 == 0:
        frac_digits /= 10
    scale = int(math.log10(frac_digits))
    return (magnitude + scale, scale)


def float_f(x):
    if x is None:
        return ''
    magnitude, scale = precision_and_scale(x)
    return '{value:{width}.{precision}f}'.format(value=x, width=magnitude, precision=scale)


@frozen(kw_only=True)
class AccountDetails:
    availBal:       int
    availEq:        int
    accAvgPx:       int
    borrowFroz:     int
    cashBal:        int
    ccy:            int
    clSpotInUseAmt: int
    crossLiab:      int
    disEq:          int
    eq:             int
    eqUsd:          int
    fixedBal:       int
    frozenBal:      int
    imr:            int
    interest:       int
    isoEq:          int
    isoLiab:        int
    isoUpl:         int
    liab:           int
    maxLoan:        int
    maxSpotInUse:   int
    mgnRatio:       int
    mmr:            int
    notionalLever:  int
    ordFrozen:      int
    openAvgPx:      int
    rewardBal:      int
    smtSyncEq:      int
    spotInUseAmt:   int
    spotIsoBal:     int
    spotBal:        int
    spotUpl:        int
    spotUplRatio:   int
    stgyEq:         int
    totalPnl:       int
    totalPnlRatio:  int
    twap:           int
    uTime:          int
    upl:            int
    uplLiab:        int
 

@frozen(kw_only=True)
class AccountData:
    adjEq:       int
    borrowFroz:  int
    details:     List[AccountDetails] = field(converter=lambda x: [AccountDetails(**i) for i in x])
    imr:         int
    isoEq:       int
    mgnRatio:    int
    mmr:         int
    notionalUsd: int
    ordFroz:     int
    totalEq:     int
    uTime:       int
    upl:         int


@frozen(kw_only=True)
class Account:
    code: int = field(converter=int)
    msg:  str
    data: List[AccountData] = field(converter=lambda x: [AccountData(**i) for i in x])


@frozen(kw_only=True)
class AccountResponse:
    response: int

#    async def close(self, *, code=WSCloseCode.OK, message=b''):
#        await self.response.close(code=code, message=message)

    async def data(self):
        data = await self.response.json()
        return Account(**data)


def get_timestamp():
    return datetime.datetime.utcnow().isoformat('T', 'milliseconds') + 'Z'

def get_sign(secret, timestamp, method, request_path, body=''):
    msg = timestamp + method + request_path + body
    digest = hmac.new(bytes(secret, 'utf-8'), bytes(msg, 'utf-8'), digestmod='sha256').digest()
    sign = base64.b64encode(digest).decode('utf-8')
    return sign

def get_ok_access_headers(apikey, secret, passphrase, method, request_path, body=''):
    timestamp = get_timestamp()
    sign = get_sign(secret, timestamp, method, request_path, body)
    return {
        'OK-ACCESS-KEY': apikey,
        'OK-ACCESS-SIGN': sign,
        'OK-ACCESS-TIMESTAMP': timestamp,
        'OK-ACCESS-PASSPHRASE': passphrase,
    }



@frozen(kw_only=True)
class AccountRequest:
    base:       URL

    def __call__(self, session, apikey, secret, passphrase, simulated_trading=True):
        method = 'GET'
        url = self.base / 'api/v5/account/balance'

        request_path = f'{url.path}?{url.query_string}' if url.query_string else f'{url.path}'

        ok_access_headers = get_ok_access_headers(apikey, secret, passphrase, method, request_path)

        headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                **ok_access_headers,
                **({'x-simulated-trading': '1'} if simulated_trading else {})
                }

        return RequestContextManager(
                session.request(method, url, headers=headers),
                AccountResponse)


import json
from .operation import *
from .business import _int, _str, _milliseconds


@frozen(kw_only=True)
class TradeOrderData:
    ts:      float = field(converter=_milliseconds)
    ordId:   str = field(converter=_str)
    clOrdId: str = field(converter=_str)
    sCode:   int = field(converter=_int)
    sMsg:    str = field(converter=_str)
    tag:     str = field(converter=_str)

@frozen(kw_only=True)
class TradeOrder:
    inTime:  float = field(converter=_milliseconds)
    outTime: float = field(converter=_milliseconds)
    code:    int = field(converter=_int)
    msg:     str = field(converter=_str)
    data:    List[TradeOrderData] = field(converter=lambda x: [TradeOrderData(**i) for i in x])


@frozen(kw_only=True)
class TradeOrderResponse:
    response: int

#    async def close(self, *, code=WSCloseCode.OK, message=b''):
#        await self.response.close(code=code, message=message)

    async def data(self):
        data = await self.response.json()
        return TradeOrder(**data)


@frozen(kw_only=True)
class TradeOrderRequest:
    base:       URL

    instId:     str = None
    tdMode:     TD_MODE = None
    clOrdId:    str = None
    side:       SIDE = None
    ordType:    ORD_TYPE = None
    px:         str = None
    sz:         str = None
    # Other fields...

    def __call__(self, session, apikey, secret, passphrase, simulated_trading=True):
        method = 'POST'
        url = self.base / 'api/v5/trade/order'

        request_path = f'{url.path}?{url.query_string}' if url.query_string else f'{url.path}'

        params = {
            **({'instId': self.instId} if self.instId is not None else {}),
            **({'tdMode': self.tdMode.value} if self.tdMode is not None else {}),
            **({'clOrdId': self.clOrdId} if self.clOrdId is not None else {}),
            **({'side': self.side.value} if self.side is not None else {}),
            **({'ordType': self.ordType.value} if self.ordType is not None else {}),
            **({'px': str(self.px)} if self.px is not None else {}),
            **({'sz': str(self.sz)} if self.sz is not None else {}),
        }
        body = json.dumps(params, separators=(',', ':'))

        ok_access_headers = get_ok_access_headers(apikey, secret, passphrase, method, request_path, body)

        headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                **ok_access_headers,
                **({'x-simulated-trading': '1'} if simulated_trading else {})
                }

        return RequestContextManager(
                session.request(method, url, headers=headers, data=body),
                TradeOrderResponse)


@frozen(kw_only=True)
class TradeOrderAlgoData:
    algoClOrdId: str = field(converter=_str)
    algoId:      str = field(converter=_str)
    clOrdId:     str = field(converter=_str)
    sCode:       int = field(converter=_int)
    sMsg:        str = field(converter=_str)
    tag:         str = field(converter=_str)


@frozen(kw_only=True)
class TradeOrderAlgo:
    code:    int = field(converter=_int)
    msg:     str = field(converter=_str)
    data:    List[TradeOrderAlgoData] = field(converter=lambda x: [TradeOrderAlgoData(**i) for i in x])


@frozen(kw_only=True)
class TradeOrderAlgoResponse:
    response: int

#    async def close(self, *, code=WSCloseCode.OK, message=b''):
#        await self.response.close(code=code, message=message)

    async def data(self):
        data = await self.response.json()
        return TradeOrderAlgo(**data)


@frozen(kw_only=True)
class TradeOrderAlgoRequest:
    base:       URL

    instId:      str = None
    tdMode:      TD_MODE = None
    side:        SIDE = None
    ordType:     ORD_TYPE = None
    px:          str = None
    sz:          str = None
    slTriggerPx: str = None
    slOrdPx:     str = None
    tpTriggerPx: str = None
    tpOrdPx:     str = None
    algoClOrdId: str = None
    # Other fields...

    def __call__(self, session, apikey, secret, passphrase, simulated_trading=True):
        method = 'POST'
        url = self.base / 'api/v5/trade/order-algo'

        request_path = f'{url.path}?{url.query_string}' if url.query_string else f'{url.path}'

        params = {
            **({'instId':      self.instId}               if self.instId is not None else {}),
            **({'tdMode':      self.tdMode.value}         if self.tdMode is not None else {}),
            **({'side':        self.side.value}           if self.side is not None else {}),
            **({'ordType':     self.ordType.value}        if self.ordType is not None else {}),
            **({'px':          float_f(self.px)}          if self.px is not None else {}),
            **({'sz':          float_f(self.sz)}          if self.sz is not None else {}),
            **({'slTriggerPx': float_f(self.slTriggerPx)} if self.slTriggerPx is not None else {}),
            **({'slOrdPx':     float_f(self.slOrdPx)}     if self.slOrdPx is not None else {}),
            **({'tpTriggerPx': float_f(self.tpTriggerPx)} if self.tpTriggerPx is not None else {}),
            **({'tpOrdPx':     float_f(self.tpOrdPx)}     if self.tpOrdPx is not None else {}),
            **({'algoClOrdId': self.algoClOrdId}          if self.algoClOrdId is not None else {}),
        }
        body = json.dumps(params, separators=(',', ':'))

        ok_access_headers = get_ok_access_headers(apikey, secret, passphrase, method, request_path, body)

        headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                **ok_access_headers,
                **({'x-simulated-trading': '1'} if simulated_trading else {})
                }

        return RequestContextManager(
                session.request(method, url, headers=headers, data=body),
                TradeOrderAlgoResponse)

