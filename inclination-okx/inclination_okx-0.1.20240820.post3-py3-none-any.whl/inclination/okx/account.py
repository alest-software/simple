import datetime
import base64
import hmac
import hashlib
from typing import List
from attrs import frozen, field
##from attrs.validators import instance_of
from yarl import URL
from aiohttp import WSMsgType, WSCloseCode
from .context_manager import RequestContextManager
#from .type import *


@frozen(kw_only=True)
class AccountDetails:
    availBal:       int
    availEq:        int
    borrowFroz:     int
    cashBal:        int
    ccy:            int
    clSpotInUseAmt: int
    crossLiab:      int
    disEq:          int
    eq:             int
    eqUsd:          int
    fixedBal:       int
    frozenBal:      int
    imr:            int
    interest:       int
    isoEq:          int
    isoLiab:        int
    isoUpl:         int
    liab:           int
    maxLoan:        int
    maxSpotInUse:   int
    mgnRatio:       int
    mmr:            int
    notionalLever:  int
    ordFrozen:      int
    rewardBal:      int
    smtSyncEq:      int
    spotInUseAmt:   int
    spotIsoBal:     int
    stgyEq:         int
    twap:           int
    uTime:          int
    upl:            int
    uplLiab:        int
 

@frozen(kw_only=True)
class AccountData:
    adjEq:       int
    borrowFroz:  int
    details:     List[AccountDetails] = field(converter=lambda x: [AccountDetails(**i) for i in x])
    imr:         int
    isoEq:       int
    mgnRatio:    int
    mmr:         int
    notionalUsd: int
    ordFroz:     int
    totalEq:     int
    uTime:       int
    upl:         int


@frozen(kw_only=True)
class Account:
    code: int = field(converter=int)
    msg:  str
    data: List[AccountData] = field(converter=lambda x: [AccountData(**i) for i in x])


@frozen(kw_only=True)
class AccountResponse:
    response: int

#    async def close(self, *, code=WSCloseCode.OK, message=b''):
#        await self.response.close(code=code, message=message)

    async def data(self):
        json = await self.response.json()
        return Account(**json)


def get_timestamp():
    return datetime.datetime.utcnow().isoformat('T', 'milliseconds') + 'Z'

def get_sign(secret, timestamp, method, request_path, body=''):
    msg = timestamp + method + request_path + body
    digest = hmac.new(bytes(secret, 'utf-8'), bytes(msg, 'utf-8'), digestmod='sha256').digest()
    sign = base64.b64encode(digest).decode('utf-8')
    return sign

def get_ok_access_headers(apikey, secret, passphrase, method, request_path, body=''):
    timestamp = get_timestamp()
    sign = get_sign(secret, timestamp, method, request_path, body)
    return {
        'OK-ACCESS-KEY': apikey,
        'OK-ACCESS-SIGN': sign,
        'OK-ACCESS-TIMESTAMP': timestamp,
        'OK-ACCESS-PASSPHRASE': passphrase,
    }



@frozen(kw_only=True)
class AccountRequest:
    base:       URL

    def __call__(self, session, apikey, secret, passphrase, simulated_trading=True):
        method = 'GET'
        url = self.base / 'api/v5/account/balance'

        request_path = f'{url.path}?{url.query_string}' if url.query_string else f'{url.path}'

        ok_access_headers = get_ok_access_headers(apikey, secret, passphrase, method, request_path)

        headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                **ok_access_headers,
                **({'x-simulated-trading': '1'} if simulated_trading else {})
                }

        return RequestContextManager(
                session.request(method, url, headers=headers),
                AccountResponse)


import json
from .operation import *
from .business import milliseconds


@frozen(kw_only=True)
class TradeOrderData:
    ts:      float = field(converter=milliseconds)
    ordId:   str
    clOrdId: str
    sCode:   int = field(converter=int)
    sMsg:    str
    tag:     str

@frozen(kw_only=True)
class TradeOrder:
    inTime:  float = field(converter=milliseconds)
    outTime: float = field(converter=milliseconds)
    code:    int = field(converter=int)
    msg:     str
    data:    List[TradeOrderData] = field(converter=lambda x: [TradeOrderData(**i) for i in x])


@frozen(kw_only=True)
class TradeOrderResponse:
    response: int

#    async def close(self, *, code=WSCloseCode.OK, message=b''):
#        await self.response.close(code=code, message=message)

    async def data(self):
        json = await self.response.json()
        print(json)
        return TradeOrder(**json)


@frozen(kw_only=True)
class TradeOrderRequest:
    base:       URL

    instId:     str = None
    tdMode:     TD_MODE = None
    clOrdId:    str = None
    side:       SIDE = None
    ordType:    ORD_TYPE = None
    px:         str = None
    sz:         str = None
    # Other fields...

    def __call__(self, session, apikey, secret, passphrase, simulated_trading=True):
        method = 'POST'
        url = self.base / 'api/v5/trade/order'

        request_path = f'{url.path}?{url.query_string}' if url.query_string else f'{url.path}'

        params = {
            **({'instId': self.instId} if self.instId is not None else {}),
            **({'tdMode': self.tdMode.value} if self.tdMode is not None else {}),
            **({'clOrdId': self.clOrdId} if self.clOrdId is not None else {}),
            **({'side': self.side.value} if self.side is not None else {}),
            **({'ordType': self.ordType.value} if self.ordType is not None else {}),
            **({'px': str(self.px)} if self.px is not None else {}),
            **({'sz': str(self.sz)} if self.sz is not None else {}),
        }
        body = json.dumps(params, separators=(',', ':'))

        ok_access_headers = get_ok_access_headers(apikey, secret, passphrase, method, request_path, body)

        headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                **ok_access_headers,
                **({'x-simulated-trading': '1'} if simulated_trading else {})
                }

        return RequestContextManager(
                session.request(method, url, headers=headers, data=body),
                TradeOrderResponse)

