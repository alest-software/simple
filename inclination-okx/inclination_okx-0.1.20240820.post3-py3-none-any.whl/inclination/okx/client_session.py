from attrs import frozen, field
from yarl import URL
import aiohttp
from .business import BusinessRequest, PrivateRequest
from .account import AccountRequest, TradeOrderRequest


@frozen(kw_only=True)
class ClientSession:
    session: aiohttp.ClientSession = field(factory=aiohttp.ClientSession)
    base: URL

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_value, exc_tb):
        await self.close()

#    async def close(self):
#        await self.session.close()

    def __getattr__(self, method):
        return getattr(self.session, method)

    def business(self, **kwargs):
        return BusinessRequest(base=self.base)(session=self.session, **kwargs)

    def private(self, **kwargs):
        return PrivateRequest(base=self.base)(session=self.session, **kwargs)

    def get_account_balance(self, *, apikey, secret, passphrase, simulated_trading=True):
        return AccountRequest(base=self.base)(self.session, apikey=apikey, secret=secret, passphrase=passphrase, simulated_trading=simulated_trading)

    def post_trade_order(self, *, apikey, secret, passphrase, simulated_trading=True, **kwargs):
        return TradeOrderRequest(base=self.base, **kwargs)(self.session, apikey=apikey, secret=secret, passphrase=passphrase, simulated_trading=simulated_trading)

