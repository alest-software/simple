from typing import Any
from attrs import frozen
import aiohttp


@frozen
class RequestContextManager():
    request_context_manager: aiohttp.ClientResponse
    Response: Any

    async def __aenter__(self):
        response = await self.request_context_manager.__aenter__()
        return self.Response(response=response)

    async def __aexit__(self, exc_type, exc_value, exc_tb):
        await self.request_context_manager.__aexit__(exc_type, exc_value, exc_tb)

