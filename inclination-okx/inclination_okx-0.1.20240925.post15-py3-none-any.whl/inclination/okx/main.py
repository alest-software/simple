from functools import partial, singledispatchmethod
from collections import OrderedDict
import signal
import os
from pathlib import Path
import re
import json
import uuid
from argparse import ArgumentParser
import logging
from pprint import pprint
from attrs import frozen, define, field, asdict
from attrs.validators import instance_of
from yarl import URL
import asyncio
import async_timer
import aiohttp
from aiohttp import web
import time
from .client_session import ClientSession
from .operation import *
from .business import *
from . import mqtt
try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib


logger = logging.getLogger(__name__)
private_log = logging.getLogger('private ')
business_log = logging.getLogger('business')
logging.basicConfig(level=logging.DEBUG)


url_ws = URL('wss://wspap.okx.com:8443/')
#url_ws = URL('wss://ws.okx.com:8443/')
url_rest = URL('https://www.okx.com/')


@define
class Formatter:
    fields: list = field(default=list)
    formats: dict = field(default=dict)
    sep = '|'
    def __call__(self, **kwargs):
        d = {k: str.format(f'{{{0}:{self.formats[k][0] if k in self.formats else ""}}}', v) if v else '-' for k, v in kwargs.items()}
        fmt = self.sep.join([f'{{{i}:{self.formats[i][1] if i in self.formats else ""}}}' for i in self.fields])
        return str.format(fmt, **d)

formats = {
    'algoId':      [   's',  '20s' ],
    'instId':      [   's', '>12s' ],
    'uTime':       [ '.3f',  '16s' ],
    'ordType':     [   'n', '^16s' ],
    'state':       [   'n', '^22s' ],
    'side':        [   'n', '^10s' ],
    'sz':          [ '.6f',  '12s' ],
    'px':          [ '.6f',  '12s' ],
    'avgPx':       [ '.6f',  '12s' ],
    'fillSz':      [ '.6f',  '12s' ],
    'accFillSz':   [ '.6f',  '12s' ],
    'slTriggerPx': [ '.6f',  '12s' ],
    'tpTriggerPx': [ '.6f',  '12s' ],
    'actualSide':  [   'n',   '2s' ],
}

fmt_order = Formatter(
        fields=['instId', 'uTime', 'ordType', 'state', 'side', 'sz', 'px', 'avgPx', 'fillSz', 'accFillSz', 'algoId'],
        formats=formats)

fmt_order_algo = Formatter(
        fields=['instId', 'uTime', 'ordType', 'state', 'side', 'sz', 'actualSide', 'slTriggerPx', 'tpTriggerPx'],
        formats=formats)

#levt = lambda x: str.format("{x.event}" "{x.code}" "{x.msg}" "{x.connId}", x=x)

lformats = {
    'code': ['d',  '3s'],
    'msg':  ['s', '20s'],
}
levt = Formatter(
        fields=['event', 'code', 'msg', 'connId'],
        formats=lformats)

@define
class Main:
    mqtt: int = None
    cred: int = None
    done: bool = False
    mqtt_done: asyncio.Future = None
    ws_private: int = None
    ws_business: int = None
    index_channel_data: dict = field(factory=dict)
    candlesticks: dict = field(factory=dict)
    balance_data: dict = field(factory=dict)
    orders_data: OrderedDict = field(factory=OrderedDict)
    orders_algo_data: OrderedDict = field(factory=OrderedDict)
    symbols: dict = field(factory=dict)
    rsymbols: dict = field(factory=dict)
    candle1m: dict = field(factory=dict)
    index_candle1m: dict = field(factory=dict)
    interactive: bool = False
    http_done: asyncio.Future = None

    async def on_sigint(self):
        print('sigint')
        self.done = True
        self.mqtt_done.set_result(0)
        self.http_done.set_result(0)
        if self.ws_private:
            await self.ws_private.close()
        if self.ws_business:
            await self.ws_business.close()

    def overview(self):
        rval = '\033[2J\033[H'
        for k, v in self.index_channel_data.items():
            #print(v)
            rval += f'{k:12s} {v.ts:12.3f} {v.o:12.6f} {v.h:12.6f} {v.l:12.6f} {v.c:12.6f} {v.confirm}\n'
        for k, v in self.candlesticks.items():
            #print(v)
            rval += f'{k:12s}|{v.ts:12.3f}|{v.o:12.6f}|{v.h:12.6f}|{v.l:12.6f}|{v.c:12.6f}|{v.vol:12.6f}|{v.volCcy:12.6f}|{v.volCcyQuote:12.6f}|{v.confirm}\n'
        for ccy, v in self.balance_data.items():
            cashBal = float(v.cashBal)
            uTime = float(v.uTime)
            s = f'{ccy}-USD'
            if s in self.index_channel_data:
                idx = self.index_channel_data[s]
                c = float(idx.c)
                vv = cashBal * c
                rval += f'{cashBal:12.6f} {ccy:5}  = {vv:12.6f} USD (@{c:12.6f})\n'
            else:
                rval += f'{cashBal:12.6f} {ccy:5}\n'
        rval += '\n'
        rval += self.print_orders()
        return rval

    @singledispatchmethod
    async def on_private(self, msg):
        raise NotImplementedError(f'{type(msg)}')

    @on_private.register
    async def _(self, msg: ErrorEvent):
        private_log.debug(msg)
        await asyncio.sleep(1)
        await self.ws_private.close()

    @on_private.register
    async def _(self, msg: LoginEvent):
        if msg.code != 0:
            private_log.debug(f'login: code={msg.code} msg="{msg.msg}"')
            await asyncio.sleep(1)
            await self.ws_private.close()
        else:
            private_log.debug(f'successful login')
            await self.ws_private.balance_and_position(channel=CHANNEL.balance_and_position)
            await self.ws_private.order_channel(channel=CHANNEL.orders, instType=INST_TYPE.any, instFamily=None, instId=None)

    @on_private.register
    async def _(self, msg: SubscribeEvent):
        private_log.debug(f'subscribe: channel={msg.arg.channel.value} inst={msg.arg.instId}')

    @on_private.register
    async def _(self, msg: ChannelConnCount):
        private_log.debug(f'channel count: connCount={msg.connCount} connId={msg.connId}')

    @on_private.register
    async def _(self, msg: OrdersData):
        #print('on_private(msg: OrdersData)')
        #print(msg)
        #for d in msg.data:
        #    f = {k: v for k, v in asdict(d).items() if v != '' and v != None}
        #    pprint(f)
        for d in msg.data:
            if d.ordId not in self.orders_data:
                self.orders_data[d.ordId] = []
            self.orders_data[d.ordId].append(d)

            if d.ordType == ORD_TYPE.market:
                base, quote = self.rsymbols[d.instId]
                z = {
                    'cTime': d.cTime,
                    'uTime': d.uTime,
                    'state': d.state.value,
                    'side': d.side.value,
                    'size': d.sz,
                    'algoClOrdId': d.algoClOrdId,
                    'algoId': d.algoId,
                    'clOrdId': d.clOrdId,
                    'ordId': d.ordId,
                    }
                await self.mqtt.publish(f'inclination/market/okx/{base}/{quote}/{d.ordId}', json.dumps(z))
            elif d.ordType == ORD_TYPE.limit:
                base, quote = self.rsymbols[d.instId]
                z = {
                    'cTime': d.cTime,
                    'uTime': d.uTime,
                    'state': d.state.value,
                    'side': d.side.value,
                    'size': d.sz,
                    'algoClOrdId': d.algoClOrdId,
                    'algoId': d.algoId,
                    'clOrdId': d.clOrdId,
                    'ordId': d.ordId,
                    }
                await self.mqtt.publish(f'inclination/limit/okx/{base}/{quote}/{d.ordId}', json.dumps(z))

            if (d.state == STATE.filled) or (d.state == STATE.canceled):
                self.orders_data.pop(d.ordId, None)

        print(self.print_orders())

    @on_private.register
    async def _(self, msg: BalanceAndPositionData):
        #print(msg)
        for i in msg.data:
            for j in i.balData:
                private_log.debug(j)
                self.balance_data[j.ccy] = j

                await self.mqtt.publish(f'inclination/balance/okx/default/{j.ccy}', json.dumps(j.cashBal))

            for j in i.posData:
                pass

            for j in i.trades:
                pass

    @singledispatchmethod
    async def on_business(self, msg):
        raise NotImplementedError(f'{type(msg)}')

    @on_business.register
    async def _(self, msg: ErrorEvent):
        business_log.debug(msg)
        await asyncio.sleep(1)
        await self.ws_business.close()

    @on_business.register
    async def _(self, msg: LoginEvent):
        if msg.code != 0:
            business_log.debug(f'login: code={msg.code} msg="{msg.msg}"')
            await asyncio.sleep(1)
            await self.ws_business.close()
        else:
            business_log.debug('successful login')
            await self.ws_business.algo_order_channel(channel=CHANNEL.orders_algo, instType=INST_TYPE.any, instFamily=None, instId=None)

    @on_business.register
    async def _(self, msg: SubscribeEvent):
        business_log.debug(f'subscribe: channel={msg.arg.channel.value} inst={msg.arg.instId}')

    @on_business.register
    async def _(self, msg: IndexChannelData):
        now = time.time()

        #business_log.debug(msg)
        for d in msg.data:
            self.index_channel_data[msg.arg.instId] = d

            #base, quote = self.rsymbols[msg.arg.instId]
            await self.mqtt.publish(f'inclination/actual/okx/{msg.arg.instId}/{now:.3f}', json.dumps(d.c))

            #if d.confirm:
            #    candle = { 'o': d.o, 'h': d.h, 'l': d.l, 'c': d.c }
            #    await self.mqtt.publish(f'inclination/okx/index/okx/{base}/{quote}/{d.ts:.0f}', json.dumps(candle))

    @on_business.register
    async def _(self, msg: CandlesticksData):
        now = time.time()

        #business_log.debug(msg)
        for d in msg.data:
            self.candlesticks[msg.arg.instId] = d

            #base, quote = self.rsymbols[msg.arg.instId]
            await self.mqtt.publish(f'inclination/actual/okx/{msg.arg.instId}/{now:.3f}', json.dumps(d.c))

            if d.confirm:
                candle = { 'o': d.o, 'h': d.h, 'l': d.l, 'c': d.c, 'v': d.vol }
                await self.mqtt.publish(f'inclination/candle/okx/{msg.arg.instId}/{d.ts:.0f}', json.dumps(candle))

    def print_orders(self):
        rval = ''
        for k, d in self.orders_data.items():
            rval += k + '\n'
            for o in d:
                rval += fmt_order(**asdict(o))
                rval += '\n'
        rval += '\n'
        for k, d in self.orders_algo_data.items():
            rval += k + '\n'
            for o in d:
                rval += fmt_order_algo(**asdict(o))
                rval += '\n'
        return rval

    @on_business.register
    async def _(self, msg: OrdersAlgoData):
        #print('on_business(msg: OrdersAlgoData)')
        #print(msg)
        #for d in msg.data:
        #    f = {k: v for k, v in asdict(d).items() if v != '' and v != None}
        #    pprint(f)
        for d in msg.data:
            if d.algoId not in self.orders_algo_data:
                self.orders_algo_data[d.algoId] = []
            self.orders_algo_data[d.algoId].append(d)

            if (d.state == STATE.effective) or (d.state == STATE.canceled):
                self.orders_algo_data.pop(d.algoId, None)

            #data = asdict(d)
            #print(data)
            #data['instType'] = data['instType'].value
            #data['ordType'] = data['ordType'].value
            #data['reduceOnly'] = data['reduceOnly'].value
            #data['side'] = data['side'].value
            #data['slTriggerPxType'] = data['slTriggerPxType'].value
            #data['tpTriggerPxType'] = data['tpTriggerPxType'].value
            #data['state'] = data['state'].value
            #data['tdMode'] = data['tdMode'].value
            dd = {
                    'cTime':       d.cTime,
                    'uTime':       d.uTime,
                    'symbol':      d.instId,
                    'state':       d.state.value,
                    'side':        d.side.value,
                    'size':        d.sz,
                    'takeprofit':  d.tpTriggerPx,
                    'stoploss':    d.slTriggerPx,
                    'algoClOrdId': d.algoClOrdId,
                    'algoId':      d.algoId,
                    }
            await self.mqtt.publish(f'inclination/oco/okx/time', json.dumps(dd))

        print(self.print_orders())

    async def on_trade_market(self, payload, *, base, quote):
        print('on_trade_market', payload, base, quote)

        @frozen(kw_only=True)
        class MarketOrder:
            side:    str = field(converter=SIDE)
            sz:      float = field(validator=instance_of(float))
            clOrdId: str = None

        order = MarketOrder(**payload)

        if (base, quote) not in self.symbols:
            logging.warning(f'no symbol registered for {base}/{quote}')
        else:
            instId = self.symbols[(base, quote)]

            cred = {'apikey': self.cred.apiKey, 'secret': self.cred.secret, 'passphrase': self.cred.passphrase}
            async with ClientSession(base=url_rest) as session:
                async with session.post_trade_order(
                        **cred, simulated_trading=True,
                        ordType=ORD_TYPE.market, tdMode=TD_MODE.cash, instId=instId, clOrdId=order.clOrdId, side=order.side, sz=order.sz) as resp:
                    data = await resp.data()
                    #print(data)
                    for i in data.data:
                        if i.sCode == 0:
                            logger.debug(f'{i.ts} {i.ordId} ("{i.sMsg}" - {i.sCode})')
                        else:
                            print(i)

    async def on_trade_oco(self, payload, *, base, quote):
        print('on_trade_oco', payload, base, quote)

        @frozen(kw_only=True)
        class OcoOrder:
            side:        str   = field(converter=SIDE)
            sz:          float = field(validator=instance_of(float))
            tpTriggerPx: float = field(validator=instance_of(float))
            slTriggerPx: float = field(validator=instance_of(float))
            algoClOrdId: str   = None

        order = OcoOrder(**payload)
        #print('order', order)

        if (base, quote) not in self.symbols:
            logging.warning(f'no symbol registered for {base}/{quote}')
        else:
            instId = self.symbols[(base, quote)]
            #print(instId)

            cred = {'apikey': self.cred.apiKey, 'secret': self.cred.secret, 'passphrase': self.cred.passphrase}
            async with ClientSession(base=url_rest) as session:
                async with session.post_trade_order_algo(
                        **cred, simulated_trading=True,
                        ordType=ORD_TYPE.oco, tdMode=TD_MODE.cash, instId=instId, algoClOrdId=order.algoClOrdId, side=order.side, sz=order.sz,
                        tpTriggerPx=order.tpTriggerPx, slTriggerPx=order.slTriggerPx, tpOrdPx=-1, slOrdPx=-1) as resp:
                    data = await resp.data()
                    #print(data)
                    if (data.code) != 0:
                        print(data.msg)
                    else:
                        for i in data.data:
                            if i.sCode == 0:
                                logger.debug(f'{i.algoId} ("{i.sMsg}" - {i.sCode})')
                            else:
                                print(i)

    async def on_conf_inst_id(self, payload, *, base, quote):
        logging.debug(f'mapping {base}/{quote} to instId {payload}')
        k = (base, quote)
        self.symbols[k] = payload
        self.rsymbols[payload] = k

    async def on_conf_candle1m(self, payload, *, base, quote):
        print(payload, base, quote)
        k = (base, quote)
        if payload is None:
            self.candle1m.pop(k, None)
        else:
            self.candle1m[k] = payload
            #await self.ws_business.candlesticks(channel=CHANNEL.candle1m, instId=payload['instId'])

    async def on_conf_index_candle1m(self, payload, *, base, quote):
        print(payload, base, quote)
        k = (base, quote)
        if payload is None:
            self.index_candle1m.pop(k, None)
        else:
            self.index_candle1m[k] = payload
            #await self.ws_business.candlesticks(channel=CHANNEL.candle1m, instId=payload['instId'])

    async def on_mqtt_connect(self, client, userdata, flags, rc):
        print('mqtt connect')
        await self.mqtt.subscribe('inclination/config/okx/0/#')
        await self.mqtt.subscribe('inclination/trade/okx/#')
        await self.mqtt.subscribe('inclination/mailgun/notify')
        await self.mqtt.subscribe('inclination/position/okx/zigzag')

    async def on_mqtt_disconnect(self, client, userdata, rc):
        print('mqtt disconnect')

    async def on_http_get_root(self, request):
        base = 'ETH'
        quote = 'USDC'
        instId = self.symbols[(base, quote)]
        c = self.candlesticks[instId].c
        margin = 0.01
        resistence = c * (1.0 + margin)
        support = c * (1.0 - margin)
        text = f'''
<!DOCTYPE html>
<html><body>
<form method="post" action="/"><table>
<tr><th><label for"base">Base</label></th><td><input id="base" type="text" name="base" value="{base}"></td></tr>
<tr><th><label for"quote">Quote</label></th><td><input id="quote" type="text" name="quote" value="{quote}"></td></tr>
<tr><th><label for"pct">Pct</label></th><td><input id="pct" type="number" name="pct" value="2.0"></td></tr>
<tr><th><label for"tp">TP</label></th><td><input id="tp" type="number" name="takeprofit" value="{resistence}"></td></tr>
<tr><th><label for"sl">SL</label></th><td><input id="sl" type="number" name="stoploss" value="{support}"></td></tr>
</table><input type="submit" name="position" value="Long"/></form>
<form method="post" action="/"><table>
<tr><th><label for"base">Base</label></th><td><input id="base" type="text" name="base" value="{base}"></td></tr>
<tr><th><label for"quote">Quote</label></th><td><input id="quote" type="text" name="quote" value="{quote}"></td></tr>
<tr><th><label for"pct">Pct</label></th><td><input id="pct" type="number" name="pct" value="2.0"></td></tr>
<tr><th><label for"tp">TP</label></th><td><input id="tp" type="number" name="takeprofit" value="{support}"></td></tr>
<tr><th><label for"sl">SL</label></th><td><input id="sl" type="number" name="stoploss" value="{resistence}"></td></tr>
</table><input type="submit" name="position" value="Short"/></form>
</body></html>
        '''
        return web.Response(text=text, headers={'Content-Type': 'text/html'})

    async def on_http_post_root(self, request):
        if request.content_type == 'application/x-www-form-urlencoded':
            data = await request.post()

            z = {
                'position':   data['position'].lower(),
                'base':       data['base'],
                'quote':      data['quote'],
                'pct':        float(data['pct']),
                'takeprofit': float(data['takeprofit']),
                'stoploss':   float(data['stoploss']),
            }

            #await take_position(position, base, quote, pct, takeprofit, stoploss)
            await self.mqtt.publish(f'inclination/position/okx/zigzag', json.dumps(z))

            raise web.HTTPFound(location='/')
        elif request.content_type == 'application/json':
            data = await request.json()

            z = {
                'position':   data['position'],
                'base':       data['base'],
                'quote':      data['quote'],
                'pct':        data['pct'],
                'takeprofit': data['takeprofit'],
                'stoploss':   data['stoploss']
            }

            #await take_position(base, quote, pct, takeprofit, stoploss)
            await self.mqtt.publish(f'inclination/position/okx/zigzag', json.dumps(z))

            return web.Response()
        else:
            print('Err', request.content_type)

        return web.Response()

    async def on_mailgun_notify(self, payload):
        print(f'Mailgun notification: {payload}')
        #await self.mqtt.publish(f'inclination/position/okx/zigzag', json.dumps(payload))
        async with aiohttp.ClientSession() as session:
            async with session.post('http://localhost:8889/', json=payload) as resp:
                print(resp)

    async def on_position_zigzag(self, payload):
        async def market(base, quote, side, sz, clOrdId):
            z = {
                    'side': side,
                    'sz': sz,
                    'clOrdId': clOrdId,
                    }
            #print(z)
            await self.mqtt.publish(f'inclination/trade/okx/{base}/{quote}/market', json.dumps(z))

        async def oco(base, quote, side, sz, tpTriggerPx, slTriggerPx, algoClOrdId):
            z = {
                    'side': side,
                    'sz': sz,
                    'tpTriggerPx': tpTriggerPx,
                    'slTriggerPx': slTriggerPx,
                    'algoClOrdId': algoClOrdId,
                    }
            #print(z)
            await self.mqtt.publish(f'inclination/trade/okx/{base}/{quote}/oco', json.dumps(z))

        async def take_position(position, base, quote, pct, takeprofit, stoploss):
            clOrdId = uuid.uuid4().hex
            instId = self.symbols[(base, quote)]
            if position == 'long':
                from_asset = quote
                to_asset = base
                market_sz = self.balance_data[quote].cashBal * (pct / 100.0)
                market_quote_sz = market_sz / self.candlesticks[instId].c
                market_side = 'buy'
                oco_sz = market_quote_sz
                oco_side = 'sell'
                tp_sz = oco_sz * takeprofit
                sl_sz = oco_sz * stoploss
            else:
                from_asset = base
                to_asset = quote
                market_sz = self.balance_data[base].cashBal * (pct / 100.0)
                market_quote_sz = market_sz * self.candlesticks[instId].c
                market_side = 'sell'
                oco_sz = market_quote_sz
                oco_side = 'buy'
                tp_sz = oco_sz / takeprofit
                sl_sz = oco_sz / stoploss

            print(f'{base} {quote} {market_side} {market_sz} {from_asset} -> {market_quote_sz} {to_asset}')
            await market(base, quote, market_side, market_sz, clOrdId)

            print(f'{base} {quote} {oco_side} {oco_sz} {to_asset} -> {tp_sz} {from_asset} or {sl_sz} {from_asset}')
            await oco(base, quote, oco_side, oco_sz, takeprofit, stoploss, clOrdId)

        print(f'Position zigzag: {payload}')
        await take_position(**payload)

    async def on_http_startup(self, app):
        print('http startup')

    async def on_http_cleanup(self, app):
        print('http cleanup')

    async def run_http(self):
        app = web.Application()
        app.add_routes([
            web.get('/', self.on_http_get_root),
            web.post('/', self.on_http_post_root),
            ])
        app.on_startup.append(self.on_http_startup)
        app.on_cleanup.append(self.on_http_cleanup)

        runner = web.AppRunner(app, access_log=None)
        await runner.setup()
        site = web.TCPSite(runner, '0.0.0.0', 8889)
        await site.start()

        loop = asyncio.get_event_loop()
        self.http_done = loop.create_future()
        await self.http_done

        await runner.cleanup()

    async def __call__(self, *, mqtt_host, mqtt_port, mqtt_user, mqtt_passwd, credentials, interactive):
        self.interactive = interactive

        @frozen(kw_only=True)
        class Credentials:
            apiKey:     str
            secret:     str
            passphrase: str

        with open(Path.home() / '.okx' / 'okx.toml', 'rb') as f:
            config = tomllib.load(f)
            self.cred = Credentials(**config[credentials])

        url_rest = URL('https://www.okx.com/') # REST
        async with ClientSession(base=url_rest) as session:
            async with session.get_account_balance(apikey=self.cred.apiKey, secret=self.cred.secret, passphrase=self.cred.passphrase) as resp:
                pass #print(await resp.data())

        loop = asyncio.get_running_loop()
        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(self.on_sigint)()))

        await asyncio.gather(
                self.run_okx(),
                self.do_timer(),
                self.run_mqtt(mqtt_host=mqtt_host, mqtt_port=mqtt_port, mqtt_user=mqtt_user, mqtt_passwd=mqtt_passwd),
                self.run_http()
                )

    async def run_okx(self):
        await asyncio.sleep(5)
        async with ClientSession(base=url_ws) as session:
            #print(session)

            async def do_private(on_connect, on_disconnect, on_message, **kwargs):
                while not self.done:
                    async with session.private(**kwargs) as ws:
                        if on_connect:
                            await on_connect(ws)

                        async for msg in ws:
                            if on_message and msg:
                                await on_message(msg)

                        if on_disconnect:
                            await on_disconnect(ws)

                        print('Private end')

            async def do_business(on_connect, on_disconnect, on_message, **kwargs):
                while not self.done:
                    async with session.business(**kwargs) as ws:
                        if on_connect:
                            await on_connect(ws)

                        async for msg in ws:
                            if on_message and msg:
                                await on_message(msg)

                        if on_disconnect:
                            await on_disconnect(ws)

                        print('Business end')

            kwargs = {'autoping': False, 'autoclose': False, 'heartbeat': 5}

            await asyncio.gather(
                    do_private(on_connect=self.on_connect_private, on_disconnect=self.on_disconnect_private, on_message=self.on_private, **kwargs),
                    do_business(on_connect=self.on_connect_business, on_disconnect=self.on_disconnect_business, on_message=self.on_business, **kwargs),
                    )

    async def do_timer(self):
        async with async_timer.Timer(2, target=self.overview) as timer:
            async for time_rv in timer:
                if not self.done:
                    if self.interactive:
                        print(time_rv, end='', flush=True)
                else:
                    await timer.stop()

    async def run_mqtt(self, mqtt_host, mqtt_port, mqtt_user, mqtt_passwd):
        class _:
            def __init__(self, handler, regex=None, do_qos=False, do_retain=False):
                self._handler = handler
                self._regex = re.compile(regex) if regex else None
                self._do_qos = do_qos
                self._do_retain = do_retain
            async def __call__(self, client, userdata, msg):
                params = {}
                if self._do_qos:
                    params['qos'] = msg.qos
                if self._do_retain:
                    params['retain'] = msg.retain
                instance = self._regex.match(msg.topic).groupdict() if self._regex else {'topic': msg.topic}
                payload = json.loads(msg.payload) if msg.payload else None
                await self._handler(payload, **params, **instance)

        self.mqtt = mqtt.Client()
        self.mqtt.username_pw_set(username=mqtt_user, password=mqtt_passwd)
        self.mqtt.on_connect = self.on_mqtt_connect
        self.mqtt.on_disconnect = self.on_mqtt_disconnect

        self.mqtt.message_callback_add(
                'inclination/config/okx/0/+/+/candle1m',
                _(self.on_conf_candle1m, r'inclination/config/okx/0/(?P<base>[^/]+)/(?P<quote>[^/]+)/candle1m'))

        self.mqtt.message_callback_add(
                'inclination/config/okx/0/+/+/index_candle1m',
                _(self.on_conf_index_candle1m, r'inclination/config/okx/0/(?P<base>[^/]+)/(?P<quote>[^/]+)/index_candle1m'))

        self.mqtt.message_callback_add(
                'inclination/config/okx/0/+/+/inst_id',
                _(self.on_conf_inst_id, r'inclination/config/okx/0/(?P<base>[^/]+)/(?P<quote>[^/]+)/inst_id'))

        self.mqtt.message_callback_add(
                'inclination/trade/okx/+/+/market',
                _(self.on_trade_market, r'inclination/trade/okx/(?P<base>[^/]+)/(?P<quote>[^/]+)/market'))

        self.mqtt.message_callback_add(
                'inclination/trade/okx/+/+/oco',
                _(self.on_trade_oco, r'inclination/trade/okx/(?P<base>[^/]+)/(?P<quote>[^/]+)/oco'))

        self.mqtt.message_callback_add(
                'inclination/mailgun/notify',
                _(self.on_mailgun_notify, r'inclination/mailgun/notify'))

        self.mqtt.message_callback_add(
                'inclination/position/okx/zigzag',
                _(self.on_position_zigzag, r'inclination/position/okx/zigzag'))

        loop = asyncio.get_running_loop()
        self.mqtt.loop = loop

        self.mqtt_done = loop.create_future()

        await self.mqtt.connect(host=mqtt_host, port=mqtt_port)

        await self.mqtt_done

        await self.mqtt.disconnect()

    async def on_connect_private(self, ws):
        print('Connect (private)')
        self.ws_private = ws
        await ws.login(apikey=self.cred.apiKey, secret=self.cred.secret, passphrase=self.cred.passphrase)

    async def on_disconnect_private(self, ws):
        print('Disconnect (private)')
        self.ws_private = None

    async def on_connect_business(self, ws):
        print('Connect (business)')
        self.ws_business = ws
        await ws.login(apikey=self.cred.apiKey, secret=self.cred.secret, passphrase=self.cred.passphrase)
        for k, v in self.index_candle1m.items():
            await ws.index_candlestick(channel=CHANNEL.index_candle1m, instId=v['instId'])
            #await ws.index_candlestick(channel=CHANNEL.index_candle1m, instId='ETH-USD')
            #await ws.index_candlestick(channel=CHANNEL.index_candle1m, instId='USDT-USD')
            #await ws.index_candlestick(channel=CHANNEL.index_candle1m, instId='USDC-USD')
            #await ws.index_candlestick(channel=CHANNEL.index_candle1m, instId='OKB-USD')
        for k, v in self.candle1m.items():
            await ws.candlesticks(channel=CHANNEL.candle1m, instId=v['instId'])
            #await ws.candlesticks(channel=CHANNEL.candle1m, instId='ETH-USDT')
            #await ws.candlesticks(channel=CHANNEL.candle1m, instId='OKB-USDT')

    async def on_disconnect_business(self, ws):
        print('Disconnect (business)')
        self.ws_business = None


def main():
    parser = ArgumentParser()
    parser.add_argument('-H', '--mqtt-host', default=os.environ.get('MQTT_HOST', 'localhost'))
    parser.add_argument('-p', '--mqtt-port', type=int, default=os.environ.get('MQTT_PORT', 1883))
    parser.add_argument('-u', '--mqtt-user', default=os.environ.get('MQTT_USER', None))
    parser.add_argument('-P', '--mqtt-passwd', default=os.environ.get('MQTT_PASSWD', None))
    parser.add_argument('-C', '--credentials', default='okx')
    parser.add_argument(      '--interactive', action='store_true')
    args = parser.parse_args()

    x = Main()
    asyncio.run(Main()(**vars(args)))

#main()

