from enum import Enum

class EVENT(Enum):
    error              = 'error'
    subscribe          = 'subscribe'
    login              = 'login'
    orders             = 'orders'
    channel_conn_count = 'channel-conn-count'
    __repr__ = lambda self: str(self)

