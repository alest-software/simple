"""JWT Token validator using PyJWT."""

import jwt
from jwt.exceptions import (
    ExpiredSignatureError,
    InvalidSignatureError,
    InvalidIssuerError,
    InvalidAudienceError,
    DecodeError,
    InvalidTokenError,
)

from .config import JWTConfig
from .exceptions import (
    TokenExpiredError,
    TokenInvalidSignatureError,
    TokenInvalidIssuerError,
    TokenInvalidAudienceError,
    TokenMalformedError,
)


def validate_token(token: str, config: JWTConfig) -> dict:
    """Validate a JWT token and return the decoded payload.
    
    Args:
        token: The JWT token string
        config: JWT configuration
    
    Returns:
        Decoded token payload as dictionary
    
    Raises:
        TokenExpiredError: If token has expired
        TokenInvalidSignatureError: If token signature is invalid
        TokenInvalidIssuerError: If token issuer doesn't match
        TokenInvalidAudienceError: If token audience doesn't match
        TokenMalformedError: If token is malformed or invalid
    """
    try:
        # Prepare decode options
        options = {
            "verify_exp": True,
            "verify_iat": True,
            "verify_nbf": True,
            "verify_iss": config.issuer is not None,
            "verify_aud": config.audience is not None,
            "leeway": config.leeway,
        }
        
        # Get the signing key
        key = config.get_signing_key()
        
        # Decode and validate
        payload = jwt.decode(
            token,
            key,
            algorithms=[config.algorithm],
            issuer=config.issuer,
            audience=config.audience,
            options=options,
        )
        
        return payload
    
    except ExpiredSignatureError:
        raise TokenExpiredError()
    except InvalidSignatureError:
        raise TokenInvalidSignatureError()
    except InvalidIssuerError:
        raise TokenInvalidIssuerError()
    except InvalidAudienceError:
        raise TokenInvalidAudienceError()
    except (DecodeError, InvalidTokenError) as e:
        raise TokenMalformedError(str(e))