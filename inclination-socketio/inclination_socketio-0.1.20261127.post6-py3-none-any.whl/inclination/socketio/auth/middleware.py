"""SocketIO authentication middleware."""

from urllib.parse import parse_qs
from typing import Callable, Awaitable, Any

import socketio
from aiohttp import web

from .config import JWTConfig, load_config
from .validator import validate_token
from .exceptions import (
    TokenMissingError,
    TokenExpiredError,
    TokenInvalidSignatureError,
    TokenInvalidIssuerError,
    TokenInvalidAudienceError,
    TokenMalformedError,
    ConfigurationError,
)


def extract_token(environ: dict) -> str | None:
    """Extract JWT token from SocketIO handshake request.
    
    Checks in order:
    1. Authorization header (Bearer token)
    2. Query string parameter 'token'
    
    Args:
        environ: WSGI/ASGI environment dictionary
    
    Returns:
        Token string or None if not found
    """
    # 1. Check Authorization header (Bearer token)
    auth_header = environ.get("HTTP_AUTHORIZATION", "")
    if auth_header.startswith("Bearer "):
        return auth_header[7:]
    
    # 2. Check query string
    query_string = environ.get("QUERY_STRING", "")
    params = parse_qs(query_string)
    if "token" in params:
        return params["token"][0]
    
    return None


async def auth_middleware(sio: socketio.AsyncServer, config: JWTConfig | None = None) -> None:
    """Register authentication middleware on SocketIO server.
    
    This must be called before other connect handlers to ensure
    authentication runs first.
    
    Args:
        sio: SocketIO async server instance
        config: JWT configuration (loads from env if not provided)
    """
    if config is None:
        config = load_config()
    
    @sio.event
    async def connect(sid: str, environ: dict, auth: dict | None = None) -> bool | None:
        """Authenticate incoming SocketIO connection."""
        token = extract_token(environ)
        
        if token is None:
            # No token provided
            raise ConnectionRefusedError("Unauthorized: No token provided")
        
        try:
            payload = validate_token(token, config)
            # Store payload in environ for downstream handlers
            environ["jwt_payload"] = payload
            # Log successful authentication
            subject = payload.get("sub", "unknown")
            print(f"Client authenticated: {sid} (sub: {subject})")
        except TokenExpiredError:
            raise ConnectionRefusedError("Unauthorized: Token expired")
        except TokenInvalidSignatureError:
            raise ConnectionRefusedError("Unauthorized: Invalid token signature")
        except TokenInvalidIssuerError:
            raise ConnectionRefusedError("Unauthorized: Invalid issuer")
        except TokenInvalidAudienceError:
            raise ConnectionRefusedError("Unauthorized: Invalid audience")
        except TokenMalformedError as e:
            raise ConnectionRefusedError(f"Unauthorized: {e.message}")
        except ConfigurationError as e:
            # Server misconfiguration - log and refuse
            print(f"JWT configuration error: {e}")
            raise ConnectionRefusedError("Server configuration error")
        
        # Return None to continue with other connect handlers
        return None