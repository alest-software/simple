"""JWT Authorization module for Inclination SocketIO."""

from .config import JWTConfig, load_config
from .exceptions import (
    AuthError,
    TokenMissingError,
    TokenExpiredError,
    TokenInvalidSignatureError,
    TokenInvalidIssuerError,
    TokenInvalidAudienceError,
    TokenMalformedError,
    ConfigurationError,
)
from .validator import validate_token
from .middleware import auth_middleware

__all__ = [
    "JWTConfig",
    "load_config",
    "AuthError",
    "TokenMissingError",
    "TokenExpiredError",
    "TokenInvalidSignatureError",
    "TokenInvalidIssuerError",
    "TokenInvalidAudienceError",
    "TokenMalformedError",
    "ConfigurationError",
    "validate_token",
    "auth_middleware",
]