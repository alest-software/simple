"""JWT Configuration module."""

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, List

from .exceptions import ConfigurationError


@dataclass
class JWTConfig:
    """JWT configuration settings."""
    
    secret: str
    algorithm: str
    issuer: Optional[str] = None
    audience: Optional[List[str]] = None
    leeway: int = 0
    
    # Computed fields
    _public_key: Optional[str] = None
    
    @property
    def is_asymmetric(self) -> bool:
        """Check if using asymmetric algorithm (RS*)."""
        return self.algorithm.startswith("RS")
    
    @property
    def public_key(self) -> Optional[str]:
        """Get public key for asymmetric algorithms."""
        if self.is_asymmetric and self._public_key is None:
            # Load public key from file
            key_path = Path(self.secret)
            if key_path.exists():
                self._public_key = key_path.read_text()
            else:
                raise ConfigurationError(f"Public key file not found: {self.secret}")
        return self._public_key
    
    def get_signing_key(self) -> str:
        """Get the key for signing/verification."""
        if self.is_asymmetric:
            return self.public_key
        return self.secret


def load_config() -> JWTConfig:
    """Load JWT configuration from environment variables.
    
    Required:
        JWT_SECRET: Secret key (HS*) or path to public key file (RS*)
        JWT_ALGORITHM: Algorithm (default: HS256)
    
    Optional:
        JWT_ISSUER: Expected issuer claim
        JWT_AUDIENCE: Expected audience claim (comma-separated)
        JWT_LEEWAY: Clock skew tolerance in seconds (default: 0)
    
    Raises:
        ConfigurationError: If configuration is invalid
    """
    secret = os.environ.get("JWT_SECRET")
    if not secret:
        raise ConfigurationError("JWT_SECRET environment variable is required")
    
    algorithm = os.environ.get("JWT_ALGORITHM", "HS256")
    valid_algorithms = ["HS256", "HS384", "HS512", "RS256", "RS384", "RS512"]
    if algorithm not in valid_algorithms:
        raise ConfigurationError(f"Invalid JWT_ALGORITHM: {algorithm}. Must be one of {valid_algorithms}")
    
    # For RS* algorithms, secret should be a file path
    if algorithm.startswith("RS"):
        key_path = Path(secret)
        if not key_path.exists():
            raise ConfigurationError(f"Public key file not found: {secret}")
    
    issuer = os.environ.get("JWT_ISSUER")
    if issuer == "":
        issuer = None
    
    audience_str = os.environ.get("JWT_AUDIENCE")
    audience = None
    if audience_str:
        audience = [a.strip() for a in audience_str.split(",") if a.strip()]
    
    leeway_str = os.environ.get("JWT_LEEWAY", "0")
    try:
        leeway = int(leeway_str)
        if leeway < 0:
            raise ValueError
    except ValueError:
        raise ConfigurationError(f"Invalid JWT_LEEWAY: {leeway_str}. Must be a non-negative integer.")
    
    return JWTConfig(
        secret=secret,
        algorithm=algorithm,
        issuer=issuer,
        audience=audience,
        leeway=leeway,
    )