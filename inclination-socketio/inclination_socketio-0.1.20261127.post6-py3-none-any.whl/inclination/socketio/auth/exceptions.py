"""Custom exceptions for JWT authorization."""


class AuthError(Exception):
    """Base exception for authentication errors."""
    
    def __init__(self, message: str, code: str = "auth_error"):
        super().__init__(message)
        self.message = message
        self.code = code


class TokenMissingError(AuthError):
    """Raised when no token is provided."""
    
    def __init__(self):
        super().__init__("No token provided", "token_missing")


class TokenExpiredError(AuthError):
    """Raised when token has expired."""
    
    def __init__(self):
        super().__init__("Token expired", "token_expired")


class TokenInvalidSignatureError(AuthError):
    """Raised when token signature is invalid."""
    
    def __init__(self):
        super().__init__("Invalid token signature", "invalid_signature")


class TokenInvalidIssuerError(AuthError):
    """Raised when token issuer doesn't match expected."""
    
    def __init__(self):
        super().__init__("Invalid issuer", "invalid_issuer")


class TokenInvalidAudienceError(AuthError):
    """Raised when token audience doesn't match expected."""
    
    def __init__(self):
        super().__init__("Invalid audience", "invalid_audience")


class TokenMalformedError(AuthError):
    """Raised when token is malformed."""
    
    def __init__(self, message: str = "Malformed token"):
        super().__init__(message, "malformed_token")


class ConfigurationError(AuthError):
    """Raised when JWT configuration is invalid."""
    
    def __init__(self, message: str):
        super().__init__(message, "configuration_error")