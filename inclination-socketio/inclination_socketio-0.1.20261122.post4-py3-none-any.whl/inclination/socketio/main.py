"""Async SocketIO server that sends server time to clients every second."""

import asyncio
from datetime import datetime, timezone
from pathlib import Path
from aiohttp import web
import socketio

# Request logging middleware
@web.middleware
async def log_requests(request, handler):
    print(f'HTTP {request.method} {request.path}')
    return await handler(request)

# Create an async SocketIO server
sio = socketio.AsyncServer(
    async_mode='aiohttp',
    cors_allowed_origins='*',
    # Explicitly set the Socket.IO path
    path='socket.io'
)

# Create an aiohttp application
app = web.Application()
app.middlewares.append(log_requests)

# Attach Socket.IO with explicit path
sio.attach(app, socketio_path='socket.io')

# Serve static files
static_dir = Path(__file__).parent / 'static'
app.router.add_static('/static/', static_dir)
app.router.add_get('/', lambda request: web.FileResponse(static_dir / 'index.html'))

# Health check endpoint
async def health(request):
    return web.json_response({'status': 'ok', 'static_dir': str(static_dir)})

app.router.add_get('/health', health)


async def send_time():
    """Background task that emits server UTC time to all connected clients every second."""
    while True:
        current_time = datetime.now(timezone.utc).isoformat()
        await sio.emit('server_time', {'time': current_time})
        await asyncio.sleep(1)


@sio.event
async def connect(sid, environ):
    """Handle client connection."""
    print(f'Client connected: {sid}')
    print(f'  environ: {environ.get("PATH_INFO", "unknown")}')
    # Send initial UTC time immediately on connect
    current_time = datetime.now(timezone.utc).isoformat()
    await sio.emit('server_time', {'time': current_time}, room=sid)


@sio.event
async def connect_error(sid, error):
    """Handle connection errors."""
    print(f'Connection error for {sid}: {error}')


@sio.event
async def disconnect(sid):
    """Handle client disconnection."""
    print(f'Client disconnected: {sid}')


async def on_startup(app):
    """Start the background time-sending task when the application starts."""
    app['time_task'] = asyncio.create_task(send_time())


async def on_shutdown(app):
    """Cancel the background task when the application shuts down."""
    app['time_task'].cancel()
    try:
        await app['time_task']
    except asyncio.CancelledError:
        pass


# Register startup and shutdown handlers
app.on_startup.append(on_startup)
app.on_shutdown.append(on_shutdown)

def cmd():
    web.run_app(app, host='0.0.0.0', port=8080)

if __name__ == '__main__':
    # Run the server on port 8080
    cmd()
