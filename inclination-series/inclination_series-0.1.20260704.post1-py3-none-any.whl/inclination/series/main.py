import asyncio
import math
import signal
import time
from typing import Dict, Tuple

import fastdds

from inclination.idl_ex.ohlcv import (OhlcvValue, OhlcvValuePubSubType,
                                      Series, SeriesPubSubType)
from .listeners import OhlcvValueListener, SeriesListener


TOPICS = ["open", "high", "low", "close", "volume"]
NUM_SAMPLES = 512  # number of most recent kline samples to include in each batch
MAX_AGE_S = (NUM_SAMPLES + 1) * 60  # 10 minutes — klines older than this are pruned from the series


_INTERVAL_MAP = {
    "m": 60, "h": 3600, "d": 86400, "w": 604800, "M": 2592000,
}


def _interval_to_seconds(interval_id: str) -> int:
    num = int(interval_id[:-1])
    unit = interval_id[-1]
    return num * _INTERVAL_MAP[unit]


def handle_ohlcv(
    sample: OhlcvValue,
    topic: str,
    context: Dict[Tuple[str, str, str, str], Dict[int, float]],
    writers: Dict[str, fastdds.DataWriter]
) -> None:
    exchange_id = sample.exchange_id()
    symbol_id = sample.symbol_id()
    interval_id = sample.interval_id()
    timestamp = sample.timestamp()
    value = sample.value()

    context_name = topic.removesuffix('_v')

    interval = _interval_to_seconds(interval_id)

    sk = (exchange_id, symbol_id, interval_id, context_name)
    inner = context.setdefault(sk, {})
    sample_id = int(timestamp // interval)
    if inner.get(sample_id) == value:
        return

    inner[sample_id] = value

    max_sid = max(inner)
    min_sid = max_sid - NUM_SAMPLES + 1
    values = [inner.get(sid, math.nan) for sid in range(max_sid, min_sid - 1, -1)]
    vals = " ".join(f"{v:12.6f}" for v in values[:12])
    last = " ".join(f"{v:12.6f}" for v in values[-3:])
    print(f"{context_name:6s}: {exchange_id:8s} {symbol_id:8s} {interval_id:3s} [{vals} ... {last}]")

    series_topic = f"{context_name}_s"
    writer = writers.get(series_topic)
    if writer is None:
        raise RuntimeException(f"no writer for topic: '{series_topic}'")

    out = Series()
    out.exchange_id(exchange_id)
    out.symbol_id(symbol_id)
    out.interval_id(interval_id)
    out.etime(time.time())
    out.timestamp(max_sid * interval)
    out.data(values)
    writer.write(out)

    cutoff = time.time() - MAX_AGE_S
    for s in list(context):
        s_interval = _interval_to_seconds(s[2])
        for sid in list(context[s]):
            if sid * s_interval < cutoff:
                del context[s][sid]
        if not context[s]:
            del context[s]


def handle_series(
    sample: Series,
    topic: str,
    context: Dict[Tuple[str, str, str, str], Dict[int, float]],
    writers: Dict[str, fastdds.DataWriter],
) -> None:
    exchange_id = sample.exchange_id()
    symbol_id = sample.symbol_id()
    interval_id = sample.interval_id()
    values = sample.data()

    context_name = topic.removesuffix('_s')

    interval = _interval_to_seconds(interval_id)

    sk = (exchange_id, symbol_id, interval_id, context_name)
    inner = context.setdefault(sk, {})
    changed = 0
    for i, val in enumerate(values):
        if not math.isnan(val):
            sample_ts = sample.timestamp() - i * interval
            sample_id = int(sample_ts // interval)
            if sample_id not in inner: #inner.get(sample_id) is None:
                inner[sample_id] = val
                changed += 1
    if not changed:
        return

    max_sid = max(inner)
    min_sid = max_sid - NUM_SAMPLES + 1
    values = [inner.get(sid, math.nan) for sid in range(max_sid, min_sid - 1, -1)]
    vals = " ".join(f"{v:12.6f}" for v in values[:12])
    last = " ".join(f"{v:12.6f}" for v in values[-3:])
    print(f"{context_name:6s}: {exchange_id:8s} {symbol_id:8s} {interval_id:3s} [{vals} ... {last}]")

    series_topic = f"{context_name}_s"
    writer = writers.get(series_topic)
    if writer is None:
        raise RuntimeException(f"no writer for topic: '{series_topic}'")

    out = Series()
    out.exchange_id(exchange_id)
    out.symbol_id(symbol_id)
    out.interval_id(interval_id)
    out.etime(time.time())
    out.timestamp(max_sid * interval)
    out.data(values)
    writer.write(out)

    cutoff = time.time() - MAX_AGE_S
    for s in list(context):
        s_interval = _interval_to_seconds(s[2])
        for sid in list(context[s]):
            if sid * s_interval < cutoff:
                del context[s][sid]
        if not context[s]:
            del context[s]


async def main() -> None:
    loop = asyncio.get_running_loop()
    queue: asyncio.Queue = asyncio.Queue()
    shutdown = asyncio.Event()

    def handle_sigint() -> None:
        print("\nShutting down subscriber...")
        shutdown.set()

    loop.add_signal_handler(signal.SIGINT, handle_sigint)

    factory = fastdds.DomainParticipantFactory.get_instance()
    participant = factory.create_participant(0, fastdds.PARTICIPANT_QOS_DEFAULT)
    if participant is None:
        print("ERROR: Failed to create DomainParticipant")
        return

    def fail(msg: str) -> None:
        participant.delete_contained_entities()
        factory.delete_participant(participant)
        print("ERROR: " + msg)

    pubsub_type = OhlcvValuePubSubType()
    pubsub_type.set_name('value')
    ts = fastdds.TypeSupport(pubsub_type)
    if participant.register_type(ts) != fastdds.RETCODE_OK:
        return fail("Failed to register type")

    values_pubsub_type = SeriesPubSubType()
    values_pubsub_type.set_name('ohlcv_values')
    values_ts = fastdds.TypeSupport(values_pubsub_type)
    if participant.register_type(values_ts) != fastdds.RETCODE_OK:
        return fail("Failed to register Series type")

    publisher = participant.create_publisher(fastdds.PUBLISHER_QOS_DEFAULT)
    if publisher is None:
        return fail("Failed to create publisher")

    subscriber = participant.create_subscriber(fastdds.SUBSCRIBER_QOS_DEFAULT)
    if subscriber is None:
        return fail("Failed to create subscriber")

    for t in TOPICS:
        topic_name = f"{t}_v"
        topic = participant.create_topic(topic_name, pubsub_type.get_name(),
                                         fastdds.TOPIC_QOS_DEFAULT)
        if topic is None:
            return fail(f"Failed to create topic '{topic_name}'")
        reader = subscriber.create_datareader(
            topic, fastdds.DATAREADER_QOS_DEFAULT,
            OhlcvValueListener(topic_name, queue, loop))
        if reader is None:
            return fail(f"Failed to create DataReader for '{topic_name}'")

    context: Dict[Tuple[str, str, str, str], Dict[int, float]] = {}
    writers: Dict[str, fastdds.DataWriter] = {}
    for t in TOPICS:
        series_topic = f"{t}_s"
        topic_obj = participant.create_topic(
            series_topic, 'ohlcv_values', fastdds.TOPIC_QOS_DEFAULT)
        if topic_obj is None:
            return fail(f"Failed to create topic '{series_topic}'")
        reader = subscriber.create_datareader(
            topic_obj, fastdds.DATAREADER_QOS_DEFAULT,
            SeriesListener(series_topic, queue, loop))
        if reader is None:
            return fail(f"Failed to create DataReader for '{series_topic}'")
        writers[series_topic] = publisher.create_datawriter(
            topic_obj, fastdds.DATAWRITER_QOS_DEFAULT, None)
        if writers[series_topic] is None:
            return fail(f"Failed to create DataWriter for '{series_topic}'")

    print("Listening for OHLCV messages... (Ctrl+C to stop)")

    while not shutdown.is_set():
        try:
            topic, data = await asyncio.wait_for(queue.get(), timeout=1.0)
        except asyncio.TimeoutError:
            continue

        if isinstance(data, Series):
            handle_series(data, topic, context, writers)
        else:
            handle_ohlcv(data, topic, context, writers)
    participant.delete_contained_entities()
    factory.delete_participant(participant)


def cmd():
    try:
        asyncio.run(main())
    except Exception:
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    cmd()

