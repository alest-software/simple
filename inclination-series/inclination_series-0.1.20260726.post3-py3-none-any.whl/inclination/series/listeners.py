import asyncio

import fastdds

from inclination.idl_ex.ohlcv import OhlcvValue, Series


class OhlcvValueListener(fastdds.DataReaderListener):

    def __init__(
        self, topic_label: str, queue: asyncio.Queue, loop: asyncio.AbstractEventLoop
    ) -> None:
        super().__init__()
        self._topic = topic_label
        self._queue = queue
        self._loop = loop

    def on_data_available(self, reader: fastdds.DataReader) -> None:
        info = fastdds.SampleInfo()
        while True:
            data = OhlcvValue()
            result = reader.take_next_sample(data, info)
            if result == fastdds.RETCODE_OK:
                if info.valid_data:
                    self._loop.call_soon_threadsafe(
                        self._queue.put_nowait, (self._topic, data))
            elif result == fastdds.RETCODE_NO_DATA:
                break
            else:
                print(f"WARNING: take_next_sample returned {result}")
                break

    def on_subscription_matched(
        self, reader: fastdds.DataReader, info: fastdds.SubscriptionMatchedStatus
    ) -> None:
        print(f"Subscription matched ({self._topic}): "
              f"current_count={info.current_count} "
              f"current_count_change={info.current_count_change}")

    def on_requested_deadline_missed(
        self, reader: fastdds.DataReader, info: fastdds.RequestedDeadlineMissedStatus
    ) -> None:
        print(f"WARNING: Deadline missed ({self._topic}): "
              f"total_count={info.total_count} "
              f"last_instance_handle={info.last_instance_handle}")

    def on_liveliness_changed(
        self, reader: fastdds.DataReader, info: fastdds.LivelinessChangedStatus
    ) -> None:
        print(f"Liveliness changed ({self._topic}): "
              f"alive_count={info.alive_count} "
              f"not_alive_count={info.not_alive_count}")

    def on_requested_incompatible_qos(
        self, reader: fastdds.DataReader, info: fastdds.RequestedIncompatibleQosStatus
    ) -> None:
        print(f"WARNING: Incompatible QoS ({self._topic}): "
              f"total_count={info.total_count} "
              f"last_policy_id={info.last_policy_id}")

    def on_sample_rejected(
        self, reader: fastdds.DataReader, info: fastdds.SampleRejectedStatus
    ) -> None:
        print(f"WARNING: Sample rejected ({self._topic}): "
              f"total_count={info.total_count} "
              f"reason={info.last_reason}")

    def on_sample_lost(
        self, reader: fastdds.DataReader, info: fastdds.SampleLostStatus
    ) -> None:
        print(f"WARNING: Sample lost ({self._topic}): "
              f"total_count={info.total_count} "
              f"total_count_change={info.total_count_change}")


class SeriesListener(fastdds.DataReaderListener):

    def __init__(
        self, topic_label: str, queue: asyncio.Queue, loop: asyncio.AbstractEventLoop
    ) -> None:
        super().__init__()
        self._topic = topic_label
        self._queue = queue
        self._loop = loop

    def on_data_available(self, reader: fastdds.DataReader) -> None:
        info = fastdds.SampleInfo()
        while True:
            data = Series()
            result = reader.take_next_sample(data, info)
            if result == fastdds.RETCODE_OK:
                if info.valid_data:
                    self._loop.call_soon_threadsafe(
                        self._queue.put_nowait, (self._topic, data))
            elif result == fastdds.RETCODE_NO_DATA:
                break
            else:
                print(f"WARNING: take_next_sample returned {result}")
                break

    def on_subscription_matched(
        self, reader: fastdds.DataReader, info: fastdds.SubscriptionMatchedStatus
    ) -> None:
        print(f"Subscription matched ({self._topic}): "
              f"current_count={info.current_count} "
              f"current_count_change={info.current_count_change}")

    def on_requested_deadline_missed(
        self, reader: fastdds.DataReader, info: fastdds.RequestedDeadlineMissedStatus
    ) -> None:
        print(f"WARNING: Deadline missed ({self._topic}): "
              f"total_count={info.total_count} "
              f"last_instance_handle={info.last_instance_handle}")

    def on_liveliness_changed(
        self, reader: fastdds.DataReader, info: fastdds.LivelinessChangedStatus
    ) -> None:
        print(f"Liveliness changed ({self._topic}): "
              f"alive_count={info.alive_count} "
              f"not_alive_count={info.not_alive_count}")

    def on_requested_incompatible_qos(
        self, reader: fastdds.DataReader, info: fastdds.RequestedIncompatibleQosStatus
    ) -> None:
        print(f"WARNING: Incompatible QoS ({self._topic}): "
              f"total_count={info.total_count} "
              f"last_policy_id={info.last_policy_id}")

    def on_sample_rejected(
        self, reader: fastdds.DataReader, info: fastdds.SampleRejectedStatus
    ) -> None:
        print(f"WARNING: Sample rejected ({self._topic}): "
              f"total_count={info.total_count} "
              f"reason={info.last_reason}")

    def on_sample_lost(
        self, reader: fastdds.DataReader, info: fastdds.SampleLostStatus
    ) -> None:
        print(f"WARNING: Sample lost ({self._topic}): "
              f"total_count={info.total_count} "
              f"total_count_change={info.total_count_change}")
