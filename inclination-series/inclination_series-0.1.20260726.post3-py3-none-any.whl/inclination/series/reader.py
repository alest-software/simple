import asyncio
import signal
import sys

import fastdds

from inclination.idl_ex.ohlcv import Series, SeriesPubSubType
from .listeners import SeriesListener


async def main() -> None:
    if len(sys.argv) < 5:
        raise SystemExit("Usage: python -m inclination.series.reader EXCHANGE SYMBOL INTERVAL TOPIC")

    exchange, symbol, interval, topic = sys.argv[1:5]
    series_topic = f"{topic}_s"

    loop = asyncio.get_running_loop()
    queue: asyncio.Queue = asyncio.Queue()
    shutdown = asyncio.Event()

    def handle_sigint() -> None:
        print("\nShutting down reader...")
        shutdown.set()

    loop.add_signal_handler(signal.SIGINT, handle_sigint)

    factory = fastdds.DomainParticipantFactory.get_instance()
    participant = factory.create_participant(0, fastdds.PARTICIPANT_QOS_DEFAULT)
    if participant is None:
        raise RuntimeError("Failed to create DomainParticipant")

    pubsub_type = SeriesPubSubType()
    pubsub_type.set_name('ohlcv_values')
    ts = fastdds.TypeSupport(pubsub_type)
    if participant.register_type(ts) != fastdds.RETCODE_OK:
        raise RuntimeError("Failed to register Series type")

    subscriber = participant.create_subscriber(fastdds.SUBSCRIBER_QOS_DEFAULT)
    if subscriber is None:
        raise RuntimeError("Failed to create subscriber")

    topic_obj = participant.create_topic(
        series_topic, pubsub_type.get_name(), fastdds.TOPIC_QOS_DEFAULT)
    if topic_obj is None:
        raise RuntimeError(f"Failed to create topic '{series_topic}'")

    reader = subscriber.create_datareader(
        topic_obj, fastdds.DATAREADER_QOS_DEFAULT,
        SeriesListener(series_topic, queue, loop))
    if reader is None:
        raise RuntimeError(f"Failed to create DataReader for '{series_topic}'")

    print(f"Listening on '{series_topic}'... (Ctrl+C to stop)")

    while not shutdown.is_set():
        try:
            topic_name, data = await asyncio.wait_for(queue.get(), timeout=1.0)
        except asyncio.TimeoutError:
            continue

        values = ", ".join(f"{v:.6f}" for v in data.data())
        print(f"{topic_name:<30} "
              f"{data.exchange_id():<8} "
              f"{data.symbol_id():<10} "
              f"{data.interval_id():<6} "
              f"{data.timestamp():>10} "
              f"{data.etime():>14.3f} "
              f"[{values}]")

    participant.delete_contained_entities()
    factory.delete_participant(participant)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception:
        import traceback
        traceback.print_exc()
