def main():
    print(f'main')
