
from attr import define
try:
    from .symbol import *
    from .level import *
    from .updatespeed import *
    from .stream import *
except ImportError:
    from symbol import *
    from level import *
    from updatespeed import *
    from stream import *


@define(kw_only=True)
class Subscription:
    ws: int
    cb: int

    async def subscribe(self):
        await self.ws.do_subscribe(subscription=self)

    async def unsubscribe(self):
        await self.ws.do_unsubscribe(subscription=self)

    async def __call__(self, msg):
        rc = await self.cb(msg, self)
        return rc


@define(kw_only=True)
class AggregateTradeSubscription(Subscription):
    #stream: AggregateTradeStream
    symbol: Symbol

    def get_stream(self):
        return AggregateTradeStream(symbol=self.symbol)

    def getWsName(self):
        return f'{self.symbol.getStreamName()}@aggTrade'


@define(kw_only=True)
class TradeSubscription(Subscription):
    #stream: TradeStream
    symbol: Symbol

    def get_stream(self):
        return TradeStream(symbol=self.symbol)

    def getWsName(self):
        return f'{self.symbol.getStreamName()}@trade'


@define(kw_only=True)
class KlineCandlestickSubscription(Subscription):
    #stream: KlineCandlestickStream
    symbol: Symbol
    interval: Interval

    def get_stream(self):
        return KlineCandlestickStream(symbol=self.symbol, interval=self.interval)

    def getWsName(self):
        return f'{self.symbol.getStreamName()}@kline_{self.interval}'


@define(kw_only=True)
class IndividualSymbolMiniTickerSubscription(Subscription):
    #stream: IndividualSymbolMiniTickerStream
    symbol: Symbol

    def get_stream(self):
        return IndividualSymbolMiniTickerStream(symbol=self.symbol)

    def getWsName(self):
        return f'{self.symbol.getStreamName()}@miniTicker'


@define(kw_only=True)
class AllMarketMiniTickersSubscription(Subscription):
    #stream: AllMarketMiniTickersStream

    def get_stream(self):
        return AllMarketMiniTickersStream()

    def getWsName(self):
        return '!miniTicker@arr'


@define(kw_only=True)
class IndividualSymbolTickerSubscription(Subscription):
    #stream: IndividualSymbolTickerStream
    symbol: Symbol

    def get_stream(self):
        return IndividualSymbolTickerStream(symbol=self.symbol)

    def getWsName(self):
        return f'{self.symbol.getStreamName()}@ticker'


@define(kw_only=True)
class AllMarketTickersSubscription(Subscription):
    #stream: AllMarketTickersStream

    def get_stream(self):
        return AllMarketTickersStream()

    def getWsName(self):
        return '!ticker@arr'


@define(kw_only=True)
class IndividualSymbolBookTickerSubscription(Subscription):
    #stream: IndividualSymbolBookTickerStream
    symbol: Symbol

    def get_stream(self):
        return IndividualSymbolBookTickerStream(symbol=self.symbol)

    def getWsName(self):
        return f'{self.symbol.getStreamName()}@bookTicker'


@define(kw_only=True)
class PartialBookDepthSubscription(Subscription):
    #stream: PartialBookDepthStream
    symbol: Symbol
    level: Level
    rate: UpdateSpeed

    def get_stream(self):
        return PartialBookDepthStream()

    def getWsName(self):
        return f'{self.symbol.getStreamName()}@depth{self.level}@{self.rate}'


@define(kw_only=True)
class DiffDepthSubscription(Subscription):
    #stream: DiffDepthStream
    rate: UpdateSpeed
    symbol: Symbol

    def get_stream(self):
        return DiffDepthStream(symbol=self.symbol)

    def getWsName(self):
        return f'{self.symbol.getStreamName()}@depth@{self.rate}'

