import math

nan = float('nan')
inf = float('inf')

class DownScaler:
    def __init__(self, period):
        self._period = period
        self._open = nan
        self._high = 0.0
        self._low = inf
        self._volume = 0.0
        
    def __call__(self, timestamp, open_time, close_time, open, high, low, close, volume, last_candle):
        timestamp = close_time if timestamp > close_time else timestamp
        close_time = int(close_time + .1)
        a1 = timestamp // self._period
        _open_time = (a1 * self._period)
        _close_time = int((a1 + 1) * self._period)
        _last_candle = last_candle & (close_time == _close_time)
        _close_time = _close_time - .001
        
        if math.isnan(self._open):
            self._open = open
        _open = self._open
        
        self._high = max(self._high, high)
        _high = self._high
        
        self._low = min(self._low, low)
        _low = self._low
        
        self._volume += volume
        _volume = self._volume
        
        if _last_candle:
            self._open = nan
            self._high = 0.0
            self._low = inf
            self._volume = 0.0

        return [_open_time, _close_time, _last_candle, _open, _high, _low, close, _volume]
