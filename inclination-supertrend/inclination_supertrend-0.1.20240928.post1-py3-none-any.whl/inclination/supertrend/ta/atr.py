import math

nan = float('nan')

class AverageTrueRange:
    def __init__(self, length=10):
        self._length = length
        self._window = []
        self._prev_atr = nan
    
    def __call__(self, true_range, store=True):
        if not math.isnan(self._prev_atr):
            atr = ((self._prev_atr * (self._length - 1)) + true_range) / self._length
        else:
            if len(self._window) < self._length-1:
                if not math.isnan(true_range):
                    self._window.append(true_range)
                atr = math.nan
            else:
                self._window.append(true_range)
                atr = sum(self._window) / len(self._window)
                
        if store:
            self._prev_atr = atr
            
        return atr

