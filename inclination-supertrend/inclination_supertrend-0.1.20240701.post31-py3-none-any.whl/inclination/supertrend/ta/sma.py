nan = float('nan')

class SimpleMovingAverage:
    def __init__(self, length=9):
        self._length = length
        self._window = []
        
    def __call__(self, close, store=True):
        window = self._window
        if len(window) < self._length-1:
            window.append(close)
            sma = nan
        else:
            window = [*window[-(self._length-1):], close]
            sma = sum(window) / len(window)
            
        if store:
            self._window = window
        
        return sma

