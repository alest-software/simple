import math

nan = float('nan')

class ExponentialMovingAverage:
    def __init__(self, length=10, smoothing=2):
        self._length = length
        self._smoothing = smoothing
        self._ema = nan
    
    def __call__(self, close, sma, store=True):
        weight = self._smoothing / (self._length + 1)
        if math.isnan(self._ema):
            ema = sma
        else:
            ema = (close * weight) + (self._ema * (1 - weight))
            
        if store:
            self._ema = ema

        return ema

