from typing import TypeVar, Generic, Type
from enum import Enum, auto
from attrs import define, frozen, field
from attrs.validators import instance_of


T = TypeVar('T')


#class PingResponse:
#    def __str__(self):
#        return f'{type(self).__name__}()'


#@frozen(kw_only=True)
#class TimeResponse:
#    serverTime: float = field(converter=lambda x: float(x) / 1000.0)


class OrderType(Enum):
    LIMIT = auto()
    LIMIT_MAKER = auto()
    MARKET = auto()
    STOP_LOSS = auto()
    STOP_LOSS_LIMIT = auto()
    TAKE_PROFIT = auto()
    TAKE_PROFIT_LIMIT = auto()


class SymbolFilterType(Enum):
    PRICE_FILTER = auto()
    PERCENT_PRICE = auto()
    PERCENT_PRICE_BY_SIDE = auto()
    LOT_SIZE = auto()
    MIN_NOTIONAL = auto()
    NOTIONAL = auto()
    ICEBERG_PARTS = auto()
    MARKET_LOT_SIZE = auto()
    MAX_NUM_ORDERS = auto()
    MAX_NUM_ALGO_ORDERS = auto()
    MAX_NUM_ICEBERG_ORDERS = auto()
    MAX_POSITION = auto()
    TRAILING_DELTA = auto()
 

@frozen(kw_only=True)
class SymbolFilter:
    filterType: SymbolFilterType = field(converter=lambda x: SymbolFilterType[x])
    minPrice: str = None
    maxPrice: str = None
    tickSize: str = None

    multiplierUp: str = None
    multiplierDown: str = None
    avgPriceMins: int = None

    bidMultiplierUp: str = None
    bidMultiplierDown: str = None
    askMultiplierUp: str = None
    askMultiplierDown: str = None
    #avgPriceMins = None

    minQty: str = None
    maxQty: str = None
    stepSize: str = None

    minNotional: str = None
    applyToMarket: bool = None
    # avgPriceMins = None

    #minNotional: str = None
    applyMinToMarket: bool = None
    maxNotional: str = None
    applyMaxToMarket: bool = None
    #avgPriceMins = None

    limit: int = None

    #minQty = None
    #maxQty = None
    #stepSize = None

    maxNumOrders: int = None

    maxNumIcebergOrders: int = None

    maxNumAlgoOrders: int = None

    maxPosition: str = None

    minTrailingAboveDelta: int = None
    maxTrailingAboveDelta: int = None
    minTrailingBelowDelta: int = None
    maxTrailingBelowDelta: int = None


class Permission(Enum):
    NONE = auto()


class PermissionSet(Enum):
    SPOT = auto()
    MARGIN = auto()


class SelfTradePreventionMode(Enum):
    NONE = auto
    EXPIRE_MAKER = auto()
    EXPIRE_TAKER = auto()
    EXPIRE_BOTH = auto()


@frozen(kw_only=True)
class SymbolInfo:
    symbol:                          str
    status:                          str
    baseAsset:                       str
    baseAssetPrecision:              int
    quoteAsset:                      str
    quotePrecision:                  int
    quoteAssetPrecision:             int
    baseCommissionPrecision:         int
    quoteCommissionPrecision:        int
    orderTypes:                      list = field(converter=lambda x: [OrderType[i] for i in x])
    icebergAllowed:                  bool
    ocoAllowed:                      bool
    otoAllowed:                      bool
    quoteOrderQtyMarketAllowed:      bool
    allowTrailingStop:               bool
    cancelReplaceAllowed:            bool
    isSpotTradingAllowed:            bool
    isMarginTradingAllowed:          bool
    filters:                         list = field(converter=lambda x: [SymbolFilter(**i) for i in x])
    permissions:                     list = field(converter=lambda x: [Permission[i] for i in x])
    permissionSets:                  list # = field(converter=lambda x: [PermissionSet[i] for i in x]) # List of lists...
    defaultSelfTradePreventionMode:  str
    allowedSelfTradePreventionModes: list = field(converter=lambda x: [SelfTradePreventionMode[i] for i in x])


class RateLimitType(Enum):
    REQUEST_WEIGHT = auto()
    ORDERS = auto()
    RAW_REQUESTS = auto()


class RateLimitInterval(Enum):
    SECOND = auto()
    MINUTE = auto()
    DAY = auto()


@frozen(kw_only=True)
class RateLimit:
    rateLimitType: RateLimitType = field(converter=lambda x: RateLimitType[x])
    interval:      RateLimitInterval = field(converter=lambda x: RateLimitInterval[x])
    intervalNum:   int
    limit:         int


class ExchangeFilterType(Enum):
    EXCHANGE_MAX_NUM_ORDERS = auto()
    EXCHANGE_MAX_NUM_ALGO_ORDERS = auto()
    EXCHANGE_MAX_NUM_ICEBERG_ORDERS = auto()


@frozen(kw_only=True)
class ExchangeFilter:
    filterType:          ExchangeFilterType = field(converter=lambda x: ExchangeFilterType[x])
    maxNumOrders:        int = None
    maxNumAlgoOrders:    int = None
    maxNumIcebergOrders: int = None


@frozen(kw_only=True)
class ExchangeInfo:
    timezone:        str = field(validator=instance_of(str))
    serverTime:      int = field(converter=lambda x: float(x) / 1000.0)
    rateLimits:      list = field(converter=lambda x: [RateLimit(**i) for i in x])
    exchangeFilters: list = field(converter=lambda x: [ExchangeFilter(**i) for i in x])
    symbols:         list = field(converter=lambda x: [SymbolInfo(**i) for i in x])


@frozen(order=True)
class Depth:  
    price:    float = field(converter=float)
    quantity: float = field(converter=float)


@frozen(kw_only=True)
class DepthResponse(list):
    lastUpdateId: int
    bids:         list = field(converter=lambda x: [Depth(*i) for i in x])
    asks:         list = field(converter=lambda x: [Depth(*i) for i in x])


@frozen(kw_only=True)
class TimeResponse:
    serverTime: float = field(converter=lambda x: float(x) / 1000.0)


class PingResponse:
    def __str__(self):
        return f'{type(self).__name__}()'


@frozen(order=True)
class KlinesResponseItem:
    time_open:        float = field(converter=lambda x: float(x) / 1000.0)  # Convert from int
    open:             float = field(converter=float)                        # Convert from str
    high:             float = field(converter=float)                        # Convert from str
    low:              float = field(converter=float)                        # Convert from str
    close:            float = field(converter=float)                        # Convert from str
    volume:           float = field(converter=float)                        # Convert from str
    close_time:       float = field(converter=lambda x: float(x) / 1000.0)  # Convert from int
    quote_asset:      float = field(converter=float)                        # Convert from str
    nof_trades:       int   = field (validator=instance_of(int))
    buy_base_volume:  float = field(converter=float)                        # Convert from str
    buy_quote_volume: float = field(converter=float)                        # Convert from str
    unused:           str


class KlinesResponse(list):
    pass


#@frozen(kw_only=True)
#class ErrorResponse:
#    code: int
#    msg: str

