from attrs import define, frozen, field
from attrs.validators import instance_of
#import aiohttp
from yarl import URL
from ..context_manager import BinanceRequestContextManager
from ..type import *


@frozen(kw_only=True)
class BinanceDepthResponse:
    response: int

    async def data(self):
        json = await self.response.json()
        return DepthResponse(**json)


@frozen(kw_only=True)
class DepthRequest:
    base: URL
    symbol: str
    limit: int = None

    def __call__(self, session):
        url = self.base / 'v3/depth'
        headers = {'Accept': 'application/json'}
        params = {
                **({'symbol': self.symbol}),
                **({'limit': self.limit} if self.limit else {}),
                }
        return BinanceRequestContextManager[BinanceDepthResponse](
                session.get(url, headers=headers, params=params),
                BinanceDepthResponse)

