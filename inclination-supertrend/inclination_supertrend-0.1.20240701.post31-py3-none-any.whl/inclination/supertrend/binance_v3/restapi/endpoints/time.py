from attrs import define, frozen, field
#from attrs.validators import instance_of
from yarl import URL
from ..context_manager import BinanceRequestContextManager
from ..type import *


@frozen(kw_only=True)
class BinanceTimeResponse:
    response: int

#    def __getattr__(self, method):
#        return getattr(self.response, method)

    async def data(self):
        json = await self.response.json()
        return TimeResponse(**json)


@frozen(kw_only=True)
class TimeRequest:
    base: URL

    def __call__(self, session):
        url = self.base / 'v3/time'
        headers = {'Accept': 'application/json'}
        return BinanceRequestContextManager[BinanceTimeResponse](
                session.get(url, headers=headers),
                BinanceTimeResponse)

