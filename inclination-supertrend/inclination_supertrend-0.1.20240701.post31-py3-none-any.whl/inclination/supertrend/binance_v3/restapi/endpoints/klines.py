from attrs import define, frozen, field
from attrs.validators import instance_of
from yarl import URL
from ..context_manager import BinanceRequestContextManager
from ..type import *


@frozen(kw_only=True)
class BinanceKlinesResponse:
    response: int

    async def data(self):
        json = await self.response.json()
        return KlinesResponse([KlinesResponseItem(*x) for x in json])


@frozen(kw_only=True)
class KlinesRequest:
    base: URL
    symbol: str
    interval: str
    startTime: str = None
    endTime: str = None
    timeZone: str = None
    limit: str = None

    def __call__(self, session):
        url = self.base / 'v3/klines'
        headers = {'Accept': 'application/json'}
        params = {
                **({'symbol': self.symbol, 'interval': self.interval}),
                **({'startTime': self.startTime} if self.startTime else {}),
                **({'endTime': self.endTime} if self.endTime else {}),
                **({'timeZone': self.timeZone} if self.timeZone else {}),
                **({'limit': self.limit} if self.limit else {}),
                }
        return BinanceRequestContextManager[BinanceKlinesResponse](
                session.get(url, headers=headers, params=params),
                BinanceKlinesResponse)

