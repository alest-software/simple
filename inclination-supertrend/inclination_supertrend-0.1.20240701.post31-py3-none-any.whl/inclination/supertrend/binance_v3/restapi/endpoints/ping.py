from attrs import frozen, field
from yarl import URL
from ..context_manager import BinanceRequestContextManager
from ..type import *


@frozen(kw_only=True)
class BinancePingResponse:
    response: int

#    def __getattr__(self, method):
#        return getattr(self.response, method)

    async def data(self):
        json = await self.response.json()
        return PingResponse(**json)


@frozen(kw_only=True)
class PingRequest:
    base: URL

    def __call__(self, session):
        url = self.base / 'v3/ping'
        headers = {'Accept': 'application/json'}
        return BinanceRequestContextManager[BinancePingResponse](
                session.get(url, headers=headers),
                BinancePingResponse)

