from typing import TypeVar, Generic, Type
from enum import Enum, auto
from attrs import define, frozen, field
from attrs.validators import instance_of
import aiohttp
from yarl import URL
from .context_manager import BinanceRequestContextManager
from .endpoints.ping import PingRequest
from .endpoints.time import TimeRequest
from .endpoints.klines import KlinesRequest
from .endpoints.depth import DepthRequest
from .endpoints.exchange_info import ExchangeInfoRequest


T = TypeVar('T')


@frozen(kw_only=True)
class BinanceClientSession:
    session: aiohttp.ClientSession = field(factory=aiohttp.ClientSession)
    base: URL = field(default=URL('https://api.binance.com/api'))

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_value, exc_tb):
        await self.close()

    async def close(self):
        await self.session.close()

#    def __getattr__(self, method):
#        return getattr(self.session, method)

    def ping(self):
        return PingRequest(base=self.base)(self.session)

    def time(self):
        return TimeRequest(base=self.base)(self.session)

    def exchangeInfo(self, *, symbol=None):
        return ExchangeInfoRequest(base=self.base)(self.session)

    def depth(self, *, symbol, limit=None):
        return DepthRequest(base=self.base, symbol=symbol, limit=limit)(self.session)

    def klines(self, *, symbol, interval, startTime=None, endTime=None, timeZone=None, limit=None):
        return KlinesRequest(base=self.base, symbol=symbol, interval=interval, startTime=startTime, endTime=endTime, timeZone=timeZone, limit=limit)(self.session)

