import numpy as np

class SuperTrend:
    def __init__(self, multiplier=3):
        self._multiplier = multiplier
        self._value = np.nan
        self._direction = 1
        
    def __call__(self, high, low, close, atr, store=True):
        direction = self._direction
        upper = (high + low) / 2 + self._multiplier * atr
        lower = (high + low) / 2 - self._multiplier * atr

        if self._direction > 0:
            value = lower if np.isnan(self._value) else max(self._value, lower)
            if close < value:
                direction = -1
                value = upper
        else:
            value = upper if np.isnan(self._value) else min(self._value, upper)
            if close > value:
                direction = 1
                value = lower

        support = value if direction > 0 else np.nan
        resistence = value if direction < 0 else np.nan
         
        if store:
            self._value = value
            self._direction = direction
        
        return [value, direction, support, resistence]

