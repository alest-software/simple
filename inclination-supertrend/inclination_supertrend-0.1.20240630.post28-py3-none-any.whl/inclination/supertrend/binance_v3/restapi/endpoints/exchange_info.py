from attrs import define, frozen, field
from attrs.validators import instance_of
from yarl import URL
from ..context_manager import BinanceRequestContextManager
from ..type import *


@frozen(kw_only=True)
class BinanceExchangeInfoResponse:
    response: int

#    def __getattr__(self, method):
#        return getattr(self.response, method)

    async def data(self):
        json = await self.response.json()
        return ExchangeInfo(**json)


@frozen(kw_only=True)
class ExchangeInfoRequest:
    base: URL
    symbol: str = None

    def __call__(self, session):
        url = self.base / 'v3/exchangeInfo'
        headers = {'Accept': 'application/json'}
        params = {
                **({'symbol': self.symbol} if self.symbol else {})
                }
        return BinanceRequestContextManager[BinanceExchangeInfoResponse](
                session.get(url, headers=headers, params=params),
                BinanceExchangeInfoResponse)

