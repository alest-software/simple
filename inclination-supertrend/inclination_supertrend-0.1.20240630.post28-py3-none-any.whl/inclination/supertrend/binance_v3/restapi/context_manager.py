from typing import TypeVar, Generic, Type
from attrs import frozen, field
import aiohttp


T = TypeVar('T')


@frozen
class BinanceRequestContextManager(Generic[T]):
    request_context_manager: aiohttp.ClientResponse #= field(validator=instance_of(aiohttp.ClientResponse))
    BinanceResponse: Type[T]

    async def __aenter__(self):
        response = await self.request_context_manager.__aenter__()
        return self.BinanceResponse(response=response)

    async def __aexit__(self, exc_type, exc_value, exc_tb):
        await self.request_context_manager.__aexit__(exc_type, exc_value, exc_tb)

