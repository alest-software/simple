#!/usr/bin/env python3

import urllib
import hmac
import hashlib
import asyncio
import aiohttp
from pprint import pprint
from enum import Enum
from .errors import *
from .filters import *
from .enums import *


class Response():
    def __init__(self):
        pass

    async def execute(self, callback):
        return await callback(self)

    def __repr__(self):
        return '({0}){1}'.format(type(self).__name__, vars(self))


class CodeResponse(Response):
    def __init__(self, code, msg):
        self._code = code
        self._msg = msg

    def errorCode(self):
        return ErrorCode(self._code)

    def msg(self):
        return self._msg


class Request():
    def __init__(self, session):
        self._session = session

    def headers(self):
        return None

    def params(self):
        return None

    def getParameterString(self):
        params = self.params()
        if not params is None:
            totalParams = urllib.parse.urlencode(params)
            return totalParams
        return None

    async def get(self, endpoint, callback):
        url = 'https://api.binance.com/api/v3/{0}'.format(endpoint)
        headers = self.headers()
        queryString = self.getParameterString()
        if not queryString is None:
            url = '{0}?{1}'.format(url, queryString)
        async with self._session.get(url, headers=headers) as resp:
            res = await resp.json()
            return await self.checkResult(res, callback)

    async def post(self, endpoint, callback):
        url = 'https://api.binance.com/api/v3/{0}'.format(endpoint)
        headers = self.headers()
        requestBody = self.getParameterString()
        print(self)
        async with self._session.post(url, data=requestBody, headers=headers) as resp:
            json = await resp.json()
            return await self.checkResult(json, callback)

    async def put(self, endpoint, callback):
        url = 'https://api.binance.com/api/v3/{0}'.format(endpoint)
        headers = self.headers()
        requestBody = self.getParameterString()
        async with self._session.put(url, data=requestBody, headers=headers) as resp:
            res = await resp.json()
            return await self.checkResult(res, callback)

    async def delete(self, endpoint, callback):
        url = 'https://api.binance.com/api/v3/{0}'.format(endpoint)
        headers = self.headers()
        requestBody = self.getParameterString()
        async with self._session.delete(url, data=requestBody, headers=headers) as resp:
            res = await resp.json()
            return await self.checkResult(res, callback)

    async def checkResult(self, res, callback):
        if 'code' in res and 'msg' in res:
            r = CodeResponse(**res)
            raise codeErrorFactory(r)
        return await self.result(res, callback)

    async def result(self, res, callback):
        print(res)
        raise Exception()

    def __repr__(self):
        return '({0}){1}'.format(type(self).__name__, vars(self))


class TradeRequest(Request):
    def __init__(self, session, apiKey, secret):
        self._apiKey = apiKey
        self._secret = secret
        super().__init__(session)

    def headers(self):
        return { 'X-MBX-APIKEY': self._apiKey }

    def getParameterString(self):
        totalParams = super().getParameterString()
        signature = hmac.new(bytes(self._secret, 'latin-1'), msg=bytes(totalParams, 'latin-1'), digestmod=hashlib.sha256).hexdigest()
        return '{0}&signature={1}'.format(totalParams, signature)


class UserDataRequest(Request):
    def __init__(self, session, apiKey, secret):
        self._apiKey = apiKey
        self._secret = secret
        super().__init__(session)

    def headers(self):
        return { 'X-MBX-APIKEY': self._apiKey }

    def getParameterString(self):
        totalParams = super().getParameterString()
        signature = hmac.new(bytes(self._secret, 'latin-1'), msg=bytes(totalParams, 'latin-1'), digestmod=hashlib.sha256).hexdigest()
        return '{0}&signature={1}'.format(totalParams, signature)


class UserStreamRequest(Request):
    def __init__(self, session, apiKey):
        self._apiKey = apiKey
        super().__init__(session)

    def headers(self):
        return { 'X-MBX-APIKEY': self._apiKey }


class MarketDataRequest(Request):
    def __init__(self, session, apiKey):
        self._apiKey = apiKey
        super().__init__(session)

    def headers(self):
        return { 'X-MBX-APIKEY': self._apiKey }


class PingRequest(Request):
    def __init__(self, session):
        super().__init__(session)

    async def execute(self, callback):
        await self.get('ping', callback)

    async def result(self, res, callback):
        pass


class TimeResponse(Response):
    def __init__(self, serverTime):
        self._serverTime = serverTime

#    def __str__(self):
#        return '<< serverTime: {0} >>'.format(self._serverTime)


class TimeRequest(Request):
    def __init__(self, session):
        super().__init__(session)

    async def execute(self, callback):
        await self.get('time', callback)

    async def result(self, res, callback):
        await TimeResponse(**res).execute(callback)


class ExchangeInfoResponse(Response):
    class SymbolInfo():
        def __init__(self, symbol, status, baseAsset, baseAssetPrecision, quoteAsset, quoteAssetPrecision, quotePrecision, baseCommissionPrecision, quoteCommissionPrecision, orderTypes, icebergAllowed, ocoAllowed, quoteOrderQtyMarketAllowed, isSpotTradingAllowed, isMarginTradingAllowed, filters, permissions):
            self._symbol = symbol
            self._status = status
            self._baseAsset = baseAsset
            self._baseAssetPrecision = baseAssetPrecision
            self._quoteAsset = quoteAsset
            self._quotePrecision = quotePrecision
            self._baseCommissionPrecision = baseCommissionPrecision
            self._quoteCommissionPrecision = quoteCommissionPrecision
            #[] self._orderTypes = orderTypes
            self._icebergAllowed = icebergAllowed
            self._ocoAllowed = ocoAllowed
            self._quoteOrderQtyMarketAllowed = quoteOrderQtyMarketAllowed
            self._isSpotTradingAllowed = isSpotTradingAllowed
            self._isMarginTradingAllowed = isMarginTradingAllowed
            self._filters = {}
            for f in filters:
                fname = FilterType.from_str(f['filterType'])
                self._filters[fname] = filterFactory(**f)

        def __repr__(self):
            return '{0}'.format(self._symbol)

    def __init__(self, timezone, serverTime, rateLimits, exchangeFilters, symbols):
        self._timezone = timezone
        self._serverTime = serverTime
        #[] self._rateLimits = rateLimits
        #[] self._exchangeFilters = exchangeFilters
        self._symbols = []
        for symbol in symbols:
            self._symbols.append(ExchangeInfoResponse.SymbolInfo(**symbol))

#    def __repr__(self):
#        return '<<{0},{1},{2}>>'.format(self._timezone, self._serverTime, self._symbols)


class ExchangeInfoRequest(Request):
    def __init__(self, session):
        super().__init__(session)

    async def execute(self, callback):
        await self.get('exchangeInfo', callback)

    async def result(self, res, callback):
        await ExchangeInfoResponse(**res).execute(callback)


class KlinesResponse(Response):
    def __init__(self, klines):
        #super().__init__(session)
        self._klines = klines


class KlinesRequest(Request):
    def __init__(self, session, symbol, interval, start_time=None, end_time=None, limit=None):
        super().__init__(session)
        self._symbol = symbol
        self._interval = interval
        self._start_time = start_time
        self._end_time = end_time
        self._limit = limit

    def params(self):
        params = {
            'symbol': self._symbol,
            'interval': self._interval
        }
        if not self._start_time is None:
            params['start_time'] = self._start_time
        if not self._end_time is None:
            params['end_time'] = self._end_time
        if not self._limit is None:
            params['limit'] = self._limit
        return params

    async def execute(self, callback):
        return await self.get('klines', callback)

    async def result(self, res, callback):
        await KlinesResponse(res).execute(callback)


class NewOrderResponse(Response):
    class Fill():
        def __init__(self, price, qty, commission, commissionAsset):
            self._price = float(price)
            self._qty = float(qty)
            self._commission = float(commission)
            self._commissionAsset = commissionAsset

    def __init__(self,
            symbol, orderId, orderListId, clientOrderId, transactTime,
            price = None, origQty = None, executedQty = None, cummulativeQty = None, status = None, timeInForce = None, type = None, side = None,
            fills = None,
            **ext):
        self._symbol = symbol
        self._orderId = int(orderId)
        self._orderListId = int(orderListId)
        self._clientOrderId = clientOrderId
        self._transactTime = transactTime / 1000.0
        self._price = float(price) if not price is None else None
        self._origQty = float(origQty) if not origQty is None else None
        self._executedQty = float(executedQty) if not executedQty is None else None
        self._cummulativeQty = float(cummulativeQty) if not cummulativeQty is None else None
        self._status = OrderStatus(status) if not status is None else None
        self._timeInForce = TimeInForce(timeInForce) if not timeInForce is None else None
        self._type = OrderType(type) if not type is None else None
        self._side = OrderSide(side) if not side is None else None
        self._fills = fills
        self._ext = ext
        super().__init__()

#    def __repr__(self):
#        return '<<{0}>>'.format(self._ext)


class NewOrderRequest(TradeRequest):
    def __init__(self, session, apiKey, secret,
            symbol,
            orderSide,
            orderType,
            timestamp,
            timeInForce=None,
            quantity=None,
            quoteOrderQty=None,
            price=None,
            newClientOrderId=None,
            stopPrice=None,
            icebergQty=None,
            newOrderRespType=None,
            recvWindow=None
            ):
        self._symbol = symbol
        self._orderSide = orderSide
        self._orderType = orderType
        self._timestamp = timestamp
        self._timeInForce = timeInForce
        self._quantity = quantity
        self._quoteOrderQty = quoteOrderQty
        self._price = price
        self._newClientOrderId = newClientOrderId
        self._stopPrice = stopPrice
        self._icebergQty = icebergQty
        self._newOrderRespType = newOrderRespType
        self._recvWindow = recvWindow
        super().__init__(session, apiKey, secret)

    def params(self):
        params = {
            'symbol': self._symbol,
            'side': str(self._orderSide),
            'type': str(self._orderType),
            'timestamp': int(self._timestamp * 1000)
        }
        if not self._timeInForce is None:
            params['timeInForce'] = str(self._timeInForce)
        if not self._quantity is None:
            params['quantity'] = self._quantity
        if not self._quoteOrderQty is None:
            params['quoteOrderQty'] = self._quoteOrderQty
        if not self._price is None:
            params['price'] = '{0:.8f}'.format(self._price)
        if not self._newClientOrderId is None:
            params['newClientOrderId'] = self._newClientOrderId
        if not self._stopPrice is None:
            params['stopPrice'] = self._stopPrice
        if not self._icebergQty is None:
            params['icebergQty'] = self._icebergQty
        if not self._newOrderRespType is None:
            params['newOrderRespType'] = str(self._newOrderRespType)
        if not self._recvWindow is None:
            params['recvWindow'] = self._recvWindow
        return params

    async def execute(self, callback):
        return await self.post('order', callback)

    async def result(self, res, callback):
        return await NewOrderResponse(**res).execute(callback)


class QueryOrderResponse(Response):
    def __init__(self, symbol, orderId, orderListId, clientOrderId, price, origQty, executedQty, cummulativeQuoteQty, status, timeInForce, type, side, stopPrice, icebergQty, time, updateTime, isWorking, origQuoteOrderQty, **ext):
        self._symbol = symbol
        self._orderId = int(orderId)
        self._orderListId = int(orderListId)
        self._clientOrderId = clientOrderId
        self._price = float(price)
        self._origQty = float(origQty)
        self._executedQty = float(executedQty)
        self._cummulativeQuoteQty = float(cummulativeQuoteQty)
        self._status = OrderStatus(status)
        self._timeInForce = TimeInForce(timeInForce)
        self._type = OrderType(type)
        self._side = OrderSide(side)
        self._stopPrice = float(stopPrice)
        self._icebergQty = float(icebergQty)
        self._time = time / 1000.0
        self._updateTime = updateTime / 1000.0
        self._isWorking = bool(isWorking)
        self._origQuoteOrderQty = float(origQuoteOrderQty)
        self._ext = ext
        super().__init__()

#    def __repr__(self):
#        return '<<{0}>>'.format(vars(self))


class QueryOrderRequest(UserDataRequest):
    def __init__(self, session, apiKey, secret, symbol, timestamp, orderId=None, origClientOrderId=None, recvWindow=None):
        self._symbol = symbol
        self._orderId = orderId
        self._origClientOrderId = origClientOrderId
        self._recvWindow = recvWindow
        self._timestamp = timestamp
        super().__init__(session, apiKey, secret)

    def params(self):
        params = {
            'symbol': self._symbol,
            'timestamp': int(self._timestamp * 1000)
        }
        if not self._orderId is None:
            params['orderId'] = self._orderId
        if not self._origClientOrderId is None:
            params['origClientOrderId'] = self._origClientOrderId
        if not self._recvWindow is None:
            params['recvWindow'] = self._recvWindow
        return params

    async def execute(self, callback):
        return await self.get('order', callback)

    async def result(self, res, callback):
        return await QueryOrderResponse(**res).execute(callback)


class CancelOrderResponse(Response):
    def __init__(self, symbol, origClientOrderId, orderId, orderListId, clientOrderId, price, origQty, executedQty, cummulativeQuoteQty, status, timeInForce, type, side, **ext):
        self._symbol = symbol
        self._origClientOrderId = origClientOrderId
        self._orderId = int(orderId)
        self._orderListId = int(orderListId)
        self._clientOrderId = clientOrderId
        self._price = float(price)
        self._origQty = float(origQty)
        self._executedQty = float(executedQty)
        self._cummulativeQuoteQty = float(cummulativeQuoteQty)
        self._status = OrderStatus(status)
        self._timeInForce = TimeInForce(timeInForce)
        self._type = OrderType(type)
        self._side = OrderSide(side)
        self._ext = ext
        super().__init__()


class CancelOrderRequest(TradeRequest):
    def __init__(self, session, apiKey, secret, symbol, timestamp, orderId=None, origClientOrderId=None, newClientOrderId=None, recvWindow=None):
        self._symbol = symbol
        self._timestamp = timestamp
        self._orderId = orderId
        self._origClientOrderId = origClientOrderId
        self._newClientOrderId = newClientOrderId
        self._recvWindow = recvWindow
        super().__init__(session, apiKey, secret)

    def params(self):
        params = {
            'symbol': self._symbol,
            'timestamp': int(self._timestamp * 1000)
        }
        if not self._orderId is None:
            params['orderId'] = self._orderId
        if not self._origClientOrderId is None:
            params['origClientOrderId'] = self._origClientOrderId
        if not self._newClientOrderId is None:
            params['newClientOrderId'] = self._newClientOrderId
        if not self._recvWindow is None:
            params['recvWindow'] = self._recvWindow
        return params

    async def execute(self, callback):
        return await self.delete('order', callback)

    async def result(self, res, callback):
        return await CancelOrderResponse(**res).execute(callback)


class StartUserDataStreamResponse(Response):
    def __init__(self, listenKey, **ext):
        self._listenKey = listenKey
        self._ext = ext

    def listenKey(self):
        return self._listenKey

#    def __repr__(self):
#        return '<<{0},{1}>>'.format(self._listenKey, self._ext)


class StartUserDataStreamRequest(UserStreamRequest):
    def __init__(self, session, apiKey):
        super().__init__(session, apiKey)

    async def execute(self, callback):
        return await self.post('userDataStream', callback)

    async def result(self, res, callback):
        return await StartUserDataStreamResponse(**res).execute(callback)


class KeepaliveUserDataStreamResponse(Response):
    def __init__(self, **ext):
        self._ext = ext


class KeepaliveUserDataStreamRequest(UserStreamRequest):
    def __init__(self, session, apiKey, listenKey):
        params = { 'listenKey': listenKey }
        super().__init__(session, apiKey, params=params)

    async def execute(self, callback):
        return await self.put('userDataStream', callback)

    async def result(self, res, callback):
        return await KeepaliveUserDataStreamResponse(**res).execute(callback)


class CloseUserDataStreamResponse(Response):
    def __init__(self, **ext):
        self._ext = ext


class CloseUserDataStreamRequest(UserStreamRequest):
    def __init__(self, session, apiKey, listenKey):
        params = { 'listenKey': listenKey }
        super().__init__(session, apiKey, params=params)

    async def execute(self, callback):
        return await self.delete('userDataStream', callback)

    async def result(self, res, callback):
        return await CloseUserDataStreamResponse(**res).execute(callback)


async def voidCallback(m):
    return m


class BinanceRestApi():
    def __init__(self):
        self._clientSession = aiohttp.ClientSession()

    async def ping(self, callback):
        await PingRequest(self._clientSession).execute(callback)

    async def time(self, callback):
        await TimeRequest(self._clientSession).execute(callback)

    async def exchangeInfo(self, callback):
        await ExchangeInfoRequest(self._clientSession).execute(callback)

    async def klines(self, symbol, interval, startTime=None, endTime=None, limit=None, callback=voidCallback):
        await KlinesRequest(self._clientSession, symbol, interval, startTime, endTime, limit).execute(callback)

    async def limitOrder(self, apiKey, secret, symbol, orderSide, orderType, timestamp, timeInForce=None, quantity=None, quoteOrderQty=None, price=None, newClientOrderId=None, stopPrice=None, icebergQty=None, newOrderRespType=None, recvWindow=None, callback=voidCallback):
        return await NewOrderRequest(self._clientSession, apiKey, secret, symbol, orderSide, orderType, timestamp, timeInForce=timeInForce, quantity=quantity, quoteOrderQty=quoteOrderQty, price=price, newClientOrderId=newClientOrderId, stopPrice=stopPrice, icebergQty=icebergQty, newOrderRespType=newOrderRespType, recvWindow=recvWindow).execute(callback)

    async def queryOrder(self, apiKey, secret, symbol, timestamp, orderId=None, origClientOrderId=None, recvWindow=None, callback=voidCallback):
        return await QueryOrderRequest(self._clientSession, apiKey, secret, symbol, timestamp, orderId=orderId, origClientOrderId=origClientOrderId, recvWindow=recvWindow).execute(callback)

    async def cancelOrder(self, apiKey, secret, symbol, timestamp, orderId=None, origClientOrderId=None, newClientOrderId=None, recvWindow=None, callback=voidCallback):
        request = CancelOrderRequest(self._clientSession, apiKey, secret, symbol, timestamp, orderId=orderId, origClientOrderId=origClientOrderId, newClientOrderId=newClientOrderId, recvWindow=recvWindow)
        rval = await request.execute(callback)
        return rval
        #return await CancelOrderRequest(self._clientSession, apiKey, secret, symbol, timestamp, orderId=orderId, origClientOrderId=origClientOrderId, newClientOrderId=newClientOrderId, recvWindow=recvWindow).execute(callback)

    async def startUserDataStream(self, callback, apiKey):
        return await StartUserDataStreamRequest(self._clientSession, apiKey).execute(callback)

    async def keepaliveUserDataStream(self, callback, apiKey, listenKey):
        return await KeepaliveUserDataStreamRequest(self._clientSession, apiKey, listenKey).execute(callback)

    async def closeUserDataStream(self, callback, apiKey, listenKey):
        return await CloseUserDataStreamRequest(self._clientSession, apiKey, listenKey).execute(callback)

    async def close(self):
        await self._clientSession.close()


async def print_result(m):
    print(m)


async def read_website():
    binance = BinanceRestApi()
    await binance.ping(print_result)
    await binance.time(print_result)
    await binance.exchangeInfo(print_result)
    await binance.close()


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(read_website())
    # Zero-sleep to allow underlying connections to close
    loop.run_until_complete(asyncio.sleep(0))
    loop.close()

