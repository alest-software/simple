
import datetime
import asyncio
from pprint import pprint
from aiohttp import ClientSession, WSMsgType
from .request import *
from .klineupdate import KlineEvent
from . import klineupdate
from .stream import *
from .exception import *


def camelCase(s):
    return ''.join(x for x in s.title() if not x.isspace() and x != '_')

def snakeCase(str): 
    return ''.join(['_'+i.lower() if i.isupper() else i for i in str]).lstrip('_') 


class State():
    def __init__(self, context):
        self.context = context

    async def handle(self):
        raise WebsocketError('cannot handle in state')


class DisconnectedState(State):
    def __init__(self, context):
        super().__init__(context)

    async def sendRequest(self, m):
        pass

    async def enterState(self):
        await self.context.handleDisconnect()

    async def handle(self):
        print('Connecting...')
        await asyncio.sleep(0)
        try:
            ws = await self.context.session.ws_connect(
                self.context._url,
                autoping = False,
            )
            self.context.ws = ws

            return ConnectedState(self.context)
        except RuntimeError:
            return None


class ConnectedState(State):
    def __init__(self, context):
        super().__init__(context)

    async def sendDirect(self, m):
        self.context.window[self.context.id] = m
        r = m.asMsg(self.context.id)
        self.context.id = self.context.id + 1
        print('send {0}'.format(m))
        await self.context.ws.send_json(r)

    async def sendRequest(self, m):
        if (len(self.context.window) < 1):
            await self.sendDirect(m)
        else:
            print('queued {0}'.format(m))
            self.context.queue.append(m)

    async def enterState(self):
        await self.context.handleConnect()

    async def handleJson(self, json):
        rval = None

        if isinstance(json, list):
            if len(json) > 0:
                if json[0]['e'] == '24hrMiniTicker':
                    msg = MiniTickerEventList(json)
                    rval = MiniTickerEventList
                elif json[0]['e'] == '24hrTicker':
                    msg = TickerEventList(json)
                    rval = TickerEventList
                else:
                    raise Exception('handleAllMarkets')

                await self.context.handleEvent(msg)
            else:
                raise Exception('len0')
                
        elif isinstance(json, object):
            params = {}
            if ('e' in json):
                if json['e'] == 'aggTrade':
                    msg = AggregateTradeEvent(**json)
                    rval = lambda x: AggregateTradeEvent(**x)
                elif json['e'] == 'trade':
                    msg = TradeEvent(**json)
                    rval = lambda x: TradeEvent(**x)
                elif json['e'] == 'kline':
                    msg = KlineEvent(**json)
                    rval = lambda x: KlineEvent(**x)
                elif json['e'] == '24hrMiniTicker':
                    msg = MiniTickerEvent(**json)
                    rval = lambda x: MiniTickerEvent(**x)
                elif json['e'] == '24hrTicker':
                    msg = TickerEvent(**json)
                    rval = lambda x: TickerEvent(**x)
                elif json['e'] == 'depthUpdate':
                    msg = DifferentialDepthEvent(**json)
                    rval = lambda x: DifferentialDepthEvent(**x)
                else:
                    raise WebsocketError('Invalid message: {0}'.format(json))
            elif ('u' in json):
                msg = BookTickerEvent(**json)
                rval = lambda x: BookTickerEvent(**x)
            elif ('lastUpdateId' in json):
                msg = PartialBookDepthEvent(**json)
                rval = lambda x: PartialBookDepthEvent(**x)
            elif ('id' in json):
                if ('result' in json):
                    print(type(json['result']))
                    pprint(json)
                    rval = lambda x: ResultEvent(**x)
                elif ('error' in json): 
                    pprint(json)
                    rval = lambda x: ErrorEvent(**x)

                req = self.context.window[json['id']]
                msg = req.getResponse(json)
                params['request'] = req
                del self.context.window[json['id']]
                if (len(self.context.queue) > 0):
                    json1 = self.context.queue.pop()
                    await self.sendDirect(json1)

#            elif ('code' in json):
#                raise WebsocketError('Invalid message: {0}'.format(json))
            else:
                raise WebsocketError('Invalid message: {0}'.format(json))

            await msg.handle(self.context, **params)

        else:
            raise WebsocketError('Illegal JSON message type {0}'.format(type(m)))

        return rval

    async def handleText(self, msg):
        m = msg.json()
        z = await self.handleJson(m)
        #print('-->', z(m))
        return self

    async def handlePing(self, msg):
        #print(datetime.now(), 'ping')
        await self.context.ws.pong()
        return self

    async def handleClose(self, msg):
        print(datetime.now(), 'Closed by remote')
        return DisconnectedState(self.context)

    async def handleBreak(self, msg):
        raise WebsocketError('Ill WSMsgType: ' + msg.type)

    async def handle(self):
        try:
            msg = await self.context.ws.receive()

            switcher = {
                WSMsgType.text: self.handleText,
                WSMsgType.ping: self.handlePing,
                WSMsgType.close: self.handleClose,
            }
            method = switcher.get(msg.type, self.handleBreak)
            return await method(msg)

        except Exception as e:
            print('except {0}'.format(e))
            #await self.context.close()
            return DisconnectedState(self.context)


#class AsyncObserver:
#    def __init__(self):
#        self.regs = []
#
#    async def notify(self, *args, **kwargs):
#        aws = []
#        for r in self.regs:
#            #print('for')
#            aws.append(r(*args, **kwargs))
#        #print('gath')
#        return await asyncio.gather(*aws)
#
#    def register(self, cb):
#        self.regs.append(cb)
#
#    def unregister(self, cb):
#        self.regs.remove(cb)

from .subscription import *


class BinanceWebSocket:
    def __init__(self):
        self.session = ClientSession()
        self._subscriptions_by_stream = {}
#        self._subscriptions_by_symbol = {}
        self.state = DisconnectedState(self)
        self._url = 'https://stream.binance.com:9443/ws'
        self.id = 1
        self.window = {}
        self.queue = []

    async def _subscribe(self, subscription):
#        stream_subscription = Subscription(self, stream, cb)
#
##        if (stream not in self._subscriptions_by_stream):
##            self._subscriptions_by_stream[stream] = []
##        self._subscriptions_by_stream[stream].append(stream_subscription)
#
#        #print(stream.getWsName())
#        #m = SubscribeRequest()
#        #m.addStream(stream)
#        #await m.execute(self.state)
#        await stream_subscription.subscribe()
#
##        symbolName = stream_subscription.getWsName()
##        if (symbolName not in self._subscriptions_by_symbol):
##            self._subscriptions_by_symbol[symbolName] = []
##        self._subscriptions_by_symbol[symbolName].append(stream_subscription)
#
#        return stream_subscription

        stream = subscription.get_stream()

        if (stream not in self._subscriptions_by_stream):
            self._subscriptions_by_stream[stream] = []
        self._subscriptions_by_stream[stream].append(subscription)

        await subscription.subscribe()

        return subscription

    async def aggregate_trade(self, *, symbol, cb):
        subscription = AggregateTradeSubscription(ws=self, symbol=symbol, cb=cb)
        return await self._subscribe(subscription)

    async def trade(self, *, symbol, cb):
        subscription = TradeSubscription(ws=self, symbol=symbol, cb=cb)
        return await self._subscribe(subscription)

    async def kline(self, *, symbol, interval, cb):
        subscription = KlineCandlestickSubscription(ws=self, symbol=symbol, interval=interval, cb=cb)
        return await self._subscribe(subscription)

    async def individual_symbol_mini_ticker(self, *, symbol, cb):
        subscription = IndividualSymbolMiniTickerSubscription(ws=self, symbol=symbol, cb=cb)
        return await self._subscribe(subscription)

    async def all_market_mini_tickers(self, *, cb):
        subscription = AllMarketMiniTickersSubscription(ws=self, cb=cb)
        return await self._subscribe(subscription)

    async def individual_symbol_ticker(self, *, symbol, cb):
        subscription = IndividualSymbolTickerSubscription(ws=self, symbol=symbol, cb=cb)
        return await self._subscribe(subscription)

    async def all_market_tickers(self, *, cb):
        subscription = AllMarketTickersSubscription(ws=self, cb=cb)
        return await self._subscribe(subscription)

    async def individual_symbol_book_ticker(self, *, symbol, cb):
        subscription = IndividualSymbolBookTickerSubscription(ws=self, symbol=symbol, cb=cb)
        return await self._subscribe(subscription)

    async def partial_book_depth(self, *, symbol, level, rate, cb):
        subscription = PartialBookDepthSubscription(ws=self, symbol=symbol, level=level, rate=rate, cb=cb)
        return await self._subscribe(subscription)

    async def diff_depth(self, *, symbol, rate, cb):
        subscription = DiffDepthSubscription(ws=self, symbol=symbol, rate=rate, cb=cb)
        return await self._subscribe(subscription)

    async def main(self):
        while self.state != None:
            oldState = self.state
            newState = await oldState.handle()
            self.state = newState
            if newState != None and newState != oldState:
                await newState.enterState()
        print('Main END')

#    async def open(self):
#        self._task = asyncio.create_task(self.main())

    async def stop(self):
        await self.session.close()

#    async def close(self):
#        await self._task

    async def do_subscribe(self, *, subscription):
        m = SubscribeRequest()
#        print(subscription)
        m.addSubscription(subscription)
        await m.execute(self.state)

    async def do_unsubscribe(self, *, subscription):
        m = UnsubscribeRequest()
        m.addSubscription(subscription)
#        m.addStream(stream)
        await m.execute(self.state)

    async def handleConnect(self):
        print(datetime.now(), 'Connected...')

        for s in self._subscriptions_by_stream.values():
            for p in s:
                #print(s.getWsName())
                #m = SubscribeRequest()
                #m.addStream(s)
                #await m.execute(self.state)
                #await stream_subscription.subscribe()
#                print(p)
                await self.do_subscribe(subscription=p)

        #print('Subscribed/queued...')

    async def handleDisconnect(self):
        print(datetime.now(), 'Disconnected...')

    async def handleSubscribeResponse(self, response, request, **kwargs):
        print('handleSubscribeResponse ({0}) ({1})'.format(response, request))
#        for stream in request._streams:
#            stream_subscriptions = self._subscriptions_by_stream[stream]
            #print(stream.getWsName())
#            for stream_subscription in stream_subscriptions:
#                await stream_subscription.subscribed.notify('done')

    async def handleUnsubscribeResponse(self, response, **kwargs):
        print(response)

    async def handleListSubscriptionsResponse(self, response, **kwargs):
        print(response)

    async def handleGetPropertyResponse(self, response, **kwargs):
        print(response)

    async def handleSetPropertyResponse(self, response, **kwargs):
        print(response)



    async def handleEvent(self, event, **kwargs):
        #print('----------------------------------------')
        #print(event, **kwargs)
        #for z in event.getStream():
        z = StreamFactory().getStream(event)
        #print(z)
        #print(self._subscriptions_by_stream)
        if z in self._subscriptions_by_stream:
            for s in self._subscriptions_by_stream[z]:
                #print(s)
#            for s in self._subscriptions_by_symbol[z.getWsName()]:
                await s(event)

#    async def handleKlineEvent(self, event, **kwargs):
#        print('handleKlineEvent')
#        #print(event)
#        #for z in event.getStream():
#        z = StreamFactory().getStream(event)
#        if z.getWsName() in self._subscriptions_by_symbol:
#            for s in self._subscriptions_by_symbol[z.getWsName()]:
#                await s(event)
#
#    async def handleTradeEvent(self, event, **kwargs):
#        #print('handleTradeEvent')
#        #print(event)
#        #for z in event.getStream():
#        z = StreamFactory().getStream(event)
#        if z.getWsName() in self._subscriptions_by_symbol:
#            for s in self._subscriptions_by_symbol[z.getWsName()]:
#                await s(event)
#
#    async def handleAggregateTradeEvent(self, event, **kwargs):
#        #print('handleAggregateTradeEvent')
#        #print(event)
#        #for z in event.getStream():
#        z = StreamFactory().getStream(event)
#        if z.getWsName() in self._subscriptions_by_symbol:
#            for s in self._subscriptions_by_symbol[z.getWsName()]:
#                await s(event)
#
#    async def handleMiniTickerEvent(self, event, **kwargs):
#        #print('handleMiniTickerEvent')
#        #print(event)
#        #for z in event.getStream():
#        z = StreamFactory().getStream(event)
#        if z.getWsName() in self._subscriptions_by_symbol:
#            for s in self._subscriptions_by_symbol[z.getWsName()]:
#                await s(event)
#
#    async def handleTickerEvent(self, event, **kwargs):
#        #print('handleTickerEvent')
#        #print(event)
#        #for z in event.getStream():
#        z = StreamFactory().getStream(event)
#        if z.getWsName() in self._subscriptions_by_symbol:
#            for s in self._subscriptions_by_symbol[z.getWsName()]:
#                await s(event)
#
#    async def handleBookTickerEvent(self, event, **kwargs):
#        #print('handleBookTickerEvent')
#        #print(event)
#        #for z in event.getStream():
#        z = StreamFactory().getStream(event)
#        if z.getWsName() in self._subscriptions_by_symbol:
#            for s in self._subscriptions_by_symbol[z.getWsName()]:
#                await s(event)
#
#    async def handlePartialBookDepthEvent(self, event, **kwargs):
#        #print('handlePartialBookDepthEvent')
#        #print(event)
#        #for z in event.getStream():
#        z = StreamFactory().getStream(event)
#        if z.getWsName() in self._subscriptions_by_symbol:
#            for s in self._subscriptions_by_symbol[z.getWsName()]:
#                await s(event)
#
#    async def handleDifferentialDepthEvent(self, event, **kwargs):
#        #print('handleDifferentialDepthEvent')
#        #print(event)
#        #for z in event.getStream():
#        z = StreamFactory().getStream(event)
#        if z.getWsName() in self._subscriptions_by_symbol:
#            for s in self._subscriptions_by_symbol[z.getWsName()]:
#                await s(event)

