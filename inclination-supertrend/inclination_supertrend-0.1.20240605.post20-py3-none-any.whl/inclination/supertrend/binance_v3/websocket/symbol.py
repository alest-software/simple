from attr import frozen

@frozen #(hash=True)
class Symbol():
    val: str

#    def __init__(self, val):
#        assert type(val) == str
#
#        self._val = val

#    def __eq__(self, b):
#        return (type(self) == type(b)) and (self._val == b._val)

    def getName(self):
        return self.val

    def getStreamName(self):
        return self.val.lower()

#symbol = Symbol('Some')
#some = {symbol: 2}
#some[Symbol('Some')] = 3
#print(some)

