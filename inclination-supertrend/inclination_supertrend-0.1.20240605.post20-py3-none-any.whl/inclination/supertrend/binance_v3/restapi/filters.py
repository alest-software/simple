#!/usr/bin/env python3

from enum import Enum


class FilterType(Enum):
	PRICE_FILTER = 'PRICE_FILTER'
	PERCENT_PRICE = 'PERCENT_PRICE'
	LOT_SIZE = 'LOT_SIZE'
	MIN_NOTIONAL = 'MIN_NOTIONAL'
	ICEBERG_PARTS = 'ICEBERG_PARTS'
	MARKET_LOT_SIZE = 'MARKET_LOT_SIZE'
	MAX_NUM_ORDERS = 'MAX_NUM_ORDERS'
	MAX_NUM_ALGO_ORDERS = 'MAX_NUM_ALGO_ORDERS'
	MAX_NUM_ICEBERG_ORDERS = 'MAX_NUM_ICEBERG_ORDERS'
	MAX_POSITION = 'MAX_POSITION'
	EXCHANGE_MAX_NUM_ORDERS = 'EXCHANGE_MAX_NUM_ORDERS'
	EXCHANGE_MAX_NUM_ALGO_ORDERS = 'EXCHANGE_MAX_NUM_ALGO_ORDERS'

	def __init__(self, label):	
		self._label = label

	def __str__(self):
		return '{0}'.format(self._label)

	@staticmethod
	def from_str(label):
		return getattr(FilterType, label)


class Filter():
	def __init__(self):
		pass

	def __str__(self):
		return '{0}'.format(vars(self))


class PriceFilter(Filter):
	def __init__(self, filterType, minPrice, maxPrice, tickSize, **ext):
		self._minPrice = float(minPrice)
		self._maxPrice = float(maxPrice)
		self._tickSize = float(tickSize)
		self._ext = ext


class PercentPriceFilter(Filter):
	def __init__(self, filterType, multiplierUp, multiplierDown, avgPriceMins, **ext):
		self._multiplierUp = float(multiplierUp)
		self._multiplierDown = float(multiplierDown)
		self._avgPriceMins = int(avgPriceMins)
		self._ext = ext

	def __str__(self):
		return '{0}'.format(vars(self))


class LotSizeFilter(Filter):
	def __init__(self, filterType, minQty, maxQty, stepSize, **ext):
		self._minQty = float(minQty)
		self._maxQty = float(maxQty)
		self._stepSize = float(stepSize)
		self._ext = ext


class MinNotionalFilter(Filter):
	def __init__(self, filterType, minNotional, applyToMarket, avgPriceMins, **ext):
		self._minNotional = float(minNotional)
		self._applyToMarket = bool(applyToMarket)
		self._avgPriceMins = int(avgPriceMins)
		self._ext = ext


class IcebergPartsFilter(Filter):
	def __init__(self, filterType, limit, **ext):
		self._limit = int(limit)
		self._ext = ext


class MarketLotSizeFilter(Filter):
	def __init__(self, filterType, minQty, maxQty, stepSize, **ext):
		self._minQty = float(minQty)
		self._maxQty = float(maxQty)
		self._stepSize = float(stepSize)
		self._ext = ext


class MaxNumOrdersFilter(Filter):
	def __init__(self, filterType, maxNumOrders, **ext):
		self._maxNumOrders = int(maxNumOrders)
		self._ext = ext


class MaxNumAlgoOrdersFilter(Filter):
	def __init__(self, filterType, maxNumAlgoOrders, **ext):
		self._maxNumAlgoOrders = int(maxNumAlgoOrders)
		self._ext = ext


class MaxNumIcebergOrdersFilter(Filter):
	def __init__(self, filterType, maxNumIcebergOrders, **ext):
		self._maxNumIcebergOrders = int(maxNumIcebergOrders)
		self._ext = ext


class MaxPositionFilter(Filter):
	def __init__(self, filterType, maxPosition, **ext):
		self._maxPosition = float(maxPosition)
		self._ext = ext


class ExchangeMaxNumOrdersFilter(Filter):
	def __init__(self, filterType, maxNumOrders, **ext):
		self._maxNumOrders = int(maxNumOrders)
		self._ext = ext


class ExchangeMaxNumAlgoOrdersFilter(Filter):
	def __init__(self, filterType, maxNumAlgoOrders, **ext):
		self._maxNumAlgoOrders = int(maxNumAlgoOrders)
		self._ext = ext


def filterFactory(**ext):
	switcher = {
		'PRICE_FILTER': PriceFilter,
		'PERCENT_PRICE': PercentPriceFilter,
		'LOT_SIZE': LotSizeFilter,
		'MIN_NOTIONAL': MinNotionalFilter,
		'ICEBERG_PARTS': IcebergPartsFilter,
		'MARKET_LOT_SIZE': MarketLotSizeFilter,
		'MAX_NUM_ORDERS': MaxNumOrdersFilter,
		'MAX_NUM_ALGO_ORDERS': MaxNumAlgoOrdersFilter,
		'MAX_NUM_ICEBERG_ORDERS': MaxNumIcebergOrdersFilter,
		'MAX_POSITION': MaxPositionFilter,
		'EXCHANGE_MAX_NUM_ORDERS': ExchangeMaxNumOrdersFilter,
		'EXCHANGE_MAX_NUM_ALGO_ORDERS': ExchangeMaxNumAlgoOrdersFilter,
	}
	classType = switcher.get(ext['filterType'])
	return classType(**ext)


