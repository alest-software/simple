import numpy as np

class AverageTrueRange:
    def __init__(self, length=10):
        self._length = length
        self._window = []
        self._prev_atr = np.nan
    
    def __call__(self, true_range, store=True):
        if not np.isnan(self._prev_atr):
            atr = ((self._prev_atr * (self._length - 1)) + true_range) / self._length
        else:
            if len(self._window) < self._length-1:
                if not np.isnan(true_range):
                    self._window.append(true_range)
                atr = np.nan
            else:
                self._window.append(true_range)
                atr = np.mean(self._window)
                
        if store:
            self._prev_atr = atr
            
        return atr

