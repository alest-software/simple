
class Symbol():
    def __init__(self, val):
        assert type(val) == str

        self._val = val

    def __eq__(self, b):
        return (type(self) == type(b)) and (self._val == b._val)

    def getName(self):
        return self._val

    def getStreamName(self):
        return self._val.lower()

