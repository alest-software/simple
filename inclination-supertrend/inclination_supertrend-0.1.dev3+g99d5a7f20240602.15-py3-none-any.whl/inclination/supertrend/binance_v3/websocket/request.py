#!/usr/bin/env python3

from .klineupdate import *
from pprint import pprint


class Request:
    def __init__(self, method):
        self._method = method

    def getMethod(self):
        return self._method

    def asMsg(self, id):
        return { 'method': self.getMethod(), 'id': id }

    async def execute(self, e):
        await e.sendRequest(self)


class SubscribeRequest(Request):
    def __init__(self):
        super().__init__('SUBSCRIBE')
        self._streams = []

    def addStream(self, stream):
        self._streams.append(stream)

    def asMsg(self, id):
        msg = super().asMsg(id)
        msg['params'] = []
        for s in self._streams:
            msg['params'].append(s.getWsName())
        return msg

    def getResponse(self, m):
        return SubscribeResponse(**m)


class UnsubscribeRequest(Request):
    def __init__(self):
        super().__init__('UNSUBSCRIBE')
        self._streams = []

    def addStream(self, stream):
        self._streams.append(stream)

    def asMsg(self, id):
        msg = super().asMsg(id)
        msg['params'] = []
        for s in self._streams:
            msg['params'].append(s.getWsName())
        return msg

    def getResponse(self, m):
        return UnsubscribeResponse(**m)


class ListSubscriptionsRequest(Request):
    def __init__(self):
        super().__init__('LIST_SUBSCRIPTIONS')

    def asMsg(self, id):
        msg = super().asMsg(id)
        return msg

    def getResponse(self, m):
        return ListSubscriptionsResponse(**m)


class SetPropertyRequest(Request):
    def __init__(self):
        super().__init__('SET_PROPERTY')

    def asMsg(self, id):
        msg = super().asMsg(id)
        msg['params'] = ['combined', False]
        return msg

    def getResponse(self, m):
        return SetPropertyResponse(**m)


class GetPropertyRequest(Request):
    def __init__(self):
        super().__init__('GET_PROPERTY')

    def asMsg(self, id):
        msg = super().asMsg(id)
        msg['params'] = ['combined']
        return msg

    def getResponse(self, m):
        return GetPropertyResponse(**m)

