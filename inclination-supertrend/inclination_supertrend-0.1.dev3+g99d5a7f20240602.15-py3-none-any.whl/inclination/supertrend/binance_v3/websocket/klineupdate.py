
from datetime import datetime
from .stream import *
from .response import *


class Event(Message):
    def __init__(self):
        pass

    async def handle(self, visitor, **kwargs):
        return await getattr(visitor, 'handleEvent')(self, **kwargs)

    def __repr__(self):
        return '({0}){1}'.format(type(self).__name__, vars(self))


class AggregateTradeEvent(Event):
    def __init__(self, E, s, a, p, q, f, l, T, m, **ext):
        self._E = float(E)/1000.0    # Event time
        self._s = str(s)            # Symbol
        self._a = int(a)            # Aggregate trade ID
        self._p = float(p)            # Price
        self._q = float(q)            # Quantity
        self._f = int(f)            # First trade ID
        self._l = int(l)            # Last trade ID
        self._T = float(T)/1000.0    # Trade time
        self._m = bool(m)            # Is the buyer the marker maken?
        self._ext = ext

    def getStream(self):
        return [ AggregateTradeStream(self.getSymbol()) ]

    def getSymbol(self):
        return Symbol(self._s)

    def __str__(self):
        return '{0},{1},{2},{3},{4},{5},{6},{7},{8}'.format(datetime.fromtimestamp(self._E), self._s, self._a, self._p, self._q,
            self._f, self._l, datetime.fromtimestamp(self._T), self._m)


class TradeEvent(Event):
    def __init__(self, E, s, t, p, q, b, a, T, m, **ext):
        self._E = float(E)/1000.0    # Event time
        self._s = str(s)            # Symbol
        self._t = int(t)            # Trade ID
        self._p = float(p)            # Price
        self._q = float(q)            # Quantity
        self._b = int(b)            # Buyer order ID
        self._a = int(a)            # Seller order ID
        self._T = float(T)/1000.0    # Trade time
        self._m = bool(m)            # Is the buyer the marker maken?
        self._ext = ext

    def getStream(self):
        return [ TradeStream(self.getSymbol()) ]

    def getSymbol(self):
        return Symbol(self._s)

    def __str__(self):
        return '{0},{1},{2},{3},{4},{5},{6},{7},{8}'.format(datetime.fromtimestamp(self._E), self._s, self._t, self._p, self._q,
            self._b, self._a, datetime.fromtimestamp(self._T), self._m)


class KlineEvent(Event):
    class KlineInfo:
        def __init__(self, t, T, s, i, f, L, o, c, h, l, v, n, x, q, V, Q, **ext):
            self._t = float(t)/1000.0    # Kline start time
            self._T = float(T)/1000.0    # Kline close time
            self._s = str(s)            # Symbol
            self._i = str(i)            # Interval
            self._f = int(f)            # First trade ID
            self._L = int(L)            # Last trade ID
            self._o = float(o)            # Open price
            self._c = float(c)            # Close price
            self._h = float(h)            # High price
            self._l = float(l)            # Low price
            self._v = float(v)            # Base asset volume
            self._n = int(n)            # Number of trades
            self._x = bool(x)            # Is this kline closed?
            self._q = float(q)            # Quote asset volume
            self._V = float(V)            # Taker buy base asset volume
            self._Q = float(Q)            # Taker buy quote asset volume
            self._ext = ext

    def __init__(self, E, s, k, **ext):
        self._E = float(E)/1000.0        # Event time
        self._s = str(s)                # Symbol
        self._k = KlineEvent.KlineInfo(**k)
        self._ext = ext

    def getStream(self):
        return [ KlineCandlestickStream(self.getSymbol(), self.getInterval()) ]

    def getEventTime(self):
        return self._E

    def getSymbol(self):
        return Symbol(self._s)

    def getStartTime(self):
        return self._k._t

    def getCloseTime(self):
        return self._k._T

    def getInterval(self):
        return Interval.from_str(self._k._i)

    def getFirstTradeId(self):
        return self._k._f

    def getLastTradeId(self):
        return self._k._L

    def getOpenPrice(self):
        return self._k._o

    def getClosePrice(self):
        return self._k._c

    def getHighPrice(self):
        return self._k._h

    def getLowPrice(self):
        return self._k._l

    def getBaseAssetVolume(self):
        return self._k._v

    def getNofTrades(self):
        return self._k._n

    def getClosed(self):
        return self._k._x

    def getQuoteAssetVolume(self):
        return self._k._q

    def getTakerBuyBaseAssetVolume(self):
        return self._k._V

    def getTakerBuyQuoteAssetVolume(self):
        return self._k._Q

    def __str__(self):
        return '{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17}'.format(
            datetime.fromtimestamp(self._E), self._s, datetime.fromtimestamp(self._k._t), datetime.fromtimestamp(self._k._T),
            self._k._s, self._k._i, self._k._f, self._k._L, self._k._o, self._k._c, self._k._h, self._k._l, self._k._v,
            self._k._n, self._k._x, self._k._q, self._k._V, self._k._Q)


# Individual Symbol Mini Ticker Stream _or_ All Market Mini Tickers Stream
class MiniTickerEvent(Event):
    def __init__(self, allMarket, e, E, s, c, o, h, l, v, q, **ext):
        self._allMarket = allMarket
        self._E = float(E)/1000.0    # Event time
        self._s = str(s)            # Symbol
        self._c = float(c)            # Close price
        self._o = float(o)            # Open price
        self._h = float(h)            # High price
        self._l = float(l)            # Low price
        self._v = float(v)            # Total traded base asset volume
        self._q = float(q)            # Total traded quote asset volume
        self._ext = ext

    def getStream(self):
        if self._allMarket:
            return [ AllMarketMiniTickersStream() ]
        else:
            return [ IndividualSymbolMiniTickerStream(self.getSymbol()) ]

    def getSymbol(self):
        return Symbol(self._s)

    def getClose(self):
        return self._c

    def getVolume(self):
        return self._v

#    def __str__(self):
#        return '{0},{1},{2},{3},{4},{5},{6},{7}'.format(
#            datetime.fromtimestamp(self._E), self._s, self._c, self._o, self._h, self._l, self._v,
#            self._q)


# Individual Symbol Ticker Streams _or_ All Market Tickers Stream
class TickerEvent(Event):
    def __init__(self, allMarket, E, s, p, P, w, x, c, Q, b, B, a, A, o, h, l, v, q, O, C, F, L, n, **ext):
        self._allMarket = allMarket
        self._E = float(E)/1000.0    # Event time
        self._s = str(s)            # Symbol
        self._p = float(p)            # Price change
        self._P = float(P)            # Price change percent
        self._w = float(w)            # Weighted average price
        self._x = float(x)            # First trade(F)-1 price (first trade before the 24hr rolling window)
        self._c = float(c)            # Last price
        self._Q = float(Q)            # Last quantity
        self._b = float(b)            # Best bid price
        self._B = float(B)            # Best bid quantity
        self._a = float(a)            # Best ask price
        self._A = float(A)            # Best ask quantity
        self._o = float(o)            # Open price
        self._h = float(h)            # High price
        self._l = float(l)            # Low price
        self._v = float(v)            # Total traded base asset volume
        self._q = float(q)            # Total traded quote asset volume
        self._O = float(O)/1000.0    # Statistics open time
        self._C = float(C)/1000.0    # Statistics close time
        self._F = int(F)            # First trade ID
        self._L = int(L)            # Last trade Id
        self._n = int(n)            # Total number of trades
        self._ext = ext

    def getStream(self):
        if self._allMarket:
            return [ AllMarketTickersStream() ]
        else:
            return [ IndividualSymbolTickerStream(Symbol(self._s)) ]

    def getSymbol(self):
        return Symbol(self._s)

    def __str__(self):
        return '{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20},{21}'.format(
            datetime.fromtimestamp(self._E), self._s, self._p, self._P, self._w, self._x, self._c, self._Q, self._b, self._B,
            self._a, self._A, self._o, self._h, self._l, self._v, self._q, datetime.fromtimestamp(self._O),
            datetime.fromtimestamp(self._C), self._F, self._L, self._n)


# Individual Symbol Book Ticker Streams _or_ All Book Tickers Stream
class BookTickerEvent(Event):
    def __init__(self, allMarket, u, s, b, B, a, A, **ext):
        self._allMarket = allMarket
        self._u = int(u)            # order book updateId
        self._s = str(s)            # symbol
        self._b = float(b)            # best bid price
        self._B = float(B)            # best bid qty
        self._a = float(a)            # best ask price
        self._A = float(A)            # best ask qty
        self._ext = ext

    def getStream(self):
        return [ IndividualSymbolBookTickerStream(self.getSymbol()), AllBookTickersStream() ]

    def getSymbol(self):
        return Symbol(self._s)

    def __str__(self):
        return '{0},{1},{2},{3},{4},{5}'.format(
            self._u, self._s, self._b, self._B, self._a, self._A)


class PartialBookDepthEvent(Event):
    def __init__(self, lastUpdateId, bids, asks, **ext):
        self._lastUpdateId = int(lastUpdateId)    # Last update ID
        self._bids = []                            # Bids to be updated []
        for x in bids:
            self._bids.append([float(x[0]), float(x[1])])
        self._asks = []                            # Asks to be updated []
        for x in asks:
            self._asks.append([float(x[0]), float(x[1])])
        self._ext = ext

    def getStream(self):
        return [ ] #PartialBookDepthStream(self.getSymbol(), level=None, rate=None) ]

#    def getSymbol(self):
#        return Symbol(self._s)

    def __str__(self):
        return '{0},{1},{2}'.format(self._lastUpdateId, self._bids, self._asks)


class DifferentialDepthEvent(Event):
    def __init__(self, E, s, U, u, b, a, **ext):
        self._E = float(E)/1000.0        # Event time
        self._s = str(s)                # Symbol
        self._U = int(U)                # First update ID in event
        self._u = int(u)                # Final update ID in event
        self._b = []                    # Bids to be updated []
        for x in b:
            self._b.append([float(x[0]), float(x[1])])
        self._a = []                    # Asks to be updated []
        for x in a:
            self._a.append([float(x[0]), float(x[1])])
        self._ext = ext

    def getStream(self):
        return [ DiffDepthStream(self.getSymbol(), UpdateSpeed.UPDATESPEED_100ms), DiffDepthStream(self.getSymbol(), UpdateSpeed.UPDATESPEED_1000ms) ]

    def getSymbol(self):
        return Symbol(self._s)

    def __str__(self):
        return '{0},{1},{2},{3},{4},{5}'.format(
            datetime.fromtimestamp(self._E), self._s, self._U, self._u, self._b, self._a)

