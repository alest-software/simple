
from datetime import datetime
from .stream import *


class Message():
    def __init__(self):
        pass

    async def handle(self, visitor, **kwargs):
        lookup = "handle" + type(self).__qualname__
        #print('Message::handle {0}'.format(lookup))
        return await getattr(visitor, lookup)(self, **kwargs)


class Response(Message):
    def __init__(self):
        super().__init__()


class SubscribeResponse(Response):
    def __init__(self, id, result):
        super().__init__()
        self._id = id
        self._result = result

    def __str__(self):
        return '{0} {1}'.format(self._id, self._result)


class UnsubscribeResponse(Response):
    def __init__(self, id, result):
        super().__init__()
        self._id = id
        self._result = result


class ListSubscriptionsResponse(Response):
    def __init__(self, id, result):
        super().__init__()
        self._id = id
        self._result = result


class GetPropertyResponse(Response):
    def __init__(self, id, result):
        super().__init__()
        self._id = id
        self._result = result


class SetPropertyResponse(Response):
    def __init__(self, id, result):
        super().__init__()
        self._id = id
        self._result = result

