
from enum import Enum
from .interval import *
from .updatespeed import *
from .level import *
from .symbol import *


class StreamBase:
    def __init__(self):
        pass

    def getWsName(self):
        raise WebsocketError('baseclass')

    def __str__(self):
        return self.getWsName()


class AggregateTradeStream(StreamBase):
    def __init__(self, symbol):
        assert type(symbol) == Symbol

        super().__init__()
        self._symbol = symbol

    def getWsName(self):
        return '{0}@aggTrade'.format(self._symbol.getStreamName())

#    def __eq__(self, b):
#        return (type(self) == type(b)) and (self._symbol == b._symbol)


class TradeStream(StreamBase):
    def __init__(self, symbol):
        assert type(symbol) == Symbol

        super().__init__()
        self._symbol = symbol

    def getWsName(self):
        return '{0}@trade'.format(self._symbol.getStreamName())


class KlineCandlestickStream(StreamBase):
    def __init__(self, symbol, interval):
        assert type(symbol) == Symbol
        assert type(interval) == Interval

        super().__init__()
        self._symbol = symbol
        self._interval = interval

    def getSymbol(self):
        return self._symbol

    def getStreamType(self):
        return self._interval

    def getWsName(self):
        return '{0}@kline_{1}'.format(self._symbol.getStreamName(), self._interval)

    def __str__(self):
        return self.getWsName()


class IndividualSymbolMiniTickerStream(StreamBase):
    def __init__(self, symbol):
        assert type(symbol) == Symbol

        super().__init__()
        self._symbol = symbol

    def getWsName(self):
        return '{0}@miniTicker'.format(self._symbol.getStreamName())


class AllMarketMiniTickersStream(StreamBase):
    def __init__(self):
        super().__init__()

    def getWsName(self):
        return '!miniTicker@arr'


class IndividualSymbolTickerStream(StreamBase):
    def __init__(self, symbol):
        assert type(symbol) == Symbol

        super().__init__()
        self._symbol = symbol

    def getWsName(self):
        return '{0}@ticker'.format(self._symbol.getStreamName())


class AllMarketTickersStream(StreamBase):
    def __init__(self):
        super().__init__()

    def getWsName(self):
        return '!ticker@arr'


class IndividualSymbolBookTickerStream(StreamBase):
    def __init__(self, symbol):
        assert type(symbol) == Symbol

        super().__init__()
        self._symbol = symbol

    def getWsName(self):
        return '{0}@bookTicker'.format(self._symbol.getStreamName())


class AllBookTickersStream(StreamBase):
    def __init__(self):
        super().__init__()

    def getWsName(self):
        return '!bookTicker'


class PartialBookDepthStream(StreamBase):
    def __init__(self, symbol, levels, rate):
        assert type(symbol) == Symbol
        assert type(levels) == Level
        assert type(rate) == UpdateSpeed

        super().__init__()
        self._symbol = symbol
        self._levels = levels
        self._rate = rate

    def getWsName(self):
        return '{0}@depth{1}@{2}'.format(self._symbol.getStreamName(), self._levels, self._rate)


class DiffDepthStream(StreamBase):
    def __init__(self, symbol, rate):
        assert type(symbol) == Symbol
        assert type(rate) == UpdateSpeed

        super().__init__()
        self._symbol = symbol
        self._rate = rate

    def getWsName(self):
        return '{0}@depth@{1}'.format(self._symbol.getStreamName(), self._rate)


