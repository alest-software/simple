
import datetime
import asyncio
from aiohttp import ClientSession, WSMsgType
from .request import *
from .klineupdate import KlineEvent
from . import klineupdate
from .stream import *
from .exception import *


def camelCase(s):
    return ''.join(x for x in s.title() if not x.isspace() and x != '_')

def snakeCase(str): 
    return ''.join(['_'+i.lower() if i.isupper() else i for i in str]).lstrip('_') 


class State():
    def __init__(self, context):
        self.context = context

    async def handle(self):
        raise WebsocketError('cannot handle in state')


class DisconnectedState(State):
    def __init__(self, context):
        super().__init__(context)

    async def sendRequest(self, m):
        pass

    async def enterState(self):
        await self.context.handleDisconnect()

    async def handle(self):
        print('Connecting...')
        await asyncio.sleep(0)
        try:
            ws = await self.context.session.ws_connect(
                self.context._url,
                autoping = False,
            )
            self.context.ws = ws

            return ConnectedState(self.context)
        except RuntimeError:
            return None


class ConnectedState(State):
    def __init__(self, context):
        super().__init__(context)

    async def sendDirect(self, m):
        self.context.window[self.context.id] = m
        r = m.asMsg(self.context.id)
        self.context.id = self.context.id + 1
        print('send {0}'.format(m))
        await self.context.ws.send_json(r)

    async def sendRequest(self, m):
        if (len(self.context.window) < 1):
            await self.sendDirect(m)
        else:
            print('queued {0}'.format(m))
            self.context.queue.append(m)

    async def enterState(self):
        await self.context.handleConnect()

    async def handleJson(self, json, allMarket):
        params = {}
        if ('e' in json):
            if json['e'] == 'aggTrade':
                msg = AggregateTradeEvent(**json)
            elif json['e'] == 'trade':
                msg = TradeEvent(**json)
            elif json['e'] == 'kline':
                msg = KlineEvent(**json)
            elif json['e'] == '24hrMiniTicker':
                msg = MiniTickerEvent(allMarket, **json)
            elif json['e'] == '24hrTicker':
                msg = TickerEvent(allMarket, **json)
            elif json['e'] == 'depthUpdate':
                msg = DifferentialDepthEvent(**json)
            else:
                raise WebsocketError('Invalid message: {0}'.format(json))
        elif ('u' in json):
            msg = BookTickerEvent(allMarket, **json)
        elif ('lastUpdateId' in json):
            msg = PartialBookDepthEvent(**json)
        elif ('id' in json):
            req = self.context.window[json['id']]
            msg = req.getResponse(json)
            params['request'] = req
            del self.context.window[json['id']]
            if (len(self.context.queue) > 0):
                json1 = self.context.queue.pop()
                await self.sendDirect(json1)
        elif ('code' in json):
            raise WebsocketError('Invalid message: {0}'.format(json))
        else:
            raise WebsocketError('Invalid message: {0}'.format(json))

        await msg.handle(self.context, **params)

        return self

    async def handleText(self, msg):
        m = msg.json()
        if isinstance(m, list):
            for e in m:
                await self.handleJson(e, True)
            return self
        elif isinstance(m, object):
            return await self.handleJson(m, False)
        else:
            raise WebsocketError('Illegal JSON message type {0}'.format(type(m)))

    async def handlePing(self, msg):
        #print(datetime.now(), 'ping')
        await self.context.ws.pong()
        return self

    async def handleClose(self, msg):
        print(datetime.now(), 'Closed by remote')
        return DisconnectedState(self.context)

    async def handleBreak(self, msg):
        raise WebsocketError('Ill WSMsgType: ' + msg.type)

    async def handle(self):
        try:
            msg = await self.context.ws.receive()

            switcher = {
                WSMsgType.text: self.handleText,
                WSMsgType.ping: self.handlePing,
                WSMsgType.close: self.handleClose,
            }
            method = switcher.get(msg.type, self.handleBreak)
            return await method(msg)

        except Exception as e:
            print('except {0}'.format(e))
            #await self.context.close()
            return DisconnectedState(self.context)


class AsyncObserver:
    def __init__(self):
        self.regs = []

    async def notify(self, *args, **kwargs):
        aws = []
        for r in self.regs:
            #print('for')
            aws.append(r(*args, **kwargs))
        #print('gath')
        return await asyncio.gather(*aws)

    def register(self, cb):
        self.regs.append(cb)

    def unregister(self, cb):
        self.regs.remove(cb)


class StreamSubscription:
    def __init__(self, ws, stream, cb):
        self.ws = ws
        self.stream = stream
        self.cb = cb
        self.subscribed = AsyncObserver()
        self.subscribed.register(self.hops)

    async def subscribe(self):
        #print(self.stream.getWsName())
        #m = SubscribeRequest()
        #m.addStream(self.stream)
        #await m.execute(self.ws.state)
        await self.ws.do_subscribe(self.stream)

    async def unsubscribe(self):
        await self.ws.do_unsubscribe(self.stream)

    async def hops(self, *args, **kwargs):
        print('hops', *args, **kwargs)

    async def __call__(self, msg):
        rc = await self.cb(msg, self)
        return rc


class BinanceWebSocket:
    def __init__(self):
        self.session = ClientSession()
        self._subscriptions_by_stream = {}
        self._subscriptions_by_symbol = {}
        self.state = DisconnectedState(self)
        self._url = 'https://stream.binance.com:9443/ws'
        self.id = 1
        self.window = {}
        self.queue = []

    async def subscribe(self, stream, cb):
        stream_subscription = StreamSubscription(self, stream, cb)

        if (stream not in self._subscriptions_by_stream):
            self._subscriptions_by_stream[stream] = []
        self._subscriptions_by_stream[stream].append(stream_subscription)

        #print(stream.getWsName())
        #m = SubscribeRequest()
        #m.addStream(stream)
        #await m.execute(self.state)
        await stream_subscription.subscribe()

        symbolName = stream.getWsName()
        if (symbolName not in self._subscriptions_by_symbol):
            self._subscriptions_by_symbol[symbolName] = []
        self._subscriptions_by_symbol[symbolName].append(stream_subscription)

        return stream_subscription

    async def main(self):
        while self.state != None:
            oldState = self.state
            newState = await oldState.handle()
            self.state = newState
            if newState != None and newState != oldState:
                await newState.enterState()
        print('Main END')

#    async def open(self):
#        self._task = asyncio.create_task(self.main())

    async def stop(self):
        await self.session.close()

#    async def close(self):
#        await self._task

    async def do_subscribe(self, stream):
        m = SubscribeRequest()
        m.addStream(stream)
        await m.execute(self.state)

    async def do_unsubscribe(self, stream):
        m = UnsubscribeRequest()
        m.addStream(stream)
        await m.execute(self.state)

    async def handleConnect(self):
        #print(datetime.now(), 'Connected...')

        for s in self._subscriptions_by_stream:
            #print(s.getWsName())
            #m = SubscribeRequest()
            #m.addStream(s)
            #await m.execute(self.state)
            #await stream_subscription.subscribe()
            await self.do_subscribe(s)

        #print('Subscribed/queued...')

    async def handleDisconnect(self):
        print(datetime.now(), 'Disconnected...')

    async def handleSubscribeResponse(self, response, request, **kwargs):
        #print('handleSubscribeResponse ({0}) ({1})'.format(response, request))
        for stream in request._streams:
            stream_subscriptions = self._subscriptions_by_stream[stream]
            #print(stream.getWsName())
            for stream_subscription in stream_subscriptions:
                await stream_subscription.subscribed.notify('done')

    async def handleUnsubscribeResponse(self, response, **kwargs):
        print(response)

    async def handleListSubscriptionsResponse(self, response, **kwargs):
        print(response)

    async def handleGetPropertyResponse(self, response, **kwargs):
        print(response)

    async def handleSetPropertyResponse(self, response, **kwargs):
        print(response)



    async def handleEvent(self, event, **kwargs):
        #print('handleEvent')
        for z in event.getStream():
            if z.getWsName() in self._subscriptions_by_symbol:
                for s in self._subscriptions_by_symbol[z.getWsName()]:
                    await s(event)

    async def handleKlineEvent(self, event, **kwargs):
        print('handleKlineEvent')
        #print(event)
        for z in event.getStream():
            if z.getWsName() in self._subscriptions_by_symbol:
                for s in self._subscriptions_by_symbol[z.getWsName()]:
                    await s(event)

    async def handleTradeEvent(self, event, **kwargs):
        #print('handleTradeEvent')
        #print(event)
        for z in event.getStream():
            if z.getWsName() in self._subscriptions_by_symbol:
                for s in self._subscriptions_by_symbol[z.getWsName()]:
                    await s(event)

    async def handleAggregateTradeEvent(self, event, **kwargs):
        #print('handleAggregateTradeEvent')
        #print(event)
        for z in event.getStream():
            if z.getWsName() in self._subscriptions_by_symbol:
                for s in self._subscriptions_by_symbol[z.getWsName()]:
                    await s(event)

    async def handleMiniTickerEvent(self, event, **kwargs):
        #print('handleMiniTickerEvent')
        #print(event)
        for z in event.getStream():
            if z.getWsName() in self._subscriptions_by_symbol:
                for s in self._subscriptions_by_symbol[z.getWsName()]:
                    await s(event)

    async def handleTickerEvent(self, event, **kwargs):
        #print('handleTickerEvent')
        #print(event)
        for z in event.getStream():
            if z.getWsName() in self._subscriptions_by_symbol:
                for s in self._subscriptions_by_symbol[z.getWsName()]:
                    await s(event)

    async def handleBookTickerEvent(self, event, **kwargs):
        #print('handleBookTickerEvent')
        #print(event)
        for z in event.getStream():
            if z.getWsName() in self._subscriptions_by_symbol:
                for s in self._subscriptions_by_symbol[z.getWsName()]:
                    await s(event)

    async def handlePartialBookDepthEvent(self, event, **kwargs):
        #print('handlePartialBookDepthEvent')
        #print(event)
        for z in event.getStream():
            if z.getWsName() in self._subscriptions_by_symbol:
                for s in self._subscriptions_by_symbol[z.getWsName()]:
                    await s(event)

    async def handleDifferentialDepthEvent(self, event, **kwargs):
        #print('handleDifferentialDepthEvent')
        #print(event)
        for z in event.getStream():
            if z.getWsName() in self._subscriptions_by_symbol:
                for s in self._subscriptions_by_symbol[z.getWsName()]:
                    await s(event)

