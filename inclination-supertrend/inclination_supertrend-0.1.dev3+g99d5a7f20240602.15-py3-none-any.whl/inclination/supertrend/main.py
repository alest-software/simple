import asyncio
import signal
from functools import partial
#import queue
from datetime import datetime
from dataclasses import dataclass, field
from collections import OrderedDict
import json
import pandas as pd
from binance_v3.restapi.api import BinanceRestApi
from binance_v3.websocket.websocket import BinanceWebSocket
from binance_v3.websocket.stream import KlineCandlestickStream
from binance_v3.websocket.symbol import Symbol
from binance_v3.websocket.interval import Interval
from ta.tr import TrueRange
from ta.atr import AverageTrueRange
from ta.supertrend import SuperTrend
import mqtt


@dataclass(order=True)
class Kline:
    timestamp:         float
    open_time:    float
    open:         float
    high:         float
    low:          float
    close:        float
    volume:       float
    close_time:   float
    #quote_asset_volume: float
    #nof_trades:   int
    #taker_buy_base_asset_volume:  float
    #taker_buy_quote_asset_volume: float
    #unused:       str
    closed:       bool

def print_kline(k):
    print(f'{k.timestamp:10.03f}|{k.open_time:10.03f}|{k.close_time:10.03f}|{k.open:12.2f}|{k.high:12.2f}|{k.low:12.2f}|{k.close:12.2f}|{k.volume:12f}|{str(k.closed)}')

q = asyncio.PriorityQueue()

tr = TrueRange()
atr = AverageTrueRange()
st = SuperTrend()
direction = 0

class Main:
    def __init__(self):
        pass #self._done = False
        self._klines = OrderedDict()

    async def _rest_api_callback(self, x):
        #print('_rest_api_callback')
        for k in x._klines[:-1]:
            # Kline open time
            # Open price
            # High price
            # Low price
            # Close price
            # Volume
            # Kline Close time
            # Quote asset volume
            # Number of trades
            # Taker buy base asset volume
            # Taker buy quote asset volume
            # Unused field, ignore.
            #dt = lambda x: datetime.fromtimestamp(x / 1000.0)
            dt = lambda x: x / 1000.0
            field_info = {
                    0:  { 'key': 'timestamp',    'parse': dt    },
                    1:  { 'key': 'open',         'parse': float },
                    2:  { 'key': 'high',         'parse': float },
                    3:  { 'key': 'low',          'parse': float },
                    4:  { 'key': 'close',        'parse': float },
                    5:  { 'key': 'volume',       'parse': float },
                    6:  { 'key': 'close_time',   'parse': dt   },
                    #7:  { 'key': 'quote_asset_volume', 'parse': float },
                    #8:  { 'key': 'nof_trades',   'parse': int   },
                    #9:  { 'key': 'taker_buy_base_asset_volume',  'parse': float },
                    #10: { 'key': 'taker_buy_quote_asset_volume', 'parse': float },
                    #11: { 'key': 'unused',       'parse': str   },
            }
            d = dict(enumerate(k))
            z = {k: d[k] for k in field_info}
            v = {field_info[k]['key']: field_info[k]['parse'](v) for k, v in z.items()}
            #slot = int(v['timestamp'] / 60)
            v['open_time'] = v['timestamp'] #float(slot * 60)
            #v['close_time'] = ((slot + 1) * 60) - .001
            v['closed'] = True
            kl = Kline(**v)
            #print_kline(kl)
            await q.put(kl)

            #print_kline(kl)

    async def _web_socket_callback(self, x, y):
        #print(x._k._x)
        v = {
            'timestamp':    x._E,
            'open_time':    x._k._t,
            'open':         x._k._o,
            'high':         x._k._h,
            'low':          x._k._l,
            'close':        x._k._c,
            'volume':       x._k._v,
            'close_time':   x._k._T,
            #'quote_asset_volume': x._k._q,
            #'nof_trades':   x._k._n,
            #'taker_buy_base_asset_volume':  x._k._V,
            #'taker_buy_quote_asset_volume': x._k._Q,
            #'unused': None
            'closed': x._k._x
        }
        kl = Kline(**v)
        await q.put(kl)
        #print_kline(kl)
        if not self._future1.done():
            #print('Received first...')
            self._future1.set_result(True)

    async def rest_api_runner(self, *, symbol, interval, limit):
        #print('RestAPI start.')
        await self._future1
        print('RestAPI start.')
        await asyncio.sleep(1)
        binance = BinanceRestApi()
        #await binance.ping(_rest_api_callback)
        await binance.klines(symbol, interval, limit=limit, callback=self._rest_api_callback)
        await binance.close()
        self._future2.set_result(True)
        print('RestAPI done.')

    async def web_socket_runner(self, *, symbol, interval):
        print('WebSocket start.')
        ws = BinanceWebSocket()
        self.ws = ws
        interval = Interval.from_str(interval)
        await ws.subscribe(KlineCandlestickStream(Symbol(symbol), interval), self._web_socket_callback)
        await ws.main()
        #await ws.open()
        #await ws.close()
        print('WebSocket done.')

    async def queue_runner(self, *, limit):
        await self._future2
        print('Queue start.')
        kl = await q.get()
        while kl:
            tr_val = tr(high=kl.high, low=kl.low, close=kl.close, store=kl.closed)
            atr_val = atr(true_range=tr_val, store=kl.closed)
            st_val = st(high=kl.high, low=kl.low, close=kl.close, atr=atr_val, store=kl.closed)
            #if kl.closed:
            #print_kline(kl)
            #print(tr_val, atr_val, st_val)
            global direction
            if st_val[1] != direction:
                direction = st_val[1]
                print(f'{datetime.fromtimestamp(kl.timestamp)}\t{direction:2d}\t{kl.close:.03f}')
                trend = "Uptrend" if (direction > 0) else "Downtrend"
                payload = json.dumps(f'{datetime.fromtimestamp(kl.timestamp)}\n{trend} detected at {kl.close:.03f}')
                await self._mqtt.publish('inclination/telegram/message', payload)
#            self._klines[kl.open_time] = vars(kl)
#            if len(self._klines) > limit:
#                self._klines.popitem(last=False)
#
#            values = list(self._klines.values())
#            data = {k: [dict[k] for dict in values] for k in values[0]}
#            df = pd.DataFrame(data)
#            df['open_time'] = pd.to_datetime(df['open_time'], unit='s')
#            df.set_index('open_time', inplace=True)
#
#            #print('\033[2J\033[H', end='')
#            #print(df)
#            await self.supertrend(df)
#
            kl = await q.get()
        print('Queue done.')

    async def on_mqtt_connect(self, client, userdata, flags, rc):
        print('MQTT connect')
        await self._mqtt.subscribe('inclination/config/supertrend/0/length')
        await self._mqtt.subscribe('inclination/config/supertrend/0/multiplier')

    async def on_mqtt_disconnect(self, client, userdata, rc):
        print('MQTT disconnect')

    async def on_conf_length(self, topic, payload, qos, retain):
        print(payload)

    async def on_conf_multiplier(self, topic, payload, qos, retain):
        print(payload)

    async def mqtt_runner(self, mqtt_done, mqtt_host='localhost'):
        def _(client, userdata, msg, handler):
            payload = json.loads(msg.payload) if msg.payload else None
            return handler(msg.topic, payload, msg.qos, msg.retain)

        print('chek!')
        self._mqtt = mqtt.Client()
        self._mqtt.on_connect = self.on_mqtt_connect
        self._mqtt.on_disconnect = self.on_mqtt_disconnect
        self._mqtt.message_callback_add('inclination/config/supertrend/0/length', lambda c, u, m: _(c, u, m, self.on_conf_length))
        self._mqtt.message_callback_add('inclination/config/supertrend/0/multiplier', lambda c, u, m: _(c, u, m, self.on_conf_multiplier))
        loop = asyncio.get_running_loop()
        self._mqtt.loop = loop
        await self._mqtt.connect(mqtt_host)
        await mqtt_done
        await self._mqtt.disconnect()
        print('MQTT done.')

    async def on_sigint(self):
        print('SIGINT')
        await self.ws.stop()
        await q.put(None)
        self._mqtt_done.set_result(0)

    async def supertrend(self, df, *, length=10, multiplier=3):

        df['tr'] = df.apply(lambda x: max([x.high - x.low, x.high - x.open, x.open - x.low]), axis=1)
        df['atr'] = df['tr'].rolling(length).mean()
        df['green'] = df.close - (df.atr * multiplier)
        df['red'] = df.close + (df.atr * multiplier)
        df['down'] = df.apply(lambda x: 1 if x.close < x.green else 0, axis=1)
        df['up'] = df.apply(lambda x: 1 if x.close > x.red else 0, axis=1)
        #((df.high - df.low), abs(df.open - df.high)).max() #, abs(df.open - df.low))
        print('\033[2J\033[H', end='')
        print(df)

    async def __call__(self):
        loop = asyncio.get_running_loop()
        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(self.on_sigint)()))

        self._future1 = loop.create_future()
        self._future2 = loop.create_future()
        self._mqtt_done = loop.create_future()

        interval = '1h'
        limit = 500

        t0 = asyncio.create_task(self.mqtt_runner(self._mqtt_done))
        t1 = asyncio.create_task(self.rest_api_runner(symbol='BTCUSDT', interval=interval, limit=limit))
        t3 = asyncio.create_task(self.queue_runner(limit=limit))
        t2 = asyncio.create_task(self.web_socket_runner(symbol='btcusdt', interval=interval))

        await asyncio.gather(t0, t1, t2, t3)


def main():
    x = Main()
    asyncio.run(x())

if __name__ == '__main__':
    main()

