
from enum import Enum


class UpdateSpeed(Enum):
	UPDATESPEED_100ms  = (100)
	UPDATESPEED_1000ms = (1000)

	def __init__(self, val):
		self._val = val

	def __str__(self):
		return '{0}ms'.format(self._val)

	@staticmethod
	def from_str(label):
		return getattr(Interval, 'UPDATESPEED_{0}'.format(label))

