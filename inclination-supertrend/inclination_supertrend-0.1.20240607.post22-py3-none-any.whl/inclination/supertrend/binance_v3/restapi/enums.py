#!/usr/bin/env python3

from enum import Enum

class SymbolStatus(Enum):
	PRE_TRADING = 'PRE_TRADING'
	TRADING = 'TRADING'
	POST_TRADING = 'POST_TRADING'
	END_OF_DAY = 'END_OF_DAY'
	HALT = 'HALT'
	AUCTION_MATCH = 'AUCTION_MATCH'
	BREAK = 'BREAK'

	def __init__(self, label):
		self._label = label

	def __str__(self):
		return '{0}'.format(self._label)

	@staticmethod
	def from_str(label):
		return getattr(SymbolStatus, label)


class SymbolType(Enum):
	SPOT = 'SPOT'


class OrderStatus(Enum):
	NEW = 'NEW'
	PARTIALLY_FILLED = 'PARTIALLY_FILLED'
	FILLED = 'FILLED'
	CANCELED = 'CANCELED'
	PENDING_CANCEL = 'PENDING_CANCEL'
	REJECTED = 'REJECTED'
	EXPIRED = 'EXPIRED'

	@staticmethod
	def from_str(label):
		return getattr(OrderStatus, label)


class OcoStatus(Enum):
	RESPONSE = 'RESPONSE'
	EXEC_STARTED = 'EXEC_STARTED'
	ALL_DONE = 'ALL_DONE'


class OcoOrderStatus(Enum):
	EXECUTING = 'EXECUTING'
	ALL_DONE = 'ALL_DONE'
	REJECT = 'REJECT'


class ContingencyType(Enum):
	OCO = 'OCO'


class OrderType(Enum):
	LIMIT = 'LIMIT'
	MARKET = 'MARKET'
	STOP_LOSS = 'STOP_LOSS'
	STOP_LOSS_LIMIT = 'STOP_LOSS_LIMIT'
	TAKE_PROFIT = 'TAKE_PROFIT'
	TAKE_PROFIT_LIMIT = 'TAKE_PROFIT_LIMIT'
	LIMIT_MAKER = 'LIMIT_MAKER'

	def __init__(self, label):
		self._label = label

	def __str__(self):
		return '{0}'.format(self._label)

	@staticmethod
	def from_str(label):
		return getattr(OrderType, label)


class OrderSide(Enum):
	BUY = 'BUY'
	SELL = 'SELL'

	def __init__(self, label):
		self._label = label

	def __str__(self):
		return '{0}'.format(self._label)

	@staticmethod
	def from_str(label):
		return getattr(OrderSide, label)


class TimeInForce(Enum):
	GTC = 'GTC'
	IOC = 'IOC'
	FOK = 'FOK'

	def __init__(self, label):
		self._label = label

	def __str__(self):
		return '{0}'.format(self._label)

	@staticmethod
	def from_str(label):
		return getattr(TimeInForce, label)


class KlineInterval(Enum):
	_1m = '1m'
	_3m = '3m'
	_5m = '5m'
	_15m = '15m'
	_30m = '30m'
	_1h = '1h'
	_2h = '2h'
	_4h = '4h'
	_6h = '6h'
	_8h = '8h'
	_12h = '12h'
	_1d = '1d'
	_3d = '3d'
	_1w = '1w'
	_1M = '1M'


class RateLimitType(Enum):
	REQUEST_WEIGHT = 'REQUEST_WEIGHT'
	ORDERS = 'ORDERS'
	RAW_REQUESTS = 'RAW_REQUESTS'


class RateLimitInterval(Enum):
	SECOND = 'SECOND'
	MINUTE = 'MINUTE'
	DAY = 'DAY'


