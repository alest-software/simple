from attr import define, frozen, field

#@frozen #(hash=True)
class Symbol(str):
    #val: str

    def __new__(cls, string):
        print(f'new Symbol({string})<<<<<<<<<<<<<<<<<<<<<')
        #self.__attrs_init__(val)
        instance = super().__new__(cls, string)
        return instance
#        assert type(val) == str
#
#        self._val = val

#    def __eq__(self, b):
#        return (type(self) == type(b)) and (self._val == b._val)

    def getName(self):
        return self.upper()

    def getStreamName(self):
        return self.lower()

@frozen
class SymbolFactory:
    instances: dict = field(factory=dict)

    def get_instance(self, name: str):
        name = name.lower()
        if name not in self.instances:
            inst = Symbol(name)
            self.instances[name] = inst
        return self.instances[name]

#symbol = Symbol('BtcUsdt')
#print(symbol)
#print(symbol.getName())
#print(symbol.getStreamName())

#sf = SymbolFactory()
#print(sf.get_instance('abc'))
#print(sf.get_instance('aBc'))
#print(sf.get_instance('aB~c'))
#print(sf.get_instance('aBC'))
#print(sf)

#some = {symbol: 2}
#some[Symbol('Some')] = 3
#print(some)

