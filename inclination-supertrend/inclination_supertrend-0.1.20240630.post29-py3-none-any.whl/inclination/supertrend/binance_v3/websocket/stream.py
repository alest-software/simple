#from abc import ABC, abstractmethod
from attrs import frozen, define, field
from attrs.validators import instance_of
from enum import Enum
try:
    from .interval import *
    from .updatespeed import *
    from .level import *
    from .symbol import *
except:
    from interval import *
    from updatespeed import *
    from level import *
    from symbol import *


#class StreamBase(ABC):
#    pass
#    @abstractmethod
#    def getWsName(self):
#        '''raise WebsocketError('baseclass')'''
#        print('No such...')
#        return None


@frozen(kw_only=True)
class AggregateTradeStream: #(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))

    def __init__(self, **kwargs):
        #print(f'Stream {kwargs} <<<<<<<<<<<<<<<<<<<<<')
        self.__attrs_init__(**kwargs)

#    def getWsName(self):
#        return '{0}@aggTrade'.format(self.symbol.getStreamName())


@frozen(kw_only=True)
class TradeStream: #(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))

    def __init__(self, **kwargs):
        #print(f'Stream {kwargs} <<<<<<<<<<<<<<<<<<<<<')
        self.__attrs_init__(**kwargs)

#    def getWsName(self):
#        return '{0}@trade'.format(self.symbol.getStreamName())


@frozen(kw_only=True)
class KlineCandlestickStream: #(StreamBase):
    symbol:   Symbol = field(validator=instance_of(Symbol))
    interval: Interval = field(validator=instance_of(Interval))

    def __init__(self, **kwargs):
        #print(f'Stream {kwargs} <<<<<<<<<<<<<<<<<<<<<')
        self.__attrs_init__(**kwargs)

#    def getWsName(self):
#        return '{0}@kline_{1}'.format(self.symbol.getStreamName(), self.interval)


@frozen(kw_only=True)
class IndividualSymbolMiniTickerStream: #(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))

    def __init__(self, **kwargs):
        #print(f'Stream {kwargs} <<<<<<<<<<<<<<<<<<<<<')
        self.__attrs_init__(**kwargs)

#    def getWsName(self):
#        return '{0}@miniTicker'.format(self.symbol.getStreamName())


@frozen(kw_only=True)
class AllMarketMiniTickersStream: #(StreamBase):
    ''''''
    def __init__(self, **kwargs):
        #print(f'Stream {kwargs} <<<<<<<<<<<<<<<<<<<<<')
        self.__attrs_init__(**kwargs)

#    def getWsName(self):
#        return '!miniTicker@arr'


@frozen(kw_only=True)
class IndividualSymbolTickerStream: #(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))

    def __init__(self, **kwargs):
        #print(f'Stream {kwargs} <<<<<<<<<<<<<<<<<<<<<')
        self.__attrs_init__(**kwargs)

#    def getWsName(self):
#        return '{0}@ticker'.format(self.symbol.getStreamName())


@frozen(kw_only=True)
class AllMarketTickersStream: #(StreamBase):
    ''''''
    def __init__(self, **kwargs):
        #print(f'Stream {kwargs} <<<<<<<<<<<<<<<<<<<<<')
        self.__attrs_init__(**kwargs)

#    def getWsName(self):
#        return '!ticker@arr'


@frozen(kw_only=True)
class IndividualSymbolBookTickerStream: #(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))

    def __init__(self, **kwargs):
        #print(f'Stream {kwargs} <<<<<<<<<<<<<<<<<<<<<')
        self.__attrs_init__(**kwargs)

#    def getWsName(self):
#        return '{0}@bookTicker'.format(self.symbol.getStreamName())


#@frozen(kw_only=True)
#class AllBookTickersStream: #(StreamBase):
#    def getWsName(self):
#        return '!bookTicker'


@frozen(kw_only=True)
class PartialBookDepthStream: #(StreamBase):
    ''''''
    def __init__(self, **kwargs):
        #print(f'Stream {kwargs} <<<<<<<<<<<<<<<<<<<<<')
        self.__attrs_init__(**kwargs)

    #symbol: Symbol = field(validator=instance_of(Symbol))
    #level: Level = field(validator=instance_of(Level))
    #rate: UpdateSpeed = field(validator=instance_of(UpdateSpeed))

#    def getWsName(self):
#        return '{0}@depth{1}@{2}'.format(self.symbol.getStreamName(), self.level, self.rate)


@frozen(kw_only=True)
class DiffDepthStream: #(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))
    #rate: UpdateSpeed = field(validator=instance_of(UpdateSpeed))

    def __init__(self, **kwargs):
        #print(f'Stream {kwargs} <<<<<<<<<<<<<<<<<<<<<')
        self.__attrs_init__(**kwargs)

#    def getWsName(self):
#        return None
#        return '{0}@depth@{1}'.format(self.symbol.getStreamName(), self.rate)


#stream0 = AggregateTradeStream(symbol=Symbol('BTCUSDT'))
#stream1 = KlineCandlestickStream(symbol=Symbol('BTCUSDT'), interval=Interval.INTERVAL_1m)
#stream2 = TradeStream(symbol=Symbol('BTCUSDT'))
#stream3 = IndividualSymbolMiniTickerStream(symbol=Symbol('BTCUSDT'))
#stream4 = AllMarketMiniTickersStream()
#stream5 = IndividualSymbolTickerStream(symbol=Symbol('BTCUSDT'))
#stream6 = AllMarketTickersStream()
#stream7 = IndividualSymbolBookTickerStream(symbol=Symbol('BTCUSDT'))
#stream8 = AllBookTickersStream()
#stream9 = PartialBookDepthStream(symbol=Symbol('BTCUSDT'), level=Level.LEVEL_5, rate=UpdateSpeed.UPDATESPEED_1000ms)
#stream10 = DiffDepthStream(symbol=Symbol('BTCUSDT'), rate=UpdateSpeed.UPDATESPEED_1000ms)
#some = {stream0: 1, stream1: 3, stream2: 5, stream3: 7, stream4: 9, stream5: 8, stream6: 6, stream7: 4, stream8: 2, stream9: 0, stream10: -1}
#print(some)
#exit(0)
