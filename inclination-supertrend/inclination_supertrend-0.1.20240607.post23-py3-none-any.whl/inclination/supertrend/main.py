import asyncio
#from asyncio import Task
import logging
import signal
from functools import partial
#import queue
from datetime import datetime
#from dataclasses import dataclass, field
from attr import define, frozen, field
from psygnal import Signal
from collections import OrderedDict
import json
import re
import pandas as pd
from .binance_v3.restapi.api import BinanceRestApi
from .binance_v3.websocket.websocket import BinanceWebSocket
from .binance_v3.websocket.stream import KlineCandlestickStream
from .binance_v3.websocket.symbol import Symbol
from .binance_v3.websocket.interval import Interval
from .ta.tr import TrueRange
from .ta.atr import AverageTrueRange
from .ta.supertrend import SuperTrend
from .ta.sma import SimpleMovingAverage
from .ta.ema import ExponentialMovingAverage
from . import mqtt


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)


#@dataclass(order=True)
@define(order=True)
class Kline:
    timestamp:    float
    open_time:    float
    open:         float
    high:         float
    low:          float
    close:        float
    volume:       float
    close_time:   float
    #quote_asset_volume: float
    #nof_trades:   int
    #taker_buy_base_asset_volume:  float
    #taker_buy_quote_asset_volume: float
    #unused:       str
    closed:       bool


@define
class Context:
    base: str = None
    quote: str = None
    interval: str = None
    runner: str = None


@frozen
class Sym:
    exchange: str
    base: str
    quote: str


@define
class SymContext:
    tr: TrueRange = TrueRange()
    atr: AverageTrueRange = AverageTrueRange()
    st: SuperTrend = SuperTrend()
    direction: int = 0
    sma: SimpleMovingAverage = SimpleMovingAverage()
    ema: ExponentialMovingAverage = ExponentialMovingAverage()


def print_kline(k):
    print(f'{k.timestamp:10.03f}|{k.open_time:10.03f}|{k.close_time:10.03f}|{k.open:12.2f}|{k.high:12.2f}|{k.low:12.2f}|{k.close:12.2f}|{k.volume:12f}|{str(k.closed)}',
            end='\r\n' if k.closed else '\r')


class RestApiAdapter:
    def __init__(self, queue):
        self._queue = queue

    async def __call__(self, x):
        for k in x._klines[:-1]:
            # Kline open time
            # Open price
            # High price
            # Low price
            # Close price
            # Volume
            # Kline Close time
            # Quote asset volume
            # Number of trades
            # Taker buy base asset volume
            # Taker buy quote asset volume
            # Unused field, ignore.
            #dt = lambda x: datetime.fromtimestamp(x / 1000.0)
            dt = lambda x: x / 1000.0
            field_info = {
                    0:  { 'key': 'timestamp',    'parse': dt    },
                    1:  { 'key': 'open',         'parse': float },
                    2:  { 'key': 'high',         'parse': float },
                    3:  { 'key': 'low',          'parse': float },
                    4:  { 'key': 'close',        'parse': float },
                    5:  { 'key': 'volume',       'parse': float },
                    6:  { 'key': 'close_time',   'parse': dt   },
                    #7:  { 'key': 'quote_asset_volume', 'parse': float },
                    #8:  { 'key': 'nof_trades',   'parse': int   },
                    #9:  { 'key': 'taker_buy_base_asset_volume',  'parse': float },
                    #10: { 'key': 'taker_buy_quote_asset_volume', 'parse': float },
                    #11: { 'key': 'unused',       'parse': str   },
            }
            d = dict(enumerate(k))
            z = {k: d[k] for k in field_info}
            v = {field_info[k]['key']: field_info[k]['parse'](v) for k, v in z.items()}
            v['open_time'] = v['timestamp']
            v['closed'] = True
            kl = Kline(**v)
            await self._queue.put(kl)


class WebsocketAdapter:
    def __init__(self, queue):
        self._queue = queue

    async def __call__(self, x, y):
        kl = Kline(**{
            'timestamp':    x.E,
            'open_time':    x.k.t,
            'open':         x.k.o,
            'high':         x.k.h,
            'low':          x.k.l,
            'close':        x.k.c,
            'volume':       x.k.v,
            'close_time':   x.k.T,
            'closed':       x.k.x
        })
        if x.k.x:
            await self._queue.put(kl)


class KlineRunner:
    def __init__(self, m, base, quote, interval, symbol='BTCUSDT', interval_sec=60, max_limit=100):
        self._m = m
        self._base = base
        self._quote = quote
        self._interval = interval
        self._symbol = f'{base}{quote}'.upper()
        self._interval_sec = interval_sec
        self._max_limit = max_limit

        self._prev_slot = 0

        self._queue = asyncio.PriorityQueue()
        self._websocket_adapter = WebsocketAdapter(self._queue)

    async def queue_runner(self):
        await asyncio.sleep(1)
        kl = await self._queue.get()
        while kl:
            open_slot = int(kl.open_time / self._interval_sec)
            expected_slot = self._prev_slot + 1
            if open_slot != expected_slot:

                if open_slot > expected_slot:
                    limit = min(open_slot - expected_slot + 3, self._max_limit)
                    logger.info(f'Fetching... {limit}')
                    cb = RestApiAdapter(self._queue)
                    binance = BinanceRestApi()
                    symbol = self._symbol
                    interval = self._interval
                    #limit = 10
                    await binance.klines(symbol=symbol, interval=interval, limit=limit, callback=cb)
                    await binance.close()
                    if self._prev_slot == 0:
                        self._prev_slot = open_slot - limit + 2
                        logger.info(f'Initial slot {self._prev_slot}')
                    logger.info('Fetch done')
                else:
                    logger.info(f'Skipped {open_slot}')
            else:

                self._prev_slot = open_slot

                if kl.closed:
                    base_topic = f'inclination/kline/{self._base}/{self._quote}/{self._interval}/{kl.open_time:.0f}'
                    await self._m._mqtt.publish(f'{base_topic}/open', kl.open)
                    await self._m._mqtt.publish(f'{base_topic}/high', kl.high)
                    await self._m._mqtt.publish(f'{base_topic}/low', kl.low)
                    await self._m._mqtt.publish(f'{base_topic}/close', kl.close)
                    await self._m._mqtt.publish(f'{base_topic}/volume', kl.volume)

                    data = json.dumps({
                        'open': kl.open,
                        'high': kl.high,
                        'low': kl.low,
                        'close': kl.close,
                        'volume': kl.volume,
                        })
                    await self._m._mqtt.publish(f'{base_topic}', data)

                    print(data)

            kl = await self._queue.get()

        print('----------------------------------------')

    async def stop(self):
        await self._queue.put(None)

    async def __call__(self):
        symbol = self._symbol
        interval = Interval.from_str(self._interval)
        subs = await self._m.ws.kline(symbol=Symbol(symbol), interval=interval, cb=self._websocket_adapter)
        self._subs = subs

        t1 = asyncio.create_task(self.queue_runner())
        await asyncio.gather(t1)
        #await asyncio.sleep(1)
        #symbol='BTCUSDT'
        #interval = Interval.from_str(self._interval)
        #subs = await self._m.ws.unsubscribe(KlineCandlestickStream(Symbol(symbol), interval), self._websocket_adapter)
        #print(subs)
        await self._subs.unsubscribe()
        await asyncio.sleep(1)
        print('========================================')


class Main:
    def __init__(self):
        pass #self._done = False
        #self._klines = OrderedDict()
        self._context = {}
        self._on_connect = Signal(str)
        self._st_context = {Sym('binance', 'btc', 'usdt'): SymContext()}

    async def web_socket_runner(self, *, symbol, interval):
        logger.info('WebSocket start.')
        ws = BinanceWebSocket()
        self.ws = ws
        await ws.main()
        logger.info('WebSocket done.')

    async def on_kline_open(self, payload, *, base, quote, interval, timestamp):
        pass # print('O', payload, base, quote, interval, timestamp)

    async def on_kline_high(self, payload, *, base, quote, interval, timestamp):
        pass # print('H', payload, base, quote, interval, timestamp)

    async def on_kline_low(self, payload, *, base, quote, interval, timestamp):
        pass # print('L', payload, base, quote, interval, timestamp)

    async def on_kline_close(self, payload, *, base, quote, interval, timestamp):
        pass # print('C', payload, base, quote, interval, timestamp)

    async def on_kline_volume(self, payload, *, base, quote, interval, timestamp):
        pass # print('V', payload, base, quote, interval, timestamp)

    async def on_kline(self, payload, *, base, quote, interval, timestamp):
        logger.debug(f'{base}, {quote}, {interval}, {timestamp}, {payload}')
        timestamp = int(timestamp)
        #open = payload['open']
        high = payload['high']
        low = payload['low']
        close = payload['close']
        volume = payload['volume']

        ctxt = self._st_context[Sym('binance', base, quote)]

        sma_val = ctxt.sma(close=close, store=True)
        ema_val = ctxt.ema(close=close, sma=sma_val, store=True)

        tr_val = ctxt.tr(high=high, low=low, close=close, store=True)
        atr_val = ctxt.atr(true_range=tr_val, store=True)
        st_val = ctxt.st(high=high, low=low, close=close, atr=atr_val, store=True)

        if st_val[1] != ctxt.direction:
            ctxt.direction = st_val[1]
            print(f'{datetime.fromtimestamp(timestamp)}\t{ctxt.direction:2d}\t{close:.03f}')
            trend = "Uptrend" if (ctxt.direction > 0) else "Downtrend"
            payload = json.dumps(f'{datetime.fromtimestamp(timestamp)}\n{trend} detected at {close:.03f}')
            await self._mqtt.publish('inclination/telegram/message', payload)

        print(f'{"timestamp":16} {"high":16} {"low":16} {"close":16} {"volume":16} {"ema":16} {"tr":16} {"atr":16} {"st":16}')
        print(f'{timestamp:16d} {high:16.8f} {low:16.8f} {close:16.8f} {volume:16.8f} {ema_val:16.8f} {tr_val:16.8f} {atr_val:16.8f} {st_val[0]}')

    async def on_mqtt_connect(self, client, userdata, flags, rc):
        logger.info('MQTT connect')
        await self._mqtt.subscribe('inclination/config/supertrend/0/length')
        await self._mqtt.subscribe('inclination/config/supertrend/0/multiplier')
        await self._mqtt.subscribe('inclination/config/kline/0/+/base')
        await self._mqtt.subscribe('inclination/config/kline/0/+/quote')
        await self._mqtt.subscribe('inclination/config/kline/0/+/interval')
        await self._mqtt.subscribe('inclination/kline/+/+/+/+')
        await self._mqtt.subscribe('inclination/kline/+/+/+/+/open')
        await self._mqtt.subscribe('inclination/kline/+/+/+/+/high')
        await self._mqtt.subscribe('inclination/kline/+/+/+/+/low')
        await self._mqtt.subscribe('inclination/kline/+/+/+/+/close')
        await self._mqtt.subscribe('inclination/kline/+/+/+/+/volume')

    async def on_mqtt_disconnect(self, client, userdata, rc):
        logger.info('MQTT disconnect')

    async def on_conf_length(self, payload, *, topic):
        logger.info('f{topic}, {payload}')

    async def on_conf_multiplier(self, payload, *, topic):
        logger.info(f'{topic}, {payload}')

    async def on_conf_kline_base(self, payload, *, retain, name):
        if name not in self._context:
            self._context[name] = Context()
        self._context[name].base = payload
        await self.on_conf_kline(name)

    async def on_conf_kline_quote(self, payload, *, name):
        if name not in self._context:
            self._context[name] = Context()
        self._context[name].quote = payload
        await self.on_conf_kline(name)

    async def on_conf_kline_interval(self, payload, *, name):
        if name not in self._context:
            self._context[name] = Context()
        self._context[name].interval = payload
        await self.on_conf_kline(name)

    async def on_conf_kline(self, name):
        if self._context[name].base and self._context[name].quote and self._context[name].interval:
            logger.info(self._context)
            runner = KlineRunner(self, self._context[name].base, self._context[name].quote, self._context[name].interval)
            self._context[name].runner = runner
            await runner()

    async def mqtt_runner(self, mqtt_done, mqtt_host='localhost'):

        class _:
            def __init__(self, handler, regex=None, do_qos=False, do_retain=False):
                self._handler = handler
                self._regex = re.compile(regex) if regex else None
                self._do_qos = do_qos
                self._do_retain = do_retain
            async def __call__(self, client, userdata, msg):
                params = {}
                if self._do_qos:
                    params['qos'] = msg.qos
                if self._do_retain:
                    params['retain'] = msg.retain
                instance = self._regex.match(msg.topic).groupdict() if self._regex else {'topic': msg.topic}
                payload = json.loads(msg.payload) if msg.payload else None
                await self._handler(payload, **params, **instance)

        logger.info('chek!')
        self._mqtt = mqtt.Client()
        self._mqtt.on_connect = self.on_mqtt_connect
        self._mqtt.on_disconnect = self.on_mqtt_disconnect

        self._mqtt.message_callback_add('inclination/config/supertrend/0/length', _(self.on_conf_length)) #lambda c, u, m: _(c, u, m, self.on_conf_length))
        self._mqtt.message_callback_add('inclination/config/supertrend/0/multiplier', _(self.on_conf_multiplier)) # lambda c, u, m: _(c, u, m, self.on_conf_multiplier))

        self._mqtt.message_callback_add('inclination/config/kline/0/+/base', _(self.on_conf_kline_base, r'inclination/config/kline/0/(?P<name>[^/]+)/base', do_retain=True)) #lambda c, u, m: _(c, u, m, self.on_conf_kline_base))
        self._mqtt.message_callback_add('inclination/config/kline/0/+/quote', _(self.on_conf_kline_quote, r'inclination/config/kline/0/(?P<name>[^/]+)/quote')) #lambda c, u, m: _(c, u, m, self.on_conf_kline_quote))
        self._mqtt.message_callback_add('inclination/config/kline/0/+/interval', _(self.on_conf_kline_interval, r'inclination/config/kline/0/(?P<name>[^/]+)/interval')) #lambda c, u, m: _(c, u, m, self.on_conf_kline_quote))

        self._mqtt.message_callback_add('inclination/kline/+/+/+/+', _(self.on_kline,
            r'inclination/kline/(?P<base>[^/]+)/(?P<quote>[^/]+)/(?P<interval>[^/]+)/(?P<timestamp>[^/]+)'))

        self._mqtt.message_callback_add('inclination/kline/+/+/+/+/open', _(self.on_kline_open, r'inclination/kline/(?P<base>[^/]+)/(?P<quote>[^/]+)/(?P<interval>[^/]+)/(?P<timestamp>[^/]+)/open'))
        self._mqtt.message_callback_add('inclination/kline/+/+/+/+/high', _(self.on_kline_high, r'inclination/kline/(?P<base>[^/]+)/(?P<quote>[^/]+)/(?P<interval>[^/]+)/(?P<timestamp>[^/]+)/high'))
        self._mqtt.message_callback_add('inclination/kline/+/+/+/+/low', _(self.on_kline_low, r'inclination/kline/(?P<base>[^/]+)/(?P<quote>[^/]+)/(?P<interval>[^/]+)/(?P<timestamp>[^/]+)/low'))
        self._mqtt.message_callback_add('inclination/kline/+/+/+/+/close', _(self.on_kline_close, r'inclination/kline/(?P<base>[^/]+)/(?P<quote>[^/]+)/(?P<interval>[^/]+)/(?P<timestamp>[^/]+)/close'))
        self._mqtt.message_callback_add('inclination/kline/+/+/+/+/volume', _(self.on_kline_volume, r'inclination/kline/(?P<base>[^/]+)/(?P<quote>[^/]+)/(?P<interval>[^/]+)/(?P<timestamp>[^/]+)/volume'))

        loop = asyncio.get_running_loop()
        self._mqtt.loop = loop
        await self._mqtt.connect(mqtt_host)
        await mqtt_done
        await self._mqtt.disconnect()
        logger.info('MQTT done.')

    async def on_sigint(self):
        logger.info('SIGINT')

        for _, ctxt in self._context.items():
            await ctxt.runner.stop()

        await asyncio.sleep(2)

        await self.ws.stop()

        for r, v in self._context.items():
            await v.runner._queue.put(None)

        self._mqtt_done.set_result(0)

    async def __call__(self):
        loop = asyncio.get_running_loop()
        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(self.on_sigint)()))

        self._future1 = loop.create_future()
        self._future2 = loop.create_future()
        self._mqtt_done = loop.create_future()

        interval = '1m'
        limit = 500

        t0 = asyncio.create_task(self.mqtt_runner(self._mqtt_done))
        t2 = asyncio.create_task(self.web_socket_runner(symbol='btcusdt', interval=interval))
        t1 = asyncio.sleep(0.1) #asyncio.create_task(self.rest_api_runner(symbol='BTCUSDT', interval=interval, limit=limit))
        t3 = asyncio.sleep(0.1) #asyncio.create_task(self.queue_runner(base='btc', quote='usdt', interval=interval, limit=limit))

        await asyncio.gather(t0, t1, t2, t3)


def main():
    x = Main()
    asyncio.run(x())

if __name__ == '__main__':
    main()

