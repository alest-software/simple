import numpy as np

class TrueRange:
    def __init__(self):
        self._prev_close = np.nan
        
    def __call__(self, high, low, close, store=True):
        if not np.isnan(self._prev_close):
            true_range = max([high-low, abs(self._prev_close-high), abs(self._prev_close-low)])
        else:
            true_range = np.nan
            
        if store:
            self._prev_close = close
            
        return true_range

