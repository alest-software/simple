
class Symbol(str):
    pass

