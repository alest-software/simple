import os
from functools import partial, singledispatchmethod
import signal
import json
import time
import parse
import argparse
import asyncio
import socket
import uuid
from .internal import *
from . import mqtt
try:
    from attrs import define, field
except ImportError:
    from attr import define, field
from inclination.binance.api.websocket.client import *
from inclination.binance.api.websocket.stream import *
from inclination.binance.api.websocket.klineupdate import *
from inclination.binance.api.websocket.symbol import Symbol
from inclination.binance.api.websocket.interval import Interval
import fastdds
from inclination.idl_ex.ohlcv import Ohlcv, OhlcvPubSubType
from inclination.idl_ex.ohlcv import OhlcvValue, OhlcvValuePubSubType


config = Config()
interval = config.get_interval('1m')
interval.timeout = 60

participant_qos = fastdds.DomainParticipantQos()
participant = fastdds.DomainParticipantFactory.get_instance().create_participant(0, participant_qos)

ohlcv_pstype = OhlcvPubSubType()
ohlcv_pstype.set_name('ohlcv')
type_support = fastdds.TypeSupport(ohlcv_pstype)
participant.register_type(type_support)

value_pstype = OhlcvValuePubSubType()
value_pstype.set_name('value')
value_ts = fastdds.TypeSupport(value_pstype)
participant.register_type(value_ts)

ohlcv_topic = participant.create_topic("ohlcv", ohlcv_pstype.get_name(), fastdds.TOPIC_QOS_DEFAULT)

open_topic = participant.create_topic("open", value_pstype.get_name(), fastdds.TOPIC_QOS_DEFAULT)
high_topic = participant.create_topic("high", value_pstype.get_name(), fastdds.TOPIC_QOS_DEFAULT)
low_topic = participant.create_topic("low", value_pstype.get_name(), fastdds.TOPIC_QOS_DEFAULT)
close_topic = participant.create_topic("close", value_pstype.get_name(), fastdds.TOPIC_QOS_DEFAULT)
volume_topic = participant.create_topic("volume", value_pstype.get_name(), fastdds.TOPIC_QOS_DEFAULT)

publisher = participant.create_publisher(fastdds.PUBLISHER_QOS_DEFAULT, None)

ohlcv_writer_qos = fastdds.DataWriterQos()
ohlcv_writer_qos.reliability().kind = fastdds.RELIABLE_RELIABILITY_QOS
ohlcv_writer_qos.durability().kind = fastdds.TRANSIENT_LOCAL_DURABILITY_QOS
ohlcv_writer_qos.history().kind = fastdds.KEEP_LAST_HISTORY_QOS
ohlcv_writer_qos.history().depth = 2**5
ohlcv_writer = publisher.create_datawriter(ohlcv_topic, ohlcv_writer_qos, None)

open_writer = publisher.create_datawriter(open_topic, fastdds.DATAWRITER_QOS_DEFAULT, None)
high_writer = publisher.create_datawriter(high_topic, fastdds.DATAWRITER_QOS_DEFAULT, None)
low_writer = publisher.create_datawriter(low_topic, fastdds.DATAWRITER_QOS_DEFAULT, None)
close_writer = publisher.create_datawriter(close_topic, fastdds.DATAWRITER_QOS_DEFAULT, None)
volume_writer = publisher.create_datawriter(volume_topic, fastdds.DATAWRITER_QOS_DEFAULT, None)


@define
class Main:
    symbol_contexts:          dict = field(factory=dict)
    conf_pid_topic:           int = None
    conf_timeout_topic:       int = None
    conf_symbol_base_topic:   int = None
    conf_symbol_quote_topic:  int = None
    conf_symbol_subscribe_name_topic:  int = None
    conf_symbol_event_name_topic:  int = None
    conf_symbol_trade_topic:        int = None
    conf_symbol_kline_topic:        int = None
    conf_symbol_kline_all_topic:        int = None
    parse_symbol_base_topic:  int = None
    parse_symbol_quote_topic: int = None
    parse_symbol_subscribe_name_topic: int = None
    parse_symbol_event_name_topic: int = None
    parse_symbol_trade_topic:       int = None
    parse_symbol_kline_topic:       int = None
    parse_symbol_kline_all_topic:       int = None
    price_topic:              int = None
    quantity_topic:           int = None
    kline_topic:              int = None
    client:                   int = None
    host:                     int = None
    binance_task:             int = None
    binance:                  int = None

    @define
    class SymbolContext:
        base:   str  = None
        quote:  str  = None
        subscribe_name: str  = None
        event_name: str  = None
        trade:  bool = False
        kline:  bool = False
        kline_all: bool = False


    def __init__(self, host, domain, name, instance, *args, **kwargs):
        self.__attrs_init__(*args, **kwargs)

        client_id = '{}/{}/{}/'.format(domain, name, instance) + str(uuid.uuid4())

        root_topic = (domain,)
        pid_topic = (*root_topic, 'proc', 'pid')
        config_topic = (*root_topic, 'config', name, instance)
        timeout_topic = (*config_topic, 'timeout')
        symbol_base_topic = (*config_topic, 'symbol', '+', 'base')
        symbol_quote_topic = (*config_topic, 'symbol', '+', 'quote')
        symbol_subscribe_name_topic = (*config_topic, 'symbol', '+', 'subscribe_name')
        symbol_event_name_topic = (*config_topic, 'symbol', '+', 'event_name')
        symbol_trade_topic = (*config_topic, 'symbol', '+', 'trade', 'subscribe')
        symbol_kline_topic = (*config_topic, 'symbol', '+', 'kline', 'subscribe')
        symbol_kline_all_topic = (*config_topic, 'symbol', '+', 'kline', 'all')
        p_symbol_base_topic = (*config_topic, 'symbol', '{symbol}', 'base')
        p_symbol_quote_topic = (*config_topic, 'symbol', '{symbol}', 'quote')
        p_symbol_subscribe_name_topic = (*config_topic, 'symbol', '{symbol}', 'subscribe_name')
        p_symbol_event_name_topic = (*config_topic, 'symbol', '{symbol}', 'event_name')
        p_symbol_trade_topic = (*config_topic, 'symbol', '{symbol}', 'trade', 'subscribe')
        p_symbol_kline_topic = (*config_topic, 'symbol', '{symbol}', 'kline', 'subscribe')
        p_symbol_kline_all_topic = (*config_topic, 'symbol', '{symbol}', 'kline', 'all')
        price_topic = (*root_topic, 'trade', 'binance', '{base}', '{quote}', '{trade_id}', '{timestamp}', 'price')
        quantity_topic = (*root_topic, 'trade', 'binance', '{base}', '{quote}', '{trade_id}', '{timestamp}', 'quantity')
        kline_topic = (*root_topic, 'kline', 'binance', '{symbol}', '{interval}', '{timestamp}')
        self.conf_pid_topic = '/'.join(pid_topic)
        self.conf_timeout_topic = '/'.join(timeout_topic)
        self.conf_symbol_base_topic = '/'.join(symbol_base_topic)
        self.conf_symbol_quote_topic = '/'.join(symbol_quote_topic)
        self.conf_symbol_subscribe_name_topic = '/'.join(symbol_subscribe_name_topic)
        self.conf_symbol_event_name_topic = '/'.join(symbol_event_name_topic)
        self.conf_symbol_trade_topic = '/'.join(symbol_trade_topic)
        self.conf_symbol_kline_topic = '/'.join(symbol_kline_topic)
        self.conf_symbol_kline_all_topic = '/'.join(symbol_kline_all_topic)
        self.parse_symbol_base_topic = '/'.join(p_symbol_base_topic)
        self.parse_symbol_quote_topic = '/'.join(p_symbol_quote_topic)
        self.parse_symbol_subscribe_name_topic = '/'.join(p_symbol_subscribe_name_topic)
        self.parse_symbol_event_name_topic = '/'.join(p_symbol_event_name_topic)
        self.parse_symbol_trade_topic = '/'.join(p_symbol_trade_topic)
        self.parse_symbol_kline_topic = '/'.join(p_symbol_kline_topic)
        self.parse_symbol_kline_all_topic = '/'.join(p_symbol_kline_all_topic)
        self.price_topic = '/'.join(price_topic)
        self.quantity_topic = '/'.join(quantity_topic)
        self.kline_topic = '/'.join(kline_topic)

        def _(client, userdata, msg, handler):
            topic = msg.topic
            payload = json.loads(msg.payload)
            qos = msg.qos
            retain = msg.retain
            return handler(topic, payload, qos, retain)

        self.client = mqtt.Client(client_id=client_id)
        self.client.on_connect = self.on_connect
        self.client.on_disconnect = self.on_disconnect
        self.client.message_callback_add(self.conf_symbol_base_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_base_message))
        self.client.message_callback_add(self.conf_symbol_quote_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_quote_message))
        self.client.message_callback_add(self.conf_symbol_subscribe_name_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_subscribe_name_message))
        self.client.message_callback_add(self.conf_symbol_event_name_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_event_name_message))
        self.client.message_callback_add(self.conf_symbol_trade_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_trade_message))
        self.client.message_callback_add(self.conf_symbol_kline_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_kline_message))
        self.client.message_callback_add(self.conf_symbol_kline_all_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_kline_all_message))
        self.client.will_set(self.conf_pid_topic)
        self.host = host

        config.subscription_map.events.connect(self._on_subscription_map_changed)

        # Default symbol configuration
        btc = config.get_asset('btc')
        btc.name = 'btc'
        usdt = config.get_asset('usdt')
        usdt.name = 'usdt'
        btcusdt = config.get_symbol('btcusdt')
        btcusdt.base = btc
        btcusdt.quote = usdt
        kline = config.get_kline('btcusdt')
        kline.enable = True
        kline.symbol = btcusdt
        kline.interval = interval

        # Default symbol context
        self.symbol_contexts['btcusdt'] = Main.SymbolContext(
            base='btc',
            quote='usdt',
            subscribe_name='btcusdt',
            event_name='BTCUSDT',
            kline_all=True,
        )

    def _on_subscription_map_changed(self, emission_info):
        if emission_info.signal == config.subscription_map.events.added:
            key, value = emission_info.args
            #print(f'---- Subscribe: {key}')
        if emission_info.signal == config.subscription_map.events.removing:
            (key,) = emission_info.args
            #print(f'---- Unsubscribe: {key}')
        #pp(config)

    async def on_connect(self, client, userdata, flags, rc):
        print('on_connect')
        await asyncio.gather(*[
            client.subscribe(self.conf_timeout_topic),
            client.subscribe(self.conf_symbol_base_topic),
            client.subscribe(self.conf_symbol_subscribe_name_topic),
            client.subscribe(self.conf_symbol_event_name_topic),
            client.subscribe(self.conf_symbol_quote_topic),
            client.subscribe(self.conf_symbol_trade_topic),
            client.subscribe(self.conf_symbol_kline_topic),
            client.subscribe(self.conf_symbol_kline_all_topic),
            ])

    async def on_disconnect(self, client, userdata, rc):
        print('on_disconnect', rc)

    async def on_sigint(self, *, mqtt_done, binance_task):
        mqtt_done.set_result(0)
        binance_task.cancel()
        return False

    def get_context_by_id(self, symbol):
        if symbol in self.symbol_contexts:
            context = self.symbol_contexts[symbol]
        else:
            context = Main.SymbolContext()
            self.symbol_contexts[symbol] = context
        return context

    def get_context_by_event_name(self, event_name):
        for k, v in self.symbol_contexts.items():
            if v.event_name == event_name:
                return k, v
        raise Exception('Not found event_name')
        return None

    async def on_conf_symbol_base_message(self, topic, payload, qos, retain):
        print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_base_topic, topic)
        #context = self.get_context_by_id(single_levels['symbol'])
        #context.base = payload

        base = config.get_asset(payload)
        base.name = payload
        symbol = config.get_symbol(single_levels['symbol'])
        symbol.base = base

    async def on_conf_symbol_quote_message(self, topic, payload, qos, retain):
        print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_quote_topic, topic)
        #context = self.get_context_by_id(single_levels['symbol'])
        #context.quote = payload

        quote = config.get_asset(payload)
        quote.name = payload
        symbol = config.get_symbol(single_levels['symbol'])
        symbol.quote = quote

    async def on_conf_symbol_subscribe_name_message(self, topic, payload, qos, retain):
        print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_subscribe_name_topic, topic)
        context = self.get_context_by_id(single_levels['symbol'])
        context.subscribe_name = payload
        #print(context)

    async def on_conf_symbol_event_name_message(self, topic, payload, qos, retain):
        print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_event_name_topic, topic)
        context = self.get_context_by_id(single_levels['symbol'])
        context.event_name = payload
        #print(context)

    async def on_conf_symbol_trade_message(self, topic, payload, qos, retain):
        print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_trade_topic, topic)
        #context = self.get_context_by_id(single_levels['symbol'])
        #context.trade = payload

        symbol = config.get_symbol(single_levels['symbol'])
        trade = config.get_trade(single_levels['symbol'])
        trade.enable = True
        trade.symbol = symbol

    async def on_conf_symbol_kline_message(self, topic, payload, qos, retain):
        print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_kline_topic, topic)
        #context = self.get_context_by_id(single_levels['symbol'])
        #context.kline = payload

        symbol = config.get_symbol(single_levels['symbol'])
        kline = config.get_kline(single_levels['symbol'])
        kline.enable = True
        interval = config.get_interval('1m')
        kline.symbol = symbol
        kline.interval = interval

    async def on_conf_symbol_kline_all_message(self, topic, payload, qos, retain):
        print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_kline_all_topic, topic)
        context = self.get_context_by_id(single_levels['symbol'])
        context.kline_all = payload
        #print(context)

    async def on_ws_connect(self, ws):
        self.binance = ws

        print('Subscribing...')

        streams = []
        #for k, v in self.symbol_contexts.items():
        #    if v.trade:
        #        streams.append(TradeStream(symbol=Symbol(v.subscribe_name))),
        #    if v.kline:
        #        streams.append(KlineCandlestickStream(symbol=Symbol(v.subscribe_name), interval=Interval.INTERVAL_1m))

        for k, v in config.subscription_map.items():
            if type(v) == Kline:
                symbol = Symbol(v.symbol.name)
                interval = Interval.INTERVAL_1m
                stream = KlineCandlestickStream(symbol=symbol, interval=interval)
                streams.append(stream)
            #    print('=====', stream)
            #elif type(v) == Trade:
            #    symbol = Symbol(v.symbol.name)
            #    stream = TradeStream(symbol=symbol)
            #    streams.append(stream)
            #    print('=====', stream)

        rval = await ws.subscribe(*streams)
        #pp(config)

    @singledispatchmethod
    async def on_event(self, evt, ws):
        print('Error:', type(evt), type(ws))

    @on_event.register
    async def _(self, result: ResultEvent, ws: ClientWebSocketResponse):
        print(result)
        pass

    @on_event.register
    async def _(self, trade: TradeEvent, ws: ClientWebSocketResponse):
        print('T', end='', flush=True)
        #print(trade)

        symbol_id, context = self.get_context_by_event_name(trade.s)

        #{
        key = {
            'base':      context.base,
            'quote':     context.quote,
            'trade_id':  trade.t,
            'timestamp': trade.T,
        }
        val = {
            'time':     trade.T,
            'trade_id': trade.t,
            'price':    trade.p,
            'quantity': trade.q
        }

        price_topic = self.price_topic.format(**key)
        quantity_topic = self.quantity_topic.format(**key)

        await asyncio.gather(*[
            self.client.publish(price_topic, json.dumps(trade.p)),
            #self.client.publish(quantity_topic, json.dumps(trade.q)),
            ])
        #}

        #{
        #args = {
        #    'exchange':        'binance',
        #    'symbol':          symbol_id,
        #    'event_timestamp': trade.E,
        #    'trade_timestamp': trade.T,
        #    'trade_id':        trade.t,
        #    'price':           trade.p,
        #    'quantity':        trade.q,
        #}
        #t = trade_t(**args)
        #trade_writer.write(t)
        #}

    @on_event.register
    async def _(self, evt: KlineEvent, ws: ClientWebSocketResponse):
        if evt.k.x:
            print('K', end='', flush=True)
        else:
            print('.', end='', flush=True)

        def send_dds(evt, symbol_id):
            msg = Ohlcv()
            msg.exchange_id('binance')
            msg.symbol_id(symbol_id)
            msg.interval_id(evt.k.i)
            msg.etime(evt.E)
            msg.data().timestamp(evt.k.t)
            msg.data().open(evt.k.o)
            msg.data().high(evt.k.h)
            msg.data().low(evt.k.l)
            msg.data().close(evt.k.c)
            msg.data().volume(evt.k.v)
            ohlcv_writer.write(msg)

        def send_open(evt, symbol_id, sample_id):
            msg = OhlcvValue()
            msg.exchange_id('binance')
            msg.symbol_id(symbol_id)
            msg.interval_id(evt.k.i)
            msg.sample_id(sample_id)
            msg.timestamp(int(evt.k.t))
            msg.value(evt.k.o)
            open_writer.write(msg)

        def send_high(evt, symbol_id, sample_id):
            msg = OhlcvValue()
            msg.exchange_id('binance')
            msg.symbol_id(symbol_id)
            msg.interval_id(evt.k.i)
            msg.sample_id(sample_id)
            msg.timestamp(int(evt.k.t))
            msg.value(evt.k.h)
            high_writer.write(msg)

        def send_low(evt, symbol_id, sample_id):
            msg = OhlcvValue()
            msg.exchange_id('binance')
            msg.symbol_id(symbol_id)
            msg.interval_id(evt.k.i)
            msg.sample_id(sample_id)
            msg.timestamp(int(evt.k.t))
            msg.value(evt.k.l)
            low_writer.write(msg)

        def send_close(evt, symbol_id, sample_id):
            msg = OhlcvValue()
            msg.exchange_id('binance')
            msg.symbol_id(symbol_id)
            msg.interval_id(evt.k.i)
            msg.sample_id(sample_id)
            msg.timestamp(int(evt.k.t))
            msg.value(evt.k.c)
            close_writer.write(msg)

        def send_volume(evt, symbol_id, sample_id):
            msg = OhlcvValue()
            msg.exchange_id('binance')
            msg.symbol_id(symbol_id)
            msg.interval_id(evt.k.i)
            msg.sample_id(sample_id)
            msg.timestamp(int(evt.k.t))
            msg.value(evt.k.v)
            volume_writer.write(msg)

        symbol_id, context = self.get_context_by_event_name(evt.s)
        sample_id = (int(evt.k.t) // 60) + 1

        if evt.k.x or context.kline_all:

            #{
            key = {
                'symbol':    symbol_id,
                'base':      context.base,
                'quote':     context.quote,
                'interval':  evt.k.i,
                'timestamp': evt.k.t
            }
            val = {
                'time':     evt.k.t,
                'open':     evt.k.o,
                'high':     evt.k.h,
                'low':      evt.k.l,
                'close':    evt.k.c,
                'volume':   evt.k.v
            }
            kline_topic = self.kline_topic.format(**key)
            await asyncio.gather(*[
                self.client.publish(kline_topic, json.dumps(val)),
                ])
            #}

            send_dds(evt, symbol_id)

            send_open(evt, symbol_id, sample_id)
            send_high(evt, symbol_id, sample_id)
            send_low(evt, symbol_id, sample_id)
            send_close(evt, symbol_id, sample_id)
            send_volume(evt, symbol_id, sample_id)

        if context.kline_all:

            send_dds(evt, symbol_id)

            #{
            #msg = Ohlcv()
            #msg.exchange_id('binance')
            #msg.symbol_id(symbol_id)
            #msg.interval_id(evt.k.i)
            #msg.etime(evt.E)
            #msg.data().timestamp(evt.k.t)
            #msg.data().open(evt.k.o)
            #msg.data().high(evt.k.h)
            #msg.data().low(evt.k.l)
            #msg.data().close(evt.k.c)
            #msg.data().volume(evt.k.v)
            #ohlcv_writer.write(msg)
            #}

            #pass

    async def runner(self):
        global _ws
        await asyncio.sleep(2)
        try:
            async with ClientSession() as session:
                while True:
                    try:
                        async with session.ws_connect() as ws:
                            _ws = ws
                            print('Connected...')
                            await self.on_ws_connect(ws)
                            async for msg in ws:
                                await self.on_event(msg, ws)
                        print('Disconnected...')
                    except Exception as e:
                        print(e)
                        raise
        except asyncio.CancelledError:
            print('Cancelled...')
            pass

    async def __call__(self):
        self.binance_task = asyncio.create_task(self.runner())

        loop = asyncio.get_running_loop()

        mqtt_done = loop.create_future()

        async def mqtt_runner(mqtt_done):
            self.client.loop = loop
            await self.client.connect(self.host)
            await mqtt_done
            await self.client.disconnect()

        mqtt_task = asyncio.create_task(mqtt_runner(mqtt_done))

        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.create_task(partial(self.on_sigint, mqtt_done=mqtt_done, binance_task=self.binance_task)()))

        await asyncio.gather(
                mqtt_task,
                self.binance_task
                )


def cmd():
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='localhost')
    parser.add_argument('--domain', default='inclination')
    parser.add_argument('--name', default='exchange')
    parser.add_argument('--instance', default='0')
    args = parser.parse_args()

    print("Starting")
    asyncio.run(Main(**vars(args))())
    print("Finished")

if __name__ == '__main__':
    cmd()

