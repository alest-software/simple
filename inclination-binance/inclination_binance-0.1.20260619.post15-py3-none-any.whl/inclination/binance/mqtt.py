from typing import Awaitable
import logging
try:
    from attrs import define, frozen, field
except ImportError:
    from attr import define, frozen, field
import asyncio
import paho.mqtt.client as mqtt


logger = logging.getLogger(__name__)


class MqttError(Exception): pass
class MqttDisconnectError(MqttError): pass
class MqttPublishError(MqttError): pass
class MqttSubscribeError(MqttError): pass
class MqttUnsubscribeError(MqttError): pass
class MqttMessageError(MqttError): pass


@frozen
class _OnConnectWrapper:
    client: 'Client'

    async def _on_connect(self, userdata, flags, rc):
        if self.client.on_connect:
            try:
                rval = await self.client.on_connect(self.client, userdata, flags, rc)
            except Exception as e:
                logger.warning(f'_OnConnectWrapper: {type(e).__name__}: {str(e)}')
        self.client.context.connected.set_result(rc)

    def __call__(self, client, userdata, flags, rc):
        asyncio.ensure_future(self._on_connect(userdata, flags, rc))


@frozen
class _OnDisconnectWrapper:
    client: 'Client'

    async def _on_disconnect(self, userdata, rc):
        if self.client.on_disconnect:
            try:
                await self.client.on_disconnect(self.client, userdata, rc)
            except Exception as e:
                logger.warning(f'_OnDisconnectWrapper: {type(e).__name__}: {str(e)}')
        if rc == 0:
            self.client.context.disconnected.set_result(rc)
            #if (rc == mqtt.MQTT_ERR_SUCCESS) and (self.client._forever):
            #    self.client._forever.set_result(None)
        else:
            loop = asyncio.get_event_loop()
            loop.call_later(1, lambda: asyncio.ensure_future(self.client.reconnect()))

    def __call__(self, client, userdata, rc):
        asyncio.ensure_future(self._on_disconnect(userdata, rc))


@frozen
class _OnMessageWrapper:
    client: 'Client'

    async def _on_message(self, userdata, msg):
        if self.client.on_message:
            try:
                await self.client.on_message(self.client, userdata, msg)
            except Exception as e:
                logger.warning(f'_OnMessageWrapper: {type(e).__name__}: {str(e)}')

    def __call__(self, client, userdata, msg):
        asyncio.ensure_future(self._on_message(userdata, msg))


@frozen
class _OnMessageCallbackWrapper:
    client: 'Client'
    callback: Awaitable

    async def _handle(self, userdata, msg):
        try:
            await self.callback(self.client, userdata, msg)
        except Exception as e:
            logger.warning(f'_OnMessageCallbackWrapper: {type(e).__name__}: {str(e)}')

    def __call__(self, client, userdata, msg):
        asyncio.ensure_future(self._handle(userdata, msg))


@frozen
class _OnPublishWrapper:
    client: 'Client'

    async def _on_publish(self, userdata, mid):
        if self.client.on_publish:
            try:
                await self.client.on_publish(self.client, userdata, mid)
            except Exception as e:
                logger.warning(f'_OnPublishWrapper: {type(e).__name__}: {str(e)}')
        self.client.context.published[mid].set_result(None)

    def __call__(self, client, userdata, mid):
        asyncio.ensure_future(self._on_publish(userdata, mid))


@frozen
class _OnSubscribeWrapper:
    client: 'Client'

    async def _on_subscribe(self, userdata, mid, granted_qos):
        if self.client.on_subscribe:
            try:
                await self.client.on_subscribe(self.client, userdata, mid, granted_qos)
            except Exception as e:
                logger.warning(f'_OnSubscribeWrapper: {type(e).__name__}: {str(e)}')
        self.client.context.subscribed[mid].set_result(None)

    def __call__(self, client, userdata, mid, granted_qos):
        asyncio.ensure_future(self._on_subscribe(userdata, mid, granted_qos))


@frozen
class _OnUnsubscribeWrapper:
    client: 'Client'

    async def _on_unsubscribe(self, userdata, mid):
        if self.client.on_unsubscribe:
            try:
                await self.client.on_unsubscribe(self.client, userdata, mid)
            except Exception as e:
                logger.warning(f'_OnUnsubscribeWrapper: {type(e).__name__}: {str(e)}')
        self.client.context.unsubscribed[mid].set_result(None)

    def __call__(self, client, userdata, mid):
        asyncio.ensure_future(self._on_unsubscribe(userdata, mid))


@frozen
class _OnLogWrapper:
    client: 'Client'

    async def _on_log(self, userdata, level, buf):
        if self.client.on_log:
            try:
                await self.client.on_log(self.client, userdata, level, buf)
            except Exception as e:
                logger.warning(f'_OnLogWrapper: {type(e).__name__}: {str(e)}')

    def __call__(self, client, userdata, level, buf):
        asyncio.ensure_future(self._on_log(userdata, level, buf))


class _AsyncioHelper:
    def __init__(self, loop, client):
        self.loop = loop
        self.client = client
        self.client.on_socket_open = self.on_socket_open
        self.client.on_socket_close = self.on_socket_close
        self.client.on_socket_register_write = self.on_socket_register_write
        self.client.on_socket_unregister_write = self.on_socket_unregister_write

    def on_socket_open(self, client, userdata, sock):
        #print("Socket opened")

        def cb():
            #print("Socket is readable, calling loop_read")
            client.loop_read()

        self.loop.add_reader(sock, cb)
        self.misc = self.loop.create_task(self.misc_loop())

    def on_socket_close(self, client, userdata, sock):
        #print("Socket closed")
        self.loop.remove_reader(sock)
        self.misc.cancel()

    def on_socket_register_write(self, client, userdata, sock):
        #print("Watching socket for writability.")

        def cb():
            #print("Socket is writable, calling loop_write")
            client.loop_write()

        self.loop.add_writer(sock, cb)

    def on_socket_unregister_write(self, client, userdata, sock):
        #print("Stop watching socket for writability.")
        self.loop.remove_writer(sock)

    async def misc_loop(self):
        #print("misc_loop started")
        while self.client.loop_misc() == mqtt.MQTT_ERR_SUCCESS:
            try:
                await asyncio.sleep(1)
            except asyncio.CancelledError:
                break
        #print("misc_loop finished")


@define
class Context:
    client:       'Client'
    connected:    asyncio.Future = None
    disconnected: asyncio.Future = None
    published:    dict = field(factory=dict)
    subscribed:   dict = field(factory=dict)
    unsubscribed: dict = field(factory=dict)


class Client:
    def __init__(self, *args, **kwargs):
        self._client = mqtt.Client(*args, **kwargs)
        self.on_connect = None
        self.on_disconnect = None
        self.on_message = None
        self.on_publish = None
        self.on_subscribe = None
        self.on_unsubscribe = None
        self.on_log = None
        self._message_callbacks = {}
        self._forever = None
        self.context = Context(self)

        self._client.on_connect = _OnConnectWrapper(self)
        self._client.on_disconnect = _OnDisconnectWrapper(self)
        self._client.on_message = _OnMessageWrapper(self)
        self._client.on_publish = _OnPublishWrapper(self)
        self._client.on_subscribe = _OnSubscribeWrapper(self)
        self._client.on_unsubscribe = _OnUnsubscribeWrapper(self)
        self._client.on_log = _OnLogWrapper(self)

    @property
    def loop(self):
        return asyncio.get_running_loop()

    @loop.setter
    def loop(self, loop):
        self._aioh = _AsyncioHelper(loop, self._client)

    async def loop_forever(self):
        #loop = asyncio.get_running_loop()
        self._forever = self.loop.create_future()
        await self._forever

    def reinitialise(self):
        raise NotImplemented('reinitialise')

    def __getattr__(self, m):
        return getattr(self._client, m)

    async def connect(self, *args, **kwargs):
        #print(f'connect()')
        rval = self._client.connect(*args, **kwargs)
        if rval == 0:
            self.context.connected = self.loop.create_future()
            try:
                await asyncio.wait_for(self.context.connected, timeout=None)
                rc = self.context.connected.result()
            except TimeoutError as e:
                rc = -1 #raise e
            finally:
                self.context.connected = None
        #print(f'~connect()')
        return rval, rc

    async def reconnect(self, *args, **kwargs):
        #print(f'reconnect()')
        try:
            rval = self._client.reconnect(*args, **kwargs)
            if rval == 0:
                self.context.connected = self.loop.create_future()
                try:
                    await asyncio.wait_for(self.context.connected, timeout=None)
                    rc = self.context.connected.result()
                finally:
                    self.context.connected = None
        #print(f'~reconnect()')
            return rval, rc
        except Exception as e:
            loop = asyncio.get_event_loop()
            loop.call_later(1, lambda: asyncio.ensure_future(self.reconnect()))
            return -1, -1

    async def disconnect(self, *args, **kwargs):
        #print(f'disconnect()')
        rc = self._client.disconnect(*args, **kwargs)
        if rc != 0:
            raise MqttDisconnectError(rc)
        else:
            self.context.disconnected = self.loop.create_future()
            await self.context.disconnected
            self.context.disconnected = None
        #print(f'~disconnect()')
        return 0

    async def publish(self, *args, **kwargs):
        #print(f'publish({args})')
        rc, mid = self._client.publish(*args, **kwargs)
        if rc != 0:
            raise MqttPublishError(rc)
        else:
            if mid in self.context.published:
                raise Exception('blub')
            else:
                published = self.loop.create_future()
                self.context.published[mid] = published
                await asyncio.wait_for(published, timeout=None)
                rc = published.result()
                del self.context.published[mid]
        #print(f'~publish()')
        return rc

    async def subscribe(self, *args, **kwargs):
        #print(f'subscribe()', *args, **kwargs)
        rc, mid = self._client.subscribe(*args, **kwargs)
        if rc != 0:
            raise MqttSubscribeError(rc)
        else:
            if mid in self.context.subscribed:
                raise MqttMessageError(f"Illegal message ID {mid}")
            else:
                subscribed = self.loop.create_future()
                self.context.subscribed[mid] = subscribed
                await subscribed #await asyncio.wait_for(subscribed, timeout=None)
                rc = subscribed.result()
                del self.context.subscribed[mid]
        #print(f'~subscribe()')
        return rc

    async def unsubscribe(self, *args, **kwargs):
        #print(f'unsubscribe()')
        rc, mid = self._client.unsubscribe(*args, **kwargs)
        if rc != 0:
            raise MqttUnsubscribeError(rc)
        else:
            if mid in self.context.unsubscribed:
                raise MqttMessageError(f"Illegal message ID {mid}")
            else:
                unsubscribed = self.loop.create_future()
                self.context.unsubscribed[mid] = unsubscribed
                await unsubscribed #await asyncio.wait_for(subscribed, timeout=None)
                rc = unsubscribed.result()
                del self.context.unsubscribed[mid]
        #print(f'~unsubscribe()')
        return rc

    def message_callback_add(self, sub, callback):
        cb = _OnMessageCallbackWrapper(self, callback)
        self._message_callbacks[sub] = cb
        return self._client.message_callback_add(sub, cb)

    def message_callback_remove(self, sub):
        rc = self._client.message_callback_remove(self._message_callbacks[sub])
        del self._message_callbacks[sub]
        return rc


def connack_string(rc):
    return mqtt.connack_string(rc)

def error_string(rc):
    return mqtt.error_string(rc)


def main(mqtt_host, mqtt_port, mqtt_user, mqtt_passwd):
    async def on_connect(client, userdata, flags, rc):
        print(f'on_connect (userdata={userdata}, flags={flags}, rc={rc}/"{connack_string(rc)}")')
        await asyncio.sleep(0.5)
        #client.context.connected.set_result(rc)
        #await asyncio.gather(*[
            #client.subscribe('$SYS/broker/uptime'),
            #client.subscribe('test/#')
            #])
        return 42

    async def on_disconnect(client, userdata, rc):
        print(f'on_disconnect (userdata={userdata}, rc="{rc}")')
        await asyncio.sleep(0.5)
        #client._forever.set_result(rc)
        return 42

    async def on_message(client, userdata, msg):
        print('on_message', msg.topic, str(msg.payload))
        await asyncio.sleep(0.5)
        return 42

    async def on_sys_broker_uptime(client, userdata, msg):
        print('on_sys_broker_uptime', msg.topic, str(msg.payload))
        await client.publish('test/publish', 'ABC')
        return 42

    async def on_test_publish(client, userdata, msg):
        print('on_test_publish', msg.topic, str(msg.payload))
        await asyncio.gather(*[
            client.publish('test/next', 'ABC'),
            client.unsubscribe('test/publish')
            ])
        return 42

    async def on_test_next(client, userdata, msg):
        print('on_test_next', msg.topic, str(msg.payload))
        #await client.publish('test/next2', 'ABC')
        #print('~on_test_publish')
#        await client.disconnect()
        return 42

    async def on_publish(client, userdata, mid):
        print(f'on_publish (userdata={userdata}, mid={mid})')
        await asyncio.sleep(0.5)
        return 42

    async def on_subscribe(client, userdata, mid, granted_qos):
        print(f'on_subscribe (userdata={userdata}, mid={mid}, granted_qos={granted_qos})')
        await asyncio.sleep(0.5)
        return 42

    async def on_unsubscribe(client, userdata, mid):
        print(f'on_unsubscribe (userdata={userdata}, mid={mid})')
        await asyncio.sleep(0.5)
        return 42

    async def on_log(client, userdata, level, buf):
        print('==', userdata, level, buf)
        return 42

    async def on_sigint(client):
        client._forever.set_result(None)
        return 42


    async def main():
        client = Client()
        client.on_connect = on_connect
        client.on_disconnect = on_disconnect
        client.on_message = on_message
        client.on_publish = on_publish
        client.on_subscribe = on_subscribe
        client.on_unsubscribe = on_unsubscribe
        #client.on_log = on_log

        client.message_callback_add('$SYS/broker/uptime', on_sys_broker_uptime)
        client.message_callback_add('test/publish', on_test_publish)
        client.message_callback_add('test/next', on_test_next)

        client.will_set('test/lwt', 'lost', 0, False)
        client.user_data_set({'answer': None})

        client.username_pw_set(mqtt_user, password=mqtt_passwd)

        #aioh = _AsyncioHelper(asyncio.get_running_loop(), client._client)
        client.loop = asyncio.get_running_loop()
        from functools import partial
        import signal
        client.loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(on_sigint)(client)))


        print('----------------------------------------')
        rval = await client.connect('localhost', 1883, 60)
        print('Connected...', rval)
        print('----------------------------------------')
        rc = await client.subscribe('$SYS/broker/uptime')
        print('Subscribed...', rc)
        print('----------------------------------------')
        rc = await asyncio.gather(*[
            client.subscribe('test/next'),
            client.subscribe('test/publish'),
            ])
        print('Subscribed...', rc)
        print('----------------------------------------')

        await client.loop_forever()

#        rc = await asyncio.gather(*[
#            client.unsubscribe('test/next'),
#            client.unsubscribe('test/publish'),
#            client.unsubscribe('$SYS/broker/uptime')
#            ])
#        print('Unsubscribed...', rc)
#        print('----------------------------------------')
#
#        rc = await client.disconnect()
#        print('Disconnected...', rc)
#        print('----------------------------------------')


    asyncio.run(main())

if __name__ == '__main__':
    import os
    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument('-H', '--mqtt-host', default=os.environ.get('MQTT_HOST', 'localhost'))
    parser.add_argument('-p', '--mqtt-port', type=int, default=os.environ.get('MQTT_PORT', 1883))
    parser.add_argument('-u', '--mqtt-user', default=os.environ.get('MQTT_USER', None))
    parser.add_argument('-P', '--mqtt-passwd', default=os.environ.get('MQTT_PASSWD', None))
    args = parser.parse_args()

    main(**vars(args))

