from aiohttp import WSMessage, WSMsgType
from .klineupdate import *


class EventFactory:
    async def create(self, msg: WSMessage):
        if msg.type == WSMsgType.TEXT:
            msg = msg.json()
            return await self._create(msg)
        raise Exception('Unknown message')

    async def _create(self, json):
        if isinstance(json, list):
            if len(json) > 0:
                if json[0]['e'] == '24hrMiniTicker':
                    msg = MiniTickerEventList(json)
                elif json[0]['e'] == '24hrTicker':
                    msg = TickerEventList(json)
                else:
                    raise Exception('handleAllMarkets')
            else:
                raise Exception('len0')
                
        elif isinstance(json, object):
            params = {}
            if ('e' in json):
                if json['e'] == 'aggTrade':
                    msg = AggregateTradeEvent(**json)
                elif json['e'] == 'trade':
                    msg = TradeEvent(**json)
                elif json['e'] == 'kline':
                    msg = KlineEvent(**json)
                elif json['e'] == '24hrMiniTicker':
                    msg = MiniTickerEvent(**json)
                elif json['e'] == '24hrTicker':
                    msg = TickerEvent(**json)
                elif json['e'] == 'depthUpdate':
                    msg = DifferentialDepthEvent(**json)
                else:
                    raise WebsocketError('Invalid message: {0}'.format(json))
            elif ('u' in json):
                msg = BookTickerEvent(**json)
            elif ('lastUpdateId' in json):
                msg = PartialBookDepthEvent(**json)
            elif ('id' in json):
                if ('result' in json):
                    msg = ResultEvent(**json)
                elif ('error' in json): 
                    msg = ErrorEvent(**json)

            elif ('code' in json):
                raise WebsocketError('Invalid message: {0}'.format(json))
            else:
                raise WebsocketError('Invalid message: {0}'.format(json))
        else:
            raise WebsocketError('Illegal JSON message type {0}'.format(type(m)))

        return msg

