#!/bin/env python

import logging
from attrs import define, frozen, field, asdict
from psygnal import evented, Signal
from psygnal.containers import EventedDict, EventedSet, EventedList


#logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname).1s - %(message)s')
log = logging.getLogger(__name__)


@evented
@define
class Interval:
    name: str = None
    timeout: int = None

    def __init__(self, *args, **kwargs):
        self.__attrs_init__(*args, **kwargs)
        self.events.connect(self._on_changed)

    def _on_changed(self, emission_info):
        sender = Signal.sender()

        if emission_info.signal == sender.events.timeout:
            (new_value, old_value) = emission_info.args
            self._update_name(None)

        if emission_info.signal == sender.events.name:
            (new_value, old_value) = emission_info.args
            log.warning(f'interval: "{old_value}" -> "{new_value}"')

    def _update_name(self, emission_info):
        if self.timeout is not None:
            m, s = divmod(self.timeout, 60)
            h, m = divmod(m, 60)
            h = f'{h}h' if h else ''
            m = f'{m}m' if m else ''
            s = f'{s}s' if s else ''
            self.name = f'{h}{m}{s}'
        else:
            self.name = None

    def __str__(self):
        return self.name


@evented
@define
class Asset:
    name: str = None

    def __init__(self, *args, **kwargs):
        self.__attrs_init__(*args, **kwargs)
        self.events.connect(self._on_changed)

    def _on_changed(self, emission_info):
        sender = Signal.sender()

        if emission_info.signal == sender.events.name:
            (new_value, old_value) = emission_info.args
            log.warning(f'asset: "{old_value}" -> "{new_value}"')

    def __str__(self):
        return self.name


@evented
@define
class Symbol:
    name: str = None
    base: Asset = None
    quote: Asset = None

    def __init__(self, *args, **kwargs):
        self.__attrs_init__(*args, **kwargs)
        self.events.connect(self._on_changed)
        self._update_name(None)

    def _on_changed(self, emission_info):
        sender = Signal.sender()

        if emission_info.signal == sender.events.base:
            (new_value, old_value) = emission_info.args
            if old_value:
                self.base.events.disconnect(self._update_name)
            if new_value:
                self.base.events.connect(self._update_name)
            self._update_name(None)

        if emission_info.signal == sender.events.quote:
            (new_value, old_value) = emission_info.args
            if old_value:
                self.quote.events.disconnect(self._update_name)
            if new_value:
                self.quote.events.connect(self._update_name)
            self._update_name(None)

        if emission_info.signal == sender.events.name:
            (new_value, old_value) = emission_info.args
            log.warning(f'symbol: "{old_value}" -> "{new_value}"')

    def _update_name(self, emission_info):
        self.name = f'{self.base.name}{self.quote.name}' if self.base and self.base.name and self.quote and self.quote.name else None

    def __str__(self):
        return self.name


@evented
@define
class Kline:
    name: str = None
    interval: Interval = None
    symbol: Symbol = None
    enable: bool = False

    def __init__(self, *args, **kwargs):
        self.__attrs_init__(*args, **kwargs)
        self.events.connect(self._on_changed)
        self._update_name(None)

    def _on_changed(self, emission_info):
        sender = Signal.sender()

        if emission_info.signal == sender.events.interval:
            (new_value, old_value) = emission_info.args
            if old_value:
                self.interval.events.disconnect(self._update_name)
            if new_value:
                self.interval.events.connect(self._update_name)
            self._update_name(None)

        if emission_info.signal == sender.events.symbol:
            (new_value, old_value) = emission_info.args
            if old_value:
                self.symbol.events.disconnect(self._update_name)
            if new_value:
                self.symbol.events.connect(self._update_name)
            self._update_name(None)

        if emission_info.signal == sender.events.enable:
            self._update_name(None)

        if emission_info.signal == sender.events.name:
            (new_value, old_value) = emission_info.args
            log.warning(f'kline: "{old_value}" -> "{new_value}"')

    def _update_name(self, emission_info):
        self.name = f'{self.symbol.name}@kline_{self.interval.name}' if self.enable and self.interval and self.interval.name and self.symbol  and self.symbol.name else None

    def __str__(self):
        return self.name


@evented
@define
class Trade:
    name: str = None
    symbol: Symbol = None
    enable: bool = False

    def __init__(self, *args, **kwargs):
        self.__attrs_init__(*args, **kwargs)
        self.events.connect(self._on_changed)
        self._update_name(None)

    def _on_changed(self, emission_info):
        sender = Signal.sender()

        if emission_info.signal == sender.events.symbol:
            (new_value, old_value) = emission_info.args
            if old_value:
                self.symbol.events.disconnect(self._update_name)
            if new_value:
                self.symbol.events.connect(self._update_name)
            self._update_name(None)

        if emission_info.signal == sender.events.enable:
            self._update_name(None)

        if emission_info.signal == sender.events.name:
            (new_value, old_value) = emission_info.args
            log.warning(f'trade: "{old_value}" -> "{new_value}"')

    def _update_name(self, emission_info):
        self.name = f'{self.symbol.name}@trade' if self.enable and self.symbol  and self.symbol.name else None

    def __str__(self):
        return self.name


@evented
@define
class Config:
    assets: EventedDict = field(factory=EventedDict)
    symbols: EventedDict = field(factory=EventedDict)
    intervals: EventedDict = field(factory=EventedDict)
    klines: EventedDict = field(factory=EventedDict)
    trades: EventedDict = field(factory=EventedDict)
    subscription_map: EventedDict = field(factory=EventedDict)

    def __init__(self):
        self.__attrs_init__()
        self.klines.events.connect(self._on_klines_changed)
        self.trades.events.connect(self._on_trades_changed)
        self.subscription_map.events.connect(self._on_subscription_map_changed)

    def _on_kline_changed(self, emission_info):
        sender = Signal.sender()
        if emission_info.signal == sender.events.name:
            (new_value, old_value) = emission_info.args
            if old_value:
                del self.subscription_map[old_value]
            if new_value:
                self.subscription_map[new_value] = sender

    def _on_trade_changed(self, emission_info):
        sender = Signal.sender()
        if emission_info.signal == sender.events.name:
            (new_value, old_value) = emission_info.args
            if old_value:
                del self.subscription_map[old_value]
            if new_value:
                self.subscription_map[new_value] = sender

    def _on_klines_changed(self, emission_info):
        if emission_info.signal == self.klines.events.added:
            key, value = emission_info.args
            self.klines[key].events.connect(self._on_kline_changed)
        if emission_info.signal == self.klines.events.removing:
            (key,) = emission_info.args
            self.klines[key].events.disconnect(self._on_kline_changed)

    def _on_trades_changed(self, emission_info):
        if emission_info.signal == self.trades.events.added:
            key, value = emission_info.args
            self.trades[key].events.connect(self._on_trade_changed)
        if emission_info.signal == self.trades.events.removing:
            (key,) = emission_info.args
            self.trades[key].events.disconnect(self._on_trade_changed)

    def _on_subscription_map_changed(self, emission_info):
        if emission_info.signal == self.subscription_map.events.added:
            key, value = emission_info.args
            print(f'Subscribe: {key}')
        if emission_info.signal == self.subscription_map.events.removing:
            (key,) = emission_info.args
            print(f'Unsubscribe: {key}')

    def get_asset(self, uid):
        if uid not in self.assets:
            self.assets[uid] = Asset()
        return self.assets[uid]

    def get_interval(self, uid):
        if uid not in self.intervals:
            self.intervals[uid] = Interval()
        return self.intervals[uid]

    def get_symbol(self, uid):
        if uid not in self.symbols:
            self.symbols[uid] = Symbol()
        return self.symbols[uid]

    def get_kline(self, uid):
        if uid not in self.klines:
            self.klines[uid] = Kline()
        return self.klines[uid]

    def get_trade(self, uid):
        if uid not in self.trades:
            self.trades[uid] = Trade()
        return self.trades[uid]


def ppp(c):
    from pprint import pprint
    cc = asdict(c)
    cc['assets'] = {k: asdict(v) for k, v in cc['assets'].items()}
    cc['intervals'] = {k: asdict(v) for k, v in cc['intervals'].items()}
    cc['symbols'] = {k: asdict(v) for k, v in cc['symbols'].items()}
    cc['klines'] = {k: asdict(v) for k, v in cc['klines'].items()}
    cc['trades'] = {k: asdict(v) for k, v in cc['trades'].items()}
    cc['subscription_map'] = {k: asdict(v) for k, v in cc['subscription_map'].items()}
    pprint(cc)

def pp(c):
    print(f'{"name":16s}|{"symbol":8s}|{"base":6s}|{"quote":6s}|{"interval":8s}|{"timeout":5s}')
    for k, v in c.subscription_map.items():
        if type(v) == Kline:
            print(f'{v.name:16s}|{v.symbol.name:8s}|{v.symbol.base.name:6s}|{v.symbol.quote.name:6s}|{v.interval.name:8s}|{v.interval.timeout:5d}')
        else:
                print(f'{v.name:16s}|{v.symbol.name:8s}|{v.symbol.base.name:6s}|{v.symbol.quote.name:6s}|{"":8s}|{"":5s}')

if __name__ == '__main__':

    config = Config()
    kline = config.get_kline('#btcusdt@kline_1m')
    trade = config.get_trade('#btcusdt@trade')
    m1 = config.get_interval('#1m')
    kline.interval = m1
    btc = config.get_asset('#btc')
    usdt = config.get_asset('#usdt')
    btcusdt = config.get_symbol('#btcusdt')
    kline.symbol = btcusdt
    btcusdt.base = btc
    btc.name = 'btc'
    usdt.name = 'usdt'
    btcusdt.quote = usdt
    m1.name = '1m'
    m1.timeout = (75*60)+3
    m1.timeout = 60
    kline.enable = True
    trade.symbol = btcusdt
    trade.enable = True
    print(btcusdt, btc, usdt, m1, kline)
    ppp(config)
    pp(config)

