
class WebsocketError(Exception):
	def __init__(self, msg):
		self._msg = msg

	def __str__(self):
		return f'{self._msg}'

