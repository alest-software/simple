import os
from functools import partial, singledispatchmethod
import signal
import json
import time
import parse
import argparse
import asyncio
import socket
import uuid
from . import mqtt
from attrs import define, field
from inclination.binance.api.websocket.client import *
from inclination.binance.api.websocket.stream import *
from inclination.binance.api.websocket.klineupdate import *
from inclination.binance.api.websocket.symbol import Symbol
from inclination.binance.api.websocket.interval import Interval
from cyclonedds.domain import DomainParticipant
from cyclonedds.topic import Topic
from cyclonedds.pub import DataWriter
from cyclonedds.sub import DataReader
from cyclonedds.util import duration
from cyclonedds.core import Listener, Qos
#from cyclonedds.qos import Policy
from inclination.idl.ohlcv import *


participant = DomainParticipant()
kline_topic = Topic(participant, "kline", kline)
kline_writer = DataWriter(participant, kline_topic)
kline_reader = DataReader(participant, kline_topic)


@define
class Main:
    symbol_contexts: dict = field(factory=dict)
    #context: core.Exchange = field(factory=core.Exchange)
    conf_pid_topic: int = None
    conf_timeout_topic: int = None
    conf_symbol_base_topic: int = None
    conf_symbol_quote_topic: int = None
    conf_symbol_topic: int = None
    parse_symbol_base_topic: int = None
    parse_symbol_quote_topic: int = None
    parse_symbol_topic: int = None
    price_topic: int = None
    quantity_topic: int = None
    kline_topic: int = None
    client: int = None
    host: int = None
    binance_task: int = None
    binance: int = None

    @define
    class SymbolContext:
        base:   str  = None
        quote:  str  = None
        symbol: str  = None
        trade:  bool = None


    def __init__(self, loop, host, domain, name, instance, *args, **kwargs):
        self.__attrs_init__(*args, **kwargs)

        client_id = '{}/{}/{}/'.format(domain, name, instance) + str(uuid.uuid4())

        root_topic = (domain,)
        pid_topic = (*root_topic, 'proc', 'pid')
        config_topic = (*root_topic, 'config', name, instance)
        timeout_topic = (*config_topic, 'timeout')
        symbol_base_topic = (*config_topic, 'symbol', '+', 'base')
        symbol_quote_topic = (*config_topic, 'symbol', '+', 'quote')
        symbol_topic = (*config_topic, 'symbol', '+', 'trade', 'subscribe')
        p_symbol_base_topic = (*config_topic, 'symbol', '{symbol}', 'base')
        p_symbol_quote_topic = (*config_topic, 'symbol', '{symbol}', 'quote')
        p_symbol_topic = (*config_topic, 'symbol', '{symbol}', 'trade', 'subscribe')
        price_topic = (*root_topic, 'trade', 'binance', '{base}', '{quote}', '{trade_id}', '{timestamp}', 'price')
        quantity_topic = (*root_topic, 'trade', 'binance', '{base}', '{quote}', '{trade_id}', '{timestamp}', 'quantity')
        kline_topic = (*root_topic, 'kline', 'binance', '{symbol}', '{interval}', '{timestamp}')
        self.conf_pid_topic = '/'.join(pid_topic)
        self.conf_timeout_topic = '/'.join(timeout_topic)
        self.conf_symbol_base_topic = '/'.join(symbol_base_topic)
        self.conf_symbol_quote_topic = '/'.join(symbol_quote_topic)
        self.conf_symbol_topic = '/'.join(symbol_topic)
        self.parse_symbol_base_topic = '/'.join(p_symbol_base_topic)
        self.parse_symbol_quote_topic = '/'.join(p_symbol_quote_topic)
        self.parse_symbol_topic = '/'.join(p_symbol_topic)
        self.price_topic = '/'.join(price_topic)
        self.quantity_topic = '/'.join(quantity_topic)
        self.kline_topic = '/'.join(kline_topic)

        def _(client, userdata, msg, handler):
            topic = msg.topic
            payload = json.loads(msg.payload)
            qos = msg.qos
            retain = msg.retain
            return handler(topic, payload, qos, retain)

        self.client = mqtt.Client(client_id=client_id)
        self.client.on_connect = self.on_connect
        self.client.on_disconnect = self.on_disconnect
        self.client.message_callback_add(self.conf_symbol_base_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_base_message))
        self.client.message_callback_add(self.conf_symbol_quote_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_quote_message))
        self.client.message_callback_add(self.conf_symbol_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_message))
        self.client.will_set(self.conf_pid_topic)
        self.host = host

    async def on_connect(self, client, userdata, flags, rc):
        print('on_connect')
        await asyncio.gather(*[
            client.subscribe(self.conf_timeout_topic),
            client.subscribe(self.conf_symbol_base_topic),
            client.subscribe(self.conf_symbol_quote_topic),
            client.subscribe(self.conf_symbol_topic),
            ])

    async def on_disconnect(self, client, userdata, rc):
        print('on_disconnect', rc)

    async def on_sigint(self, *, mqtt_done, binance_task):
        mqtt_done.set_result(0)
        binance_task.cancel()
        return False

    def get_context(self, symbol):
        if symbol in self.symbol_contexts:
            context = self.symbol_contexts[symbol]
        else:
            context = Main.SymbolContext()
            self.symbol_contexts[symbol] = context
        return context

    async def on_conf_symbol_base_message(self, topic, payload, qos, retain):
        #print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_base_topic, topic)
        context = self.get_context(single_levels['symbol'])
        context.base = payload
        #context.symbol = single_levels['symbol']
        #top = f"inclination/trade/{context.base}/{context.quote}/trade"
        #context._dw = top #self._publisher.add_data_writer(self.client, top, self._topic_type)
        #print(self.symbol_contexts)


    async def on_conf_symbol_quote_message(self, topic, payload, qos, retain):
        #print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_quote_topic, topic)
        context = self.get_context(single_levels['symbol'])
        context.quote = payload
        #context.symbol = single_levels['symbol']
        #top = f"inclination/trade/{context.base}/{context.quote}/trade"
        #context._dw = top #self._publisher.add_data_writer(self.client, top, self._topic_type)
        #print(self.symbol_contexts)
        #pass

    async def on_conf_symbol_message(self, topic, payload, qos, retain):
        #print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_topic, topic)
        context = self.get_context(single_levels['symbol'])
        context.symbol = Symbol(single_levels['symbol'])
        #context.trade = await self.binance.subscribe(TradeStream(context.symbol), self.on_event)
        #print(self.symbol_contexts)

    async def on_ws_connect(self, ws):
        self.binance = ws

        print('Subscribing...')
        #self.fut = asyncio.get_running_loop().create_future()

        streams = []
        for k, v in self.symbol_contexts.items():
            #streams.append(TradeStream(symbol=Symbol(v.symbol))),
            streams.append(KlineCandlestickStream(symbol=Symbol(v.symbol), interval=Interval.INTERVAL_1m))
        #print(streams)
        rval = await ws.subscribe(*streams)
        #print('subscribe =', rval)

        #await self.fut

    @singledispatchmethod
    async def on_event(self, evt, ws):
        print('Error:', type(evt), type(ws))

    @on_event.register
    async def _(self, result: ResultEvent, ws: ClientWebSocketResponse):
        pass

    @on_event.register
    async def _(self, trade: TradeEvent, ws: ClientWebSocketResponse):
        #print('T', end='', flush=True)
        val = {'time': trade.T, 'trade_id': trade.t, 'price': trade.p, 'quantity': trade.q}
        #print('{}\t{}\t{}\t{}'.format(trade.T, trade.s, trade.p, trade.q))
        context = self.get_context(trade.s)
        price_topic = self.price_topic.format(base=context.base, quote=context.quote, trade_id=trade.t, timestamp=trade.T)
        quantity_topic = self.quantity_topic.format(base=context.base, quote=context.quote, trade_id=trade.t, timestamp=trade.T)
        #print(price_topic)
        await asyncio.gather(*[
            self.client.publish(price_topic, json.dumps(trade.p)),
            #self.client.publish(quantity_topic, json.dumps(trade.q)),
            ])

    @on_event.register
    async def _(self, evt: KlineEvent, ws: ClientWebSocketResponse):
        #print('K', end='', flush=True)
        if evt.k.x or True:
            val = {'time': evt.k.t, 'trade_id': evt.k.i, 'open': evt.k.o, 'high': evt.k.h, 'low': evt.k.l, 'close': evt.k.c, 'volume': evt.k.v}
            #print('{}\t{}\t{}\t{}'.format(evt.T, evt.s, evt.p, evt.q))
            context = self.get_context(evt.s)
            kline_topic = self.kline_topic.format(symbol=context.symbol, base=context.base, quote=context.quote, interval=evt.k.i, timestamp=int(evt.k.t))
            await asyncio.gather(*[
                self.client.publish(kline_topic, json.dumps(val)),
                ])

            k = kline('binance', evt.s, evt.k.i, evt.k.t, evt.k.o, evt.k.h, evt.k.l, evt.k.c, evt.k.v)
            kline_writer.write(k)

    async def runner(self):
        global _ws
        await asyncio.sleep(2)
        try:
            async with ClientSession() as session:
                while True:
                    try:
                        async with session.ws_connect() as ws:
                            _ws = ws
                            print('Connected...')
                            await self.on_ws_connect(ws)
                            async for msg in ws:
                                await self.on_event(msg, ws)
                        print('Disconnected...')
                    except Exception as e:
                        print(e)
                        raise
        except asyncio.CancelledError:
            print('Cancelled...')
            pass

    async def __call__(self):
        self.binance_task = asyncio.create_task(self.runner())

        loop = asyncio.get_running_loop()

        mqtt_done = loop.create_future()

        async def mqtt_runner(mqtt_done):
            self.client.loop = loop
            await self.client.connect(self.host)
            await mqtt_done
            await self.client.disconnect()

        mqtt_task = asyncio.create_task(mqtt_runner(mqtt_done))

        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.create_task(partial(self.on_sigint, mqtt_done=mqtt_done, binance_task=self.binance_task)()))

        await asyncio.gather(
                mqtt_task,
                self.binance_task
                )


def cmd():
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='localhost')
    parser.add_argument('--domain', default='inclination')
    parser.add_argument('--name', default='exchange')
    parser.add_argument('--instance', default='0')
    args = parser.parse_args()

    print("Starting")
    loop = None #asyncio.get_event_loop()
    asyncio.run(Main(loop, **vars(args))())
    #loop.close()
    print("Finished")

if __name__ == '__main__':
    cmd()

