import logging
from types import TracebackType
from typing import Any, Optional, Type
import aiohttp
try:
    from attrs import define, frozen, field
except ImportError:
    from attr import define, frozen, field
from inclination.binance.api.websocket.event_factory import EventFactory


logger = logging.getLogger(__name__)


factory = EventFactory()


@define
class ClientWebSocketResponse:
    response: aiohttp.client.ClientWebSocketResponse
    ctr: int = 1

    def __aiter__(self) -> "ClientWebSocketResponse":
        return self

    async def __anext__(self) -> Any:
        msg = await self.response.__anext__()
        event = await factory.create(msg)
        return event

    async def subscribe(self, *streams: object) -> int:
        msg = {
            'method': 'SUBSCRIBE',
            'params': [str(s) for s in streams],
            'id': self.ctr
        }
        self.ctr = self.ctr + 1
        await self.response.send_json(msg)
        return msg['id']

    async def unsubscribe(self, *streams: object) -> int:
        msg = {
            'method': 'UNSUBSCRIBE',
            'params': [str(s) for s in streams],
            'id': self.ctr
        }
        self.ctr = self.ctr + 1
        await self.response.send_json(msg)
        return msg['id']


@frozen
class _WSRequestContextManager:
    request: aiohttp.client._WSRequestContextManager

    async def __aenter__(self) -> ClientWebSocketResponse:
        rval = await self.request.__aenter__()
        return ClientWebSocketResponse(rval)

    async def __aexit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> Optional[bool]:
        return await self.request.__aexit__(exc_type, exc_val, exc_tb)


@frozen
class ClientSession:
    session: aiohttp.ClientSession = field(factory=aiohttp.ClientSession)

    async def __aenter__(self) -> "ClientSession":
        await self.session.__aenter__()
        return self

    async def __aexit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> Optional[bool]:
        return await self.session.__aexit__(exc_type, exc_val, exc_tb)

    def ws_connect(self, url: str = 'wss://stream.binance.com:9443/ws', **kwargs: Any) -> _WSRequestContextManager:
        req = self.session.ws_connect(url=url, **kwargs)
        return _WSRequestContextManager(req)

