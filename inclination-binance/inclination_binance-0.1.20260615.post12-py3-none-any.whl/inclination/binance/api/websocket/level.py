from enum import Enum


class Level(Enum):
	LEVEL_5  = (5)
	LEVEL_10 = (10)
	LEVEL_20 = (20)

	def __init__(self, val):
		self._val = val

	def __str__(self):
		return f'{self._val}'

	@staticmethod
	def from_str(label):
		return getattr(Interval, f'LEVEL_{label}')

