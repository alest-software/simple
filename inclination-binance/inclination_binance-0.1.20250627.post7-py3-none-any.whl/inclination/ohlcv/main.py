import os
import math
from functools import partial
import signal
import json
import parse
import argparse
import asyncio
from decimal import *
from src.mqtt import Client


x = {}

trade_ids = {}

async def on_connect(client, userdata, flags, rc):
    print('connected')
    await asyncio.gather(*[
        client.publish('inclination/pid/ohlcv', os.getpid()),
        client.subscribe('inclination/trade/+/+/+/+/+/price'),
        client.subscribe('inclination/trade/+/+/+/+/+/quantity'),
        client.subscribe('inclination/config/ohlcv/+/+/+/+'),
        ])

async def on_disconnect(client, userdata, rc):
    print('disconnected', rc)

from dataclasses import dataclass

@dataclass
class OhlcvContext:
    series: int = None
    timestamp: float = None
    open: Decimal = None
    high: Decimal = None
    low: Decimal = None
    close: Decimal = None
    volume: Decimal = None

async def on_config(client, userdata, msg):
    topic = parse.parse('inclination/config/ohlcv/{exchange}/{base}/{quote}/{period:d}', msg.topic)
    exchange = topic['exchange']
    base = topic['base']
    quote = topic['quote']
    period = topic['period']
    n = (exchange, base, quote)
    if n not in x:
        x[n] = {}
    if period not in x[n]:
        x[n][period] = OhlcvContext()
    #print(exchange, base, quote, period)

#trades = asyncio.Queue()

awaits = asyncio.Queue()

async def on_trade_price1(client, exchange, base, quote, trade_id, trade):
    symbol = (exchange, base, quote)
    if symbol in x:
        periods = x[symbol]
        for interval, ohlcv_ctxt in periods.items():
            #series, _ = divmod(trade.timestamp, interval)
            series = trade.timestamp // interval
            series = int(series)
            open_timestamp = series * interval
            trade_topic = f"{exchange}/{base}/{quote}"
            if ohlcv_ctxt.series is None:
                ohlcv_ctxt.series = series
                awaits.put_nowait(client.publish(f'inclination/ohlcv/{trade_topic}/{interval}/-/actual/series'))
                print('step1', interval)
            else:
                if ohlcv_ctxt.series != series:
                    if ohlcv_ctxt.open is not None:
                        #print(interval, ohlcv_ctxt, open_timestamp, '>>>>>>>>>>>')
                        awaits.put_nowait(client.publish(f'inclination/ohlcv/{trade_topic}/{interval}/-/candle/series', f"{ohlcv_ctxt.series}"))
                        awaits.put_nowait(client.publish(f'inclination/ohlcv/{trade_topic}/{interval}/-/candle/open',   f"{ohlcv_ctxt.open}"))
                        awaits.put_nowait(client.publish(f'inclination/ohlcv/{trade_topic}/{interval}/-/candle/high',   f"{ohlcv_ctxt.high}"))
                        awaits.put_nowait(client.publish(f'inclination/ohlcv/{trade_topic}/{interval}/-/candle/low',    f"{ohlcv_ctxt.low}"))
                        awaits.put_nowait(client.publish(f'inclination/ohlcv/{trade_topic}/{interval}/-/candle/close',  f"{ohlcv_ctxt.close}"))
                        awaits.put_nowait(client.publish(f'inclination/ohlcv/{trade_topic}/{interval}/-/candle/volume', f"{ohlcv_ctxt.volume}"))

                    ohlcv_ctxt.series = series
                    awaits.put_nowait(client.publish(f'inclination/ohlcv/{trade_topic}/{interval}/-/actual/series', f"{ohlcv_ctxt.series}"))
                    ohlcv_ctxt.open = trade.price
                    awaits.put_nowait(client.publish(f'inclination/ohlcv/{trade_topic}/{interval}/-/actual/open',   f"{ohlcv_ctxt.open}"))
                    ohlcv_ctxt.high = Decimal(0)
                    ohlcv_ctxt.low = Decimal('inf')
                    ohlcv_ctxt.volume = Decimal(0.0)

                if ohlcv_ctxt.open is not None:
                    if ohlcv_ctxt.high < trade.price:
                        ohlcv_ctxt.high = trade.price
                        awaits.put_nowait(client.publish(f'inclination/ohlcv/{trade_topic}/{interval}/-/actual/high',   f"{ohlcv_ctxt.high}"))

                    if ohlcv_ctxt.low > trade.price:
                        ohlcv_ctxt.low = trade.price
                        awaits.put_nowait(client.publish(f'inclination/ohlcv/{trade_topic}/{interval}/-/actual/low',    f"{ohlcv_ctxt.low}"))

                    ohlcv_ctxt.close = trade.price

                    ohlcv_ctxt.volume = ohlcv_ctxt.volume + trade.quantity
                    awaits.put_nowait(client.publish(f'inclination/ohlcv/{trade_topic}/{interval}/-/actual/volume', f"{ohlcv_ctxt.volume}"))


class PriceQuantity:
    def __init__(self):
        self.price = None
        self.quantity = None


async def on_trade_price(client, userdata, msg):
    topic = parse.parse('inclination/trade/{exchange}/{base}/{quote}/{trade_id:d}/{timestamp:f}/price', msg.topic)
    exchange = topic['exchange']
    base = topic['base']
    quote = topic['quote']
    trade_id = topic['trade_id']
    timestamp = topic['timestamp']
    price = Decimal(msg.payload.decode())
    #print(exchange, base, quote, trade_id, divmod(timestamp, 60), price, price)
    symbol = (exchange, base, quote)

    if symbol not in trade_ids:
        trade_ids[symbol] = {}
    if trade_id not in trade_ids[symbol]:
        trade_ids[symbol][trade_id] = PriceQuantity()
    trade_ids[symbol][trade_id].price = price
    trade_ids[symbol][trade_id].timestamp = timestamp
    if (trade_ids[symbol][trade_id].price is not None) and (trade_ids[symbol][trade_id].quantity is not None):
        #print(vars(trade_ids[symbol][trade_id]))
        await on_trade_price1(client, exchange, base, quote, trade_id, trade_ids[symbol][trade_id])
        del trade_ids[symbol][trade_id]


async def on_trade_quantity(client, userdata, msg):
    topic = parse.parse('inclination/trade/{exchange}/{base}/{quote}/{trade_id:d}/{timestamp:f}/quantity', msg.topic)
    exchange = topic['exchange']
    base = topic['base']
    quote = topic['quote']
    trade_id = topic['trade_id']
    timestamp = topic['timestamp']
    quantity = Decimal(msg.payload.decode())
    symbol = (exchange, base, quote)

    if symbol not in trade_ids:
        trade_ids[symbol] = {}
    if trade_id not in trade_ids[symbol]:
        trade_ids[symbol][trade_id] = PriceQuantity()
    trade_ids[symbol][trade_id].quantity = quantity
    trade_ids[symbol][trade_id].timestamp = timestamp
    if (trade_ids[symbol][trade_id].price is not None) and (trade_ids[symbol][trade_id].quantity is not None):
        #print(vars(trade_ids[symbol][trade_id]))
        await on_trade_price1(client, exchange, base, quote, trade_id, trade_ids[symbol][trade_id])
        del trade_ids[symbol][trade_id]


async def on_queue():
    done = False
    while not done or awaits.qsize() > 0:
        a = await awaits.get()
        if a is None:
            done = True
        else:
            await a
            awaits.task_done()
    print('**')

async def on_sigint(client=None, queue_task=None):
    print('SIGINT')
    await client.unsubscribe('inclination/trade/+/+/+/+/+/price')
    await client.unsubscribe('inclination/trade/+/+/+/+/+/quantity')
    await client.unsubscribe('inclination/config/ohlcv/+/+/+/+')
    await client.publish('inclination/pid/ohlcv', retain=True)
    awaits.put_nowait(None)
    await queue_task
    #print('task')
    await client.disconnect()
    #print('disc')

async def main(*, mqtt_host, mqtt_port, mqtt_keepalive):
    loop = asyncio.get_running_loop()
    client = Client()
    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    client.will_set('inclination/pid/ohlcv', retain=True)
    client.message_callback_add('inclination/trade/+/+/+/+/+/price', on_trade_price)
    client.message_callback_add('inclination/trade/+/+/+/+/+/quantity', on_trade_quantity)
    client.message_callback_add('inclination/config/ohlcv/+/+/+/+', on_config)
    client.loop = loop
    await client.connect(mqtt_host, mqtt_port, mqtt_keepalive)

    queue_task = asyncio.create_task(on_queue())

    loop.add_signal_handler(signal.SIGINT, lambda: asyncio.create_task(partial(on_sigint, client=client, queue_task=queue_task)()))

    await asyncio.gather(*[
        client.loop_forever(),
        ])

def cmd():
    parser = argparse.ArgumentParser(
            prog='inclination-ohlcv',
            description='OHLCV',
            epilog='(C)2022 M. de Wit. All rights reserved.')
    parser.add_argument('--mqtt-host', default='127.0.0.1', metavar='HOST', help='hostname or IP-address of the remote broker')
    parser.add_argument('--mqtt-port', type=int, default=1883, metavar='PORT', help='network port of the server host to connect to')
    parser.add_argument('--mqtt-keepalive', type=int, default=60, metavar='SEC')
    args = parser.parse_args()
    asyncio.run(main(**vars(args)))

if __name__ == '__main__':
    cmd()

