import os
from functools import partial, singledispatchmethod
import signal
import json
import time
import parse
import argparse
import asyncio
import socket
import uuid
from . import mqtt
from attrs import define, field
from inclination.binance.api.websocket.client import *
from inclination.binance.api.websocket.stream import *
from inclination.binance.api.websocket.klineupdate import *
from inclination.binance.api.websocket.symbol import Symbol
from inclination.binance.api.websocket.interval import Interval
from cyclonedds.domain import DomainParticipant
from cyclonedds.topic import Topic
from cyclonedds.pub import DataWriter
from cyclonedds.sub import DataReader
from cyclonedds.util import duration
from cyclonedds.core import Listener, Qos
#from cyclonedds.qos import Policy
from inclination.idl.ohlcv import *


participant = DomainParticipant()
kline_topic = Topic(participant, "kline", kline_t)
trade_topic = Topic(participant, "trade", trade_t)
kline_writer = DataWriter(participant, kline_topic)
trade_writer = DataWriter(participant, trade_topic)


@define
class Main:
    symbol_contexts:          dict = field(factory=dict)
    conf_pid_topic:           int = None
    conf_timeout_topic:       int = None
    conf_symbol_base_topic:   int = None
    conf_symbol_quote_topic:  int = None
    conf_symbol_trade_topic:        int = None
    conf_symbol_kline_topic:        int = None
    conf_symbol_kline_all_topic:        int = None
    parse_symbol_base_topic:  int = None
    parse_symbol_quote_topic: int = None
    parse_symbol_trade_topic:       int = None
    parse_symbol_kline_topic:       int = None
    parse_symbol_kline_all_topic:       int = None
    price_topic:              int = None
    quantity_topic:           int = None
    kline_topic:              int = None
    client:                   int = None
    host:                     int = None
    binance_task:             int = None
    binance:                  int = None

    @define
    class SymbolContext:
        base:   str  = None
        quote:  str  = None
        symbol: str  = None
        trade:  bool = False
        kline:  bool = False
        kline_all: bool = False


    def __init__(self, host, domain, name, instance, *args, **kwargs):
        self.__attrs_init__(*args, **kwargs)

        client_id = '{}/{}/{}/'.format(domain, name, instance) + str(uuid.uuid4())

        root_topic = (domain,)
        pid_topic = (*root_topic, 'proc', 'pid')
        config_topic = (*root_topic, 'config', name, instance)
        timeout_topic = (*config_topic, 'timeout')
        symbol_base_topic = (*config_topic, 'symbol', '+', 'base')
        symbol_quote_topic = (*config_topic, 'symbol', '+', 'quote')
        symbol_trade_topic = (*config_topic, 'symbol', '+', 'trade', 'subscribe')
        symbol_kline_topic = (*config_topic, 'symbol', '+', 'kline', 'subscribe')
        symbol_kline_all_topic = (*config_topic, 'symbol', '+', 'kline', 'all')
        p_symbol_base_topic = (*config_topic, 'symbol', '{symbol}', 'base')
        p_symbol_quote_topic = (*config_topic, 'symbol', '{symbol}', 'quote')
        p_symbol_trade_topic = (*config_topic, 'symbol', '{symbol}', 'trade', 'subscribe')
        p_symbol_kline_topic = (*config_topic, 'symbol', '{symbol}', 'kline', 'subscribe')
        p_symbol_kline_all_topic = (*config_topic, 'symbol', '{symbol}', 'kline', 'all')
        price_topic = (*root_topic, 'trade', 'binance', '{base}', '{quote}', '{trade_id}', '{timestamp}', 'price')
        quantity_topic = (*root_topic, 'trade', 'binance', '{base}', '{quote}', '{trade_id}', '{timestamp}', 'quantity')
        kline_topic = (*root_topic, 'kline', 'binance', '{symbol}', '{interval}', '{timestamp}')
        self.conf_pid_topic = '/'.join(pid_topic)
        self.conf_timeout_topic = '/'.join(timeout_topic)
        self.conf_symbol_base_topic = '/'.join(symbol_base_topic)
        self.conf_symbol_quote_topic = '/'.join(symbol_quote_topic)
        self.conf_symbol_trade_topic = '/'.join(symbol_trade_topic)
        self.conf_symbol_kline_topic = '/'.join(symbol_kline_topic)
        self.conf_symbol_kline_all_topic = '/'.join(symbol_kline_all_topic)
        self.parse_symbol_base_topic = '/'.join(p_symbol_base_topic)
        self.parse_symbol_quote_topic = '/'.join(p_symbol_quote_topic)
        self.parse_symbol_trade_topic = '/'.join(p_symbol_trade_topic)
        self.parse_symbol_kline_topic = '/'.join(p_symbol_kline_topic)
        self.parse_symbol_kline_all_topic = '/'.join(p_symbol_kline_all_topic)
        self.price_topic = '/'.join(price_topic)
        self.quantity_topic = '/'.join(quantity_topic)
        self.kline_topic = '/'.join(kline_topic)

        def _(client, userdata, msg, handler):
            topic = msg.topic
            payload = json.loads(msg.payload)
            qos = msg.qos
            retain = msg.retain
            return handler(topic, payload, qos, retain)

        self.client = mqtt.Client(client_id=client_id)
        self.client.on_connect = self.on_connect
        self.client.on_disconnect = self.on_disconnect
        self.client.message_callback_add(self.conf_symbol_base_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_base_message))
        self.client.message_callback_add(self.conf_symbol_quote_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_quote_message))
        self.client.message_callback_add(self.conf_symbol_trade_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_message))
        self.client.message_callback_add(self.conf_symbol_kline_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_kline_message))
        self.client.message_callback_add(self.conf_symbol_kline_all_topic, lambda c, u, m: _(c, u, m, self.on_conf_symbol_kline_all_message))
        self.client.will_set(self.conf_pid_topic)
        self.host = host

    async def on_connect(self, client, userdata, flags, rc):
        print('on_connect')
        await asyncio.gather(*[
            client.subscribe(self.conf_timeout_topic),
            client.subscribe(self.conf_symbol_base_topic),
            client.subscribe(self.conf_symbol_quote_topic),
            client.subscribe(self.conf_symbol_trade_topic),
            client.subscribe(self.conf_symbol_kline_topic),
            client.subscribe(self.conf_symbol_kline_all_topic),
            ])

    async def on_disconnect(self, client, userdata, rc):
        print('on_disconnect', rc)

    async def on_sigint(self, *, mqtt_done, binance_task):
        mqtt_done.set_result(0)
        binance_task.cancel()
        return False

    def get_context(self, symbol):
        if symbol in self.symbol_contexts:
            context = self.symbol_contexts[symbol]
        else:
            context = Main.SymbolContext()
            context.symbol = symbol
            self.symbol_contexts[symbol] = context
        return context

    async def on_conf_symbol_base_message(self, topic, payload, qos, retain):
        print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_base_topic, topic)
        context = self.get_context(single_levels['symbol'])
        context.base = payload

    async def on_conf_symbol_quote_message(self, topic, payload, qos, retain):
        print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_quote_topic, topic)
        context = self.get_context(single_levels['symbol'])
        context.quote = payload

    async def on_conf_symbol_message(self, topic, payload, qos, retain):
        print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_trade_topic, topic)
        context = self.get_context(single_levels['symbol'])
        context.trade = payload

    async def on_conf_symbol_kline_message(self, topic, payload, qos, retain):
        print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_kline_topic, topic)
        context = self.get_context(single_levels['symbol'])
        context.kline = payload

    async def on_conf_symbol_kline_all_message(self, topic, payload, qos, retain):
        print(topic, payload, qos, retain)
        single_levels = parse.parse(self.parse_symbol_kline_all_topic, topic)
        context = self.get_context(single_levels['symbol'])
        context.kline_all = payload

    async def on_ws_connect(self, ws):
        self.binance = ws

        print('Subscribing...')

        streams = []
        for k, v in self.symbol_contexts.items():
            if v.trade:
                streams.append(TradeStream(symbol=Symbol(v.symbol))),
            if v.kline:
                streams.append(KlineCandlestickStream(symbol=Symbol(v.symbol), interval=Interval.INTERVAL_1m))

        rval = await ws.subscribe(*streams)

    @singledispatchmethod
    async def on_event(self, evt, ws):
        print('Error:', type(evt), type(ws))

    @on_event.register
    async def _(self, result: ResultEvent, ws: ClientWebSocketResponse):
        pass

    @on_event.register
    async def _(self, trade: TradeEvent, ws: ClientWebSocketResponse):
        #print('T', end='', flush=True)
        #print(trade)

        context = self.get_context(trade.s)

        key = {
            'base':      context.base,
            'quote':     context.quote,
            'trade_id':  trade.t,
            'timestamp': trade.T,
        }
        val = {
            'time':     trade.T,
            'trade_id': trade.t,
            'price':    trade.p,
            'quantity': trade.q
        }

        price_topic = self.price_topic.format(**key)
        quantity_topic = self.quantity_topic.format(**key)

        await asyncio.gather(*[
            self.client.publish(price_topic, json.dumps(trade.p)),
            #self.client.publish(quantity_topic, json.dumps(trade.q)),
            ])

        args = {
            'exchange':        'binance',
            'symbol':          context.symbol,
            'event_timestamp': trade.E,
            'trade_timestamp': trade.T,
            'trade_id':        trade.t,
            'price':           trade.p,
            'quantity':        trade.q,
        }
        t = trade_t(**args)
        trade_writer.write(t)

    @on_event.register
    async def _(self, evt: KlineEvent, ws: ClientWebSocketResponse):
        #print('K', end='', flush=True)
        #print(evt)

        context = self.get_context(evt.s)

        if evt.k.x or context.kline_all:

            key = {
                'symbol':    context.symbol,
                'base':      context.base,
                'quote':     context.quote,
                'interval':  evt.k.i,
                'timestamp': int(evt.k.t)
            }
            val = {
                'time':     evt.k.t,
                'open':     evt.k.o,
                'high':     evt.k.h,
                'low':      evt.k.l,
                'close':    evt.k.c,
                'volume':   evt.k.v
            }
            kline_topic = self.kline_topic.format(**key)
            await asyncio.gather(*[
                self.client.publish(kline_topic, json.dumps(val)),
                ])

            args = {
                'exchange':  'binance',
                'symbol':    context.symbol,
                'interval':  evt.k.i,
                'timestamp': int(evt.k.t),
                'open':      evt.k.o,
                'high':      evt.k.h,
                'low':       evt.k.l,
                'close':     evt.k.c,
                'volume':    evt.k.v,
            }
            k = kline_t(**args)
            kline_writer.write(k)

    async def runner(self):
        global _ws
        await asyncio.sleep(2)
        try:
            async with ClientSession() as session:
                while True:
                    try:
                        async with session.ws_connect() as ws:
                            _ws = ws
                            print('Connected...')
                            await self.on_ws_connect(ws)
                            async for msg in ws:
                                await self.on_event(msg, ws)
                        print('Disconnected...')
                    except Exception as e:
                        print(e)
                        raise
        except asyncio.CancelledError:
            print('Cancelled...')
            pass

    async def __call__(self):
        self.binance_task = asyncio.create_task(self.runner())

        loop = asyncio.get_running_loop()

        mqtt_done = loop.create_future()

        async def mqtt_runner(mqtt_done):
            self.client.loop = loop
            await self.client.connect(self.host)
            await mqtt_done
            await self.client.disconnect()

        mqtt_task = asyncio.create_task(mqtt_runner(mqtt_done))

        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.create_task(partial(self.on_sigint, mqtt_done=mqtt_done, binance_task=self.binance_task)()))

        await asyncio.gather(
                mqtt_task,
                self.binance_task
                )


def cmd():
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='localhost')
    parser.add_argument('--domain', default='inclination')
    parser.add_argument('--name', default='exchange')
    parser.add_argument('--instance', default='0')
    args = parser.parse_args()

    print("Starting")
    asyncio.run(Main(**vars(args))())
    print("Finished")

if __name__ == '__main__':
    cmd()

