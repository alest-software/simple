import logging
import aiohttp
from inclination.binance.api.websocket.event_factory import *


logger = logging.getLogger(__name__)


factory = EventFactory()


@define
class ClientWebSocketResponse:
    response: aiohttp.client.ClientWebSocketResponse
    ctr: int = 1

    def __aiter__(self):
        self.response.__aiter__()
        return self

    async def __anext__(self):
        msg = await self.response.__anext__()
        event = await factory.create(msg)
        return event

    async def subscribe(self, *streams):
        msg = {
            'method': 'SUBSCRIBE',
            'params': [str(s) for s in streams],
            'id': self.ctr
        }
        self.ctr = self.ctr + 1
        await self.response.send_json(msg)
        return msg['id']

    async def unsubscribe(self, *streams):
        msg = {
            'method': 'UNSUBSCRIBE',
            'params': [str(s) for s in streams],
            'id': self.ctr
        }
        self.ctr = self.ctr + 1
        await self.response.send_json(msg)
        return msg['id']


@frozen
class _WSRequestContextManager:
    request: aiohttp.client._WSRequestContextManager

    async def __aenter__(self):
        rval = await self.request.__aenter__()
        return ClientWebSocketResponse(rval)

    async def __aexit__(self, exc_type, exc, tb):
        return await self.request.__aexit__(exc_type, exc, tb)


@frozen
class ClientSession:
    session: aiohttp.ClientSession = field(factory=aiohttp.ClientSession)

    async def __aenter__(self):
        await self.session.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return await self.session.__aexit__(exc_type, exc, tb)

    def ws_connect(self, url='wss://stream.binance.com:9443/ws', **kwargs):
        req = self.session.ws_connect(url=url, **kwargs)
        return _WSRequestContextManager(req)

