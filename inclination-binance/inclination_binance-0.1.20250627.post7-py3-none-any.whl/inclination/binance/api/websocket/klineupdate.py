from datetime import datetime
from attr import frozen, define, field, asdict
from attr.validators import instance_of
#from typing import List
from typing import Generic, TypeVar, List
from .stream import *


T = TypeVar('T')


class Event:
    def __init__(self):
        pass

    async def handle(self, visitor, **kwargs):
        return await getattr(visitor, 'handleEvent')(self, **kwargs)

#    def __repr__(self):
#        return '({0}){1}'.format(type(self).__name__, vars(self))


timestamp = lambda x: float(x) / 1000.0


class EventList(List[T]):
    def __init__(self, factory, iterable=[]):
        self._factory = factory
        super().__init__(self._factory(i) for i in iterable)

    def __setitem__(self, index, item):
        super().__setitem__(index, self._factory(item))

    def insert(self, index, item):
        super().insert(index, self._factory(item))

    def append(self, item):
        super().append(self._factory(item))

    def extend(self, other):
        if isinstance(other, type(self)):
            super().extend(other)
        else:
            super().extend(self._factory(i) for i in other)


@frozen
class ResultEvent(Event):
    id:     int
    result: str


@frozen
class  ErrorEvent(Event):
    id:      int
    code:    int = None
    message: str = None
    error: str = None


@frozen(kw_only=True)
class AggregateTradeEvent(Event):
    E: float = field(converter=timestamp)
    s: str   = field(validator=instance_of(str))
    a: int   = field(validator=instance_of(int))
    p: float = field(converter=float)
    q: float = field(converter=float)
    f: int   = field(validator=instance_of(int))
    l: int   = field(validator=instance_of(int))
    T: float = field(converter=timestamp)
    m: bool  = field(validator=instance_of(bool))
    #M: bool  = field(validator=instance_of(bool))

    def __init__(self, *, e, M, **kwargs):
        self.__attrs_init__(**kwargs)


@frozen(kw_only=True)
class TradeEvent(Event):
    E: float = field(converter=timestamp)
    T: float = field(converter=timestamp)
    s: str   = field(validator=instance_of(str))
    t: int   = field(validator=instance_of(int))
    p: float = field(converter=float)
    q: float = field(converter=float)
    m: bool  = field(validator=instance_of(bool))
    #M: bool  = field(validator=instance_of(bool))

    def __init__(self, *, e, M, **kwargs):
        self.__attrs_init__(**kwargs)


@frozen(kw_only=True)
class KlineInfo:
    t: float = field(converter=timestamp)
    T: float = field(converter=timestamp)
    s: str   = field(validator=instance_of(str))
    i: str   = field(validator=instance_of(str))
    f: int   = field(validator=instance_of(int))
    L: int   = field(validator=instance_of(int))
    o: float = field(converter=float)
    h: float = field(converter=float)
    l: float = field(converter=float)
    c: float = field(converter=float)
    v: float = field(converter=float)
    n: int   = field(validator=instance_of(int))
    x: bool  = field(validator=instance_of(bool))
    q: float = field(converter=float)
    V: float = field(converter=float)
    Q: float = field(converter=float)
    B: str   = field(validator=instance_of(str))


KlineInfo_converter = lambda x: KlineInfo(**x)


@frozen(kw_only=True)
class KlineEvent(Event):
    E: float     = field(converter=timestamp)
    s: str       = field(validator=instance_of(str))
    k: KlineInfo = field(converter=KlineInfo_converter)

    def __init__(self, *, e, **kwargs):
        self.__attrs_init__(**kwargs)


# Individual Symbol Mini Ticker Stream _or_ All Market Mini Tickers Stream
@frozen(kw_only=True)
class MiniTickerEvent(Event):
    E: float = field(converter=timestamp)
    s: str   = field(validator=instance_of(str))
    c: float = field(converter=float)
    o: float = field(converter=float)
    h: float = field(converter=float)
    l: float = field(converter=float)
    v: float = field(converter=float)
    q: float = field(converter=float)

    def __init__(self, *, e, **kwargs):
        self.__attrs_init__(**kwargs)

    @classmethod
    def from_dict(cls, x):
        return cls(**x)


#MiniTickerEvent_parse = lambda x: MiniTickerEvent(**x)



class MiniTickerEventList(EventList[MiniTickerEvent]):
    def __init__(self, iterable=[]):
        super().__init__(MiniTickerEvent.from_dict, iterable)


# Individual Symbol Ticker Streams _or_ All Market Tickers Stream
@frozen(kw_only=True)
class TickerEvent(Event):
    E: float = field(converter=timestamp)
    s: str   = field(validator=instance_of(str))
    p: float = field(converter=float)
    P: float = field(converter=float)
    w: float = field(converter=float)
    x: float = field(converter=float)
    c: float = field(converter=float)
    Q: float = field(converter=float)
    b: float = field(converter=float)
    B: float = field(converter=float)
    a: float = field(converter=float)
    A: float = field(converter=float)
    o: float = field(converter=float)
    h: float = field(converter=float)
    l: float = field(converter=float)
    v: float = field(converter=float)
    q: float = field(converter=float)
    O: float = field(converter=timestamp)
    C: float = field(converter=timestamp)
    F: int   = field(validator=instance_of(int))
    L: int   = field(validator=instance_of(int))
    n: int   = field(validator=instance_of(int))

    def __init__(self, *, e, **kwargs):
        self.__attrs_init__(**kwargs)

    @classmethod
    def from_dict(cls, x):
        return cls(**x)


class TickerEventList(EventList[TickerEvent]):
    def __init__(self, iterable=[]):
        super().__init__(TickerEvent.from_dict, iterable)


# Individual Symbol Book Ticker Streams _or_ All Book Tickers Stream
@frozen(kw_only=True)
class BookTickerEvent(Event):
    u: int   = field(validator=instance_of(int))
    s: str   = field(validator=instance_of(str))
    b: float = field(converter=float)
    B: float = field(converter=float)
    a: float = field(converter=float)
    A: float = field(converter=float)

    @classmethod
    def from_dict(cls, x):
        return cls(**x)


class BookTickerEventList(EventList[BookTickerEvent]):
    def __init__(self, iterable=[]):
        super().__init__(BookTickerEvent.from_dict, iterable)


# Werkt niet, geen symbol in event...
@frozen(kw_only=True)
class PartialBookDepthEvent(Event):
    lastUpdateId: int
    bids:         int
    asks:         int

#    def __init__(self, lastUpdateId, bids, asks, **ext):
#        self._lastUpdateId = int(lastUpdateId)    # Last update ID
#        self._bids = []                            # Bids to be updated []
#        for x in bids:
#            self._bids.append([float(x[0]), float(x[1])])
#        self._asks = []                            # Asks to be updated []
#        for x in asks:
#            self._asks.append([float(x[0]), float(x[1])])
#        self._ext = ext

#    def getStream(self):
#        return PartialBookDepthStream()
#
#    def __str__(self):
#        return '{0},{1},{2}'.format(self._lastUpdateId, self._bids, self._asks)


@frozen(kw_only=True)
class DDepthInfo:
    x: float = field(converter=float)
    y: float = field(converter=float)


DDepthInfo_converter = lambda x: [DDepthInfo(i[0], i[1]) for i in x]


@frozen(kw_only=True)
class DifferentialDepthEvent(Event):
    E: float = field(converter=timestamp)
    s: str   = field(validator=instance_of(str))
    U: int   = field(validator=instance_of(int))
    u: int   = field(validator=instance_of(int))
    b: list  = field(converter=DDepthInfo_converter)
    a: list  = field(converter=DDepthInfo_converter)

    def __init__(self, *, e, **kwargs):
        self.__attrs_init__(**kwargs)

