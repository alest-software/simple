
from enum import Enum


class UpdateSpeed(Enum):
	UPDATESPEED_100ms  = (100)
	UPDATESPEED_1000ms = (1000)

	def __init__(self, val):
		self._val = val

	def __str__(self):
		return f'{self._val}ms'

	@staticmethod
	def from_str(label):
		return getattr(Interval, f'UPDATESPEED_{label}')

