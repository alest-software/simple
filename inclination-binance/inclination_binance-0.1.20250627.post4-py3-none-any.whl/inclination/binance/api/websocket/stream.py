from attrs import frozen, field
from attrs.validators import instance_of
from .interval import *
from .updatespeed import *
from .level import *
from .symbol import *


class StreamBase:
    pass


@frozen(kw_only=True)
class AggregateTradeStream(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))

    def __str__(self):
        return f'{self.symbol.lower()}@aggTrade'


@frozen(kw_only=True)
class TradeStream(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))

    def __str__(self):
        return f'{self.symbol.lower()}@trade'


@frozen(kw_only=True)
class KlineCandlestickStream(StreamBase):
    symbol:   Symbol = field(validator=instance_of(Symbol))
    interval: Interval = field(validator=instance_of(Interval))

    def __str__(self):
        return f'{self.symbol.lower()}@kline_{self.interval}'


@frozen(kw_only=True)
class IndividualSymbolMiniTickerStream(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))

    def __str__(self):
        return f'{self.symbol.lower()}@miniTicker'


@frozen(kw_only=True)
class AllMarketMiniTickersStream(StreamBase):
    def __str__(self):
        return '!miniTicker@arr'


@frozen(kw_only=True)
class IndividualSymbolTickerStream(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))

    def __str__(self):
        return f'{self.symbol.lower()}@ticker'


@frozen(kw_only=True)
class AllMarketTickersStream(StreamBase):
    def __str__(self):
        return '!ticker@arr'


@frozen(kw_only=True)
class IndividualSymbolBookTickerStream(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))

    def __str__(self):
        return f'{self.symbol.lower()}@bookTicker'


@frozen(kw_only=True)
class AllBookTickersStream(StreamBase):
    def __str__(self):
        return '!bookTicker'


@frozen(kw_only=True)
class PartialBookDepthStream(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))
    level: Level = field(validator=instance_of(Level))
    rate: UpdateSpeed = field(validator=instance_of(UpdateSpeed))

    def __str__(self):
        return f'{self.symbol.lower()}@depth{self.level}@{self.rate}'


@frozen(kw_only=True)
class DiffDepthStream(StreamBase):
    symbol: Symbol = field(validator=instance_of(Symbol))
    rate: UpdateSpeed = field(validator=instance_of(UpdateSpeed))

    def __str__(self):
        return f'{self.symbol.lower()}@depth@{self.rate}'

