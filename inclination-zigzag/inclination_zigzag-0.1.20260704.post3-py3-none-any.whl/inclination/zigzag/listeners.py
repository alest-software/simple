import asyncio
from attr import define
import fastdds

from inclination.idl_ex.ohlcv import Series


@define
class SubscriptionMatched:
    reader: fastdds.DataReader
    info: fastdds.SubscriptionMatchedStatus


@define
class RequestDeadlineMissed:
    reader: fastdds.DataReader
    info: fastdds.RequestedDeadlineMissedStatus


@define
class LivelinessChanged:
    reader: fastdds.DataReader
    info: fastdds.LivelinessChangedStatus


@define
class RequestedIncompatibleQos:
    reader: fastdds.DataReader
    info: fastdds.RequestedIncompatibleQosStatus


@define
class SampleRejected:
    reader: fastdds.DataReader
    info: fastdds.SampleRejectedStatus


@define
class SampleLost:
    reader: fastdds.DataReader
    info: fastdds.SampleLostStatus


@define
class SeriesListener(fastdds.DataReaderListener):
    topic: str
    queue: asyncio.Queue
    loop: asyncio.AbstractEventLoop

    def __attrs_post_init__(self):
        super().__init__()

    def _put(self, item) -> None:
        try:
            self.queue.put_nowait(item)
        except asyncio.QueueFull:
            print(f"WARNING: queue full, dropping {self.topic} sample")

    def on_data_available(self, reader: fastdds.DataReader) -> None:
        info = fastdds.SampleInfo()
        while True:
            data = Series()
            result = reader.take_next_sample(data, info)
            if result == fastdds.RETCODE_OK:
                if info.valid_data:
                    self.loop.call_soon_threadsafe(
                        self._put, (data, self.topic))
            elif result == fastdds.RETCODE_NO_DATA:
                break
            else:
                print(f"WARNING: take_next_sample returned {result}")
                break

    def on_subscription_matched(
        self, reader: fastdds.DataReader, info: fastdds.SubscriptionMatchedStatus
    ) -> None:
        print(f"[{self.topic}] subscription matched: "
              f"cur_count={info.current_count} change={info.current_count_change}")
        data = SubscriptionMatched(reader, info)
        self.loop.call_soon_threadsafe(self._put, (data, self.topic))

    def on_requested_deadline_missed(
        self, reader: fastdds.DataReader, info: fastdds.RequestedDeadlineMissedStatus
    ) -> None:
        print(f"[{self.topic}] deadline missed: "
              f"total={info.total_count} change={info.total_count_change}")
        data = RequestDeadlineMissed(reader, info)
        self.loop.call_soon_threadsafe(self._put, (data, self.topic))

    def on_liveliness_changed(
        self, reader: fastdds.DataReader, info: fastdds.LivelinessChangedStatus
    ) -> None:
        print(f"[{self.topic}] liveliness changed: "
              f"alive={info.alive_count} not_alive={info.not_alive_count} "
              f"change={info.alive_count_change}")
        data = LivelinessChanged(reader, info)
        self.loop.call_soon_threadsafe(self._put, (data, self.topic))

    def on_requested_incompatible_qos(
        self, reader: fastdds.DataReader, info: fastdds.RequestedIncompatibleQosStatus
    ) -> None:
        print(f"[{self.topic}] incompatible QoS: "
              f"policy={info.last_policy_id} total={info.total_count} change={info.total_count_change}")
        data = RequestedIncompatibleQos(reader, info)
        self.loop.call_soon_threadsafe(self._put, (data, self.topic))

    def on_sample_rejected(
        self, reader: fastdds.DataReader, info: fastdds.SampleRejectedStatus
    ) -> None:
        print(f"[{self.topic}] sample rejected: "
              f"reason={info.last_reason} total={info.total_count} change={info.total_count_change}")
        data = SampleRejected(reader, info)
        self.loop.call_soon_threadsafe(self._put, (data, self.topic))

    def on_sample_lost(
        self, reader: fastdds.DataReader, info: fastdds.SampleLostStatus
    ) -> None:
        print(f"[{self.topic}] sample lost: "
              f"total={info.total_count} change={info.total_count_change}")
        data = SampleLost(reader, info)
        self.loop.call_soon_threadsafe(self._put, (data, self.topic))
