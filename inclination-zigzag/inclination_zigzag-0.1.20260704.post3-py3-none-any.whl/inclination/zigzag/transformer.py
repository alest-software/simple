import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class DirectionalChangeTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, deviation_pct: float = 0.0005, backstep: int = 0):
        self.deviation_pct = deviation_pct
        self.backstep = backstep
        self._reset_state()

    def _reset_state(self):
        self._pivot_specs: dict[int, tuple[int, float, str, int, float]] = {}
        self._trend = 0
        self._extreme_price = 0.0
        self._extreme_index = 0
        self._last_pivot_index = -1
        self._last_pivot_type = ''
        self._bar_count = 0
        self._sid_of_bar: dict[int, int] = {}

    def fit(self, X: pd.DataFrame, y=None):
        self._reset_state()
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        result = X.copy()
        complete = result.dropna()
        new_rows = complete.iloc[self._bar_count:]
        new_pivot_list: list[tuple] = []

        for _, row in new_rows.iterrows():
            sid = row.name
            bar_idx = self._bar_count
            self._bar_count += 1
            self._sid_of_bar[bar_idx] = sid

            high = float(row['high'])
            low = float(row['low'])
            close = float(row['close'])
            deviation = self.deviation_pct / 100.0

            if self._trend == 0:
                midpoint = (high + low) / 2.0
                self._trend = 1 if close >= midpoint else -1
                self._extreme_price = high if self._trend == 1 else low
                self._extreme_index = bar_idx
            elif self._trend == 1:
                if high >= self._extreme_price:
                    self._extreme_price = high
                    self._extreme_index = bar_idx
                elif self._extreme_price > 0:
                    retrace = (self._extreme_price - low) / self._extreme_price
                    if retrace >= deviation:
                        if (self._last_pivot_index < 0
                                or self._extreme_index >= self._last_pivot_index + self.backstep):
                            pivot_idx = self._extreme_index
                            pivot_price = self._extreme_price
                            pivot_sid = self._sid_of_bar.get(pivot_idx)
                            if pivot_sid is not None:
                                self._pivot_specs[pivot_sid] = (pivot_idx, pivot_price, 'high', sid, close)
                                new_pivot_list.append((pivot_idx, pivot_price, 'high', sid, close))
                            self._last_pivot_index = pivot_idx
                            self._trend = -1
                            self._last_pivot_type = 'high'
                            self._extreme_price = low
                            self._extreme_index = bar_idx
            else:
                if low <= self._extreme_price:
                    self._extreme_price = low
                    self._extreme_index = bar_idx
                elif self._extreme_price > 0:
                    retrace = (high - self._extreme_price) / self._extreme_price
                    if retrace >= deviation:
                        if (self._last_pivot_index < 0
                                or self._extreme_index >= self._last_pivot_index + self.backstep):
                            pivot_idx = self._extreme_index
                            pivot_price = self._extreme_price
                            pivot_sid = self._sid_of_bar.get(pivot_idx)
                            if pivot_sid is not None:
                                self._pivot_specs[pivot_sid] = (pivot_idx, pivot_price, 'low', sid, close)
                                new_pivot_list.append((pivot_idx, pivot_price, 'low', sid, close))
                            self._last_pivot_index = pivot_idx
                            self._trend = 1
                            self._last_pivot_type = 'low'
                            self._extreme_price = high
                            self._extreme_index = bar_idx

        for col in ['high_pivot_price', 'high_detection_price',
                     'low_pivot_price', 'low_detection_price']:
            result[col] = np.float64(np.nan)
        for col in ['high_pivot_sid', 'high_detection_sid',
                     'low_pivot_sid', 'low_detection_sid']:
            result[col] = pd.array([pd.NA] * len(result), dtype=pd.Int64Dtype())

        for sid in sorted(self._pivot_specs):
            bar_idx, price, ptype, detection_sid, detection_price = self._pivot_specs[sid]
            if ptype == 'high':
                result.at[sid, 'high_detection_sid'] = detection_sid
                result.at[sid, 'high_detection_price'] = detection_price
                result.at[detection_sid, 'high_pivot_price'] = price
                result.at[detection_sid, 'high_pivot_sid'] = sid
            else:
                result.at[sid, 'low_detection_sid'] = detection_sid
                result.at[sid, 'low_detection_price'] = detection_price
                result.at[detection_sid, 'low_pivot_price'] = price
                result.at[detection_sid, 'low_pivot_sid'] = sid

        self._new_pivot_list = new_pivot_list
        return result

    @property
    def pivots(self) -> list[tuple]:
        return self._new_pivot_list
