import argparse
import asyncio
import signal
from functools import singledispatch
from pathlib import Path

import fastdds
import numpy as np
import pandas as pd
import tomli

from inclination.idl_ex.ohlcv import Series, SeriesPubSubType
from inclination.zigzag.listeners import SeriesListener, SubscriptionMatched
from inclination.zigzag.transformer import DirectionalChangeTransformer


_deviation_pct: float = 0.0
_backstep: int = 0


_INTERVAL_MAP = {
    "m": 60, "h": 3600, "d": 86400, "w": 604800, "M": 2592000,
}


def _interval_to_seconds(interval_id: str) -> int:
    num = int(interval_id[:-1])
    unit = interval_id[-1]
    return num * _INTERVAL_MAP[unit]


auto_insert = ["high", "low", "close"]
_context: dict[tuple, dict[str, pd.DataFrame]] = {}


def _series_to_dataframe(data: Series, col_name: str):
    ts = data.timestamp()
    interval = _interval_to_seconds(data.interval_id())
    values = np.array(data.data())
    nof_values = len(values)
    sid = int(ts // interval)
    sids = np.arange(sid, sid - nof_values, -1)
    df = pd.DataFrame({
        "sid": sids,
        col_name: values})
    return df.set_index("sid")


def _update_context(key: tuple, data: Series, field: str):
    if key not in _context:
        r = {}
        for value in auto_insert:
            r[value] = pd.DataFrame(columns=["sid", value]).set_index("sid")
        _context[key] = r

    ctxt = _context[key]
    df_series = _series_to_dataframe(data, field)
    ctxt[field] = df_series
    df = pd.concat(ctxt.values(), axis=1).sort_index()
    return df



_dc_transformers: dict[tuple, DirectionalChangeTransformer] = {}


@singledispatch
def handle_series(data, topic_name: str, *args) -> None:
    raise TypeError(f"unsupported data type: {type(data).__name__}")


@handle_series.register(Series)
def _handle_series(data: Series, topic_name: str, *args) -> None:
    field = topic_name.removesuffix('_s')
    key = (data.exchange_id(), data.symbol_id(), data.interval_id())
    df = _update_context(key, data, field)
    if df is not None:
        if key not in _dc_transformers:
            _dc_transformers[key] = DirectionalChangeTransformer(deviation_pct=_deviation_pct, backstep=_backstep)
        transformer = _dc_transformers[key]
        df = transformer.transform(df)

        print(df[['high', 'low', 'close', 'high_pivot_sid', 'high_pivot_price',
                   'high_detection_sid', 'high_detection_price',
                   'low_pivot_sid', 'low_pivot_price', 'low_detection_sid',
                   'low_detection_price']])
        for p in transformer.pivots:
            print(f"pivot: {p[2]} at idx={p[0]} price={p[1]:.2f} (pivot_sid={p[3]} det_price={p[4]:.2f})")

        pivot_cols = ['high', 'low', 'close',
                       'high_pivot_sid', 'high_pivot_price',
                       'high_detection_sid', 'high_detection_price',
                       'low_pivot_sid', 'low_pivot_price',
                       'low_detection_sid', 'low_detection_price']
        pivot_na_cols = ['high_pivot_price', 'high_detection_sid',
                         'low_pivot_price', 'low_detection_sid']
        print(df[pivot_cols].dropna(subset=pivot_na_cols, how='all'))


@handle_series.register(SubscriptionMatched)
def _handle_subscription_matched(data: SubscriptionMatched, topic_name: str, *args) -> None:
    print(f"[{topic_name}] subscription matched event")


async def run_dds(
    loop: asyncio.AbstractEventLoop,
    queue: asyncio.Queue,
    shutdown: asyncio.Event,
    series_topics: list[str],
) -> None:
    factory = fastdds.DomainParticipantFactory.get_instance()
    participant = factory.create_participant(0, fastdds.PARTICIPANT_QOS_DEFAULT)
    if participant is None:
        raise RuntimeError("Failed to create DomainParticipant")

    pubsub_type = SeriesPubSubType()
    pubsub_type.set_name('ohlcv_values')
    ts = fastdds.TypeSupport(pubsub_type)
    if participant.register_type(ts) != fastdds.RETCODE_OK:
        raise RuntimeError("Failed to register Series type")

    subscriber = participant.create_subscriber(fastdds.SUBSCRIBER_QOS_DEFAULT)
    if subscriber is None:
        raise RuntimeError("Failed to create subscriber")

    for series_topic in series_topics:
        topic_obj = participant.create_topic(
            series_topic, pubsub_type.get_name(), fastdds.TOPIC_QOS_DEFAULT)
        if topic_obj is None:
            raise RuntimeError(f"Failed to create topic '{series_topic}'")

        reader = subscriber.create_datareader(
            topic_obj, fastdds.DATAREADER_QOS_DEFAULT,
            SeriesListener(series_topic, queue, loop))
        if reader is None:
            raise RuntimeError(f"Failed to create DataReader for '{series_topic}'")

    while not shutdown.is_set():
        try:
            data, topic_name = await asyncio.wait_for(queue.get(), timeout=1.0)
        except asyncio.TimeoutError:
            continue

        handle_series(data, topic_name)

    participant.delete_contained_entities()
    factory.delete_participant(participant)


_CONFIG_FILE = ".inclination-zigzag.conf"


def _load_config(section: str) -> dict:
    paths = [Path.cwd() / _CONFIG_FILE, Path.home() / ".inclination" / "zigzag.conf"]
    for p in paths:
        if p.exists():
            with p.open("rb") as f:
                cfg = tomli.load(f)
            if section not in cfg:
                raise SystemExit(f"Section '{section}' not found in {p}")
            return cfg[section]
    raise SystemExit(f"Config file '{_CONFIG_FILE}' not found in {[str(p) for p in paths]}")


async def main() -> None:
    parser = argparse.ArgumentParser(
        description="Inclination zigzag DDS consumer")
    parser.add_argument("section", nargs="?", default="default",
                        help="TOML config section to use (default: 'default')")
    args = parser.parse_args()

    section = _load_config(args.section)
    exchange = section["exchange"]
    symbol = section["symbol"]
    interval = section["interval"]

    raw = section.get("topics", section.get("topic"))
    if isinstance(raw, str):
        topics = [raw]
    elif isinstance(raw, list):
        topics = raw
    else:
        raise SystemExit("Config must contain 'topics' (list) or 'topic' (str)")
    series_topics = [f"{t}_s" for t in topics]

    global _deviation_pct, _backstep
    _deviation_pct = float(section.get("deviation_pct", 0.0))
    _backstep = int(section.get("backstep", 0))

    loop = asyncio.get_running_loop()
    queue: asyncio.Queue = asyncio.Queue(maxsize=10000)
    shutdown = asyncio.Event()

    def handle_sigint() -> None:
        shutdown.set()

    loop.add_signal_handler(signal.SIGINT, handle_sigint)

    await run_dds(loop, queue, shutdown, series_topics)


def cmd():
    try:
        asyncio.run(main())
    except Exception:
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    cmd()
