import os
import time
import signal
import json
import logging
from functools import partial
from argparse import ArgumentParser
import asyncio
import async_timer
from . import mqtt


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.DEBUG)


class Main:
    def __init__(self):
        pass #self._done = False

    async def on_mqtt_connect(self, client, userdata, flags, rc):
        logger.debug('mqtt connected')
        await self._mqtt.subscribe('inclination/config/loadavg/0/timeout')

    async def on_mqtt_disconnect(self, client, userdata, rc):
        logger.debug('mqtt disconnected')

    async def on_conf_timeout(self, topic, payload, qos, retain):
        logger.debug(f'timeout at {payload}')

    async def mqtt_runner(self, *, mqtt_done, mqtt_host, mqtt_port, mqtt_user, mqtt_passwd):
        def _(client, userdata, msg, handler):
            payload = json.loads(msg.payload) if msg.payload else None
            return handler(msg.topic, payload, msg.qos, msg.retain)

        logger.debug('mqtt started')
        self._mqtt = mqtt.Client()
        self._mqtt.username_pw_set(username=mqtt_user, password=mqtt_passwd)
        self._mqtt.on_connect = self.on_mqtt_connect
        self._mqtt.on_disconnect = self.on_mqtt_disconnect
        self._mqtt.message_callback_add('inclination/config/loadavg/0/timeout', lambda c, u, m: _(c, u, m, self.on_conf_timeout))
        loop = asyncio.get_running_loop()
        self._mqtt.loop = loop
        await self._mqtt.connect(host=mqtt_host, port=mqtt_port)
        await mqtt_done
        await self._mqtt.disconnect()
        logger.debug('mqtt done')

    async def on_timer(self):
        logger.debug('timer started')
        async with self._timer as timer: # async_timer.Timer(2, target=time.time) as timer:
            async for i in timer:
                load1, load5, load15 = os.getloadavg()
                await asyncio.gather(
                        self._mqtt.publish('inclination/loadavg/load1', load1),
                        self._mqtt.publish('inclination/loadavg/load5', load5),
                        self._mqtt.publish('inclination/loadavg/load15', load15))
        logger.debug('timer done')

    async def on_sigint(self):
        logger.debug('sigint')
        self._mqtt_done.set_result(0)
        await self._timer.stop()

    async def __call__(self, *, mqtt_host=None, mqtt_port=None, mqtt_user=None, mqtt_passwd=None):
        loop = asyncio.get_running_loop()
        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(self.on_sigint)()))

        self._mqtt_done = loop.create_future()

        t0 = asyncio.create_task(self.mqtt_runner(mqtt_done=self._mqtt_done, mqtt_host=mqtt_host, mqtt_port=mqtt_port,
                                                  mqtt_user=mqtt_user, mqtt_passwd=mqtt_passwd))

        self._timer = async_timer.Timer(10, target=time.time)
        t1 = asyncio.create_task(self.on_timer())

        await asyncio.gather(t0, t1)


def main():
    parser = ArgumentParser()
    parser.add_argument('-H', '--mqtt-host', default=os.environ.get('MQTT_HOST', 'localhost'))
    parser.add_argument('-p', '--mqtt-port', type=int, default=os.environ.get('MQTT_PORT', 1883))
    parser.add_argument('-u', '--mqtt-user', default=os.environ.get('MQTT_USER', None))
    parser.add_argument('-P', '--mqtt-passwd', default=os.environ.get('MQTT_PASSWD', None))
    args = parser.parse_args()

    x = Main()
    asyncio.run(x(**vars(args)))

if __name__ == '__main__':
    main()

