import os
import time
import signal
import json
from functools import partial
import asyncio
import async_timer
import .mqtt


class Main:
    def __init__(self):
        pass #self._done = False

    async def on_mqtt_connect(self, client, userdata, flags, rc):
        print('MQTT connect')
        await self._mqtt.subscribe('inclination/config/loadavg/0/timeout')

    async def on_mqtt_disconnect(self, client, userdata, rc):
        print('MQTT disconnect')

    async def on_conf_length(self, topic, payload, qos, retain):
        print(payload)

    async def mqtt_runner(self, mqtt_done, mqtt_host='localhost'):
        def _(client, userdata, msg, handler):
            payload = json.loads(msg.payload) if msg.payload else None
            return handler(msg.topic, payload, msg.qos, msg.retain)

        print('chek!')
        self._mqtt = mqtt.Client()
        self._mqtt.on_connect = self.on_mqtt_connect
        self._mqtt.on_disconnect = self.on_mqtt_disconnect
        self._mqtt.message_callback_add('inclination/config/loadavg/0/timeout', lambda c, u, m: _(c, u, m, self.on_conf_length))
        loop = asyncio.get_running_loop()
        self._mqtt.loop = loop
        await self._mqtt.connect(mqtt_host)
        await mqtt_done
        await self._mqtt.disconnect()
        print('MQTT done.')

    async def on_timer(self):
        async with self._timer as timer: # async_timer.Timer(2, target=time.time) as timer:
            async for i in timer:
                load1, load5, load15 = os.getloadavg()
                await asyncio.gather(
                        self._mqtt.publish('inclination/loadavg/load1', load1),
                        self._mqtt.publish('inclination/loadavg/load5', load5),
                        self._mqtt.publish('inclination/loadavg/load15', load15))
        print('Timer done.')

    async def on_sigint(self):
        print('SIGINT')
        self._mqtt_done.set_result(0)
        await self._timer.stop()

    async def __call__(self):
        loop = asyncio.get_running_loop()
        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(self.on_sigint)()))

        self._mqtt_done = loop.create_future()

        t0 = asyncio.create_task(self.mqtt_runner(self._mqtt_done))

        self._timer = async_timer.Timer(10, target=time.time)
        t1 = asyncio.create_task(self.on_timer())

        await asyncio.gather(t0, t1)


def main():
    x = Main()
    asyncio.run(x())

if __name__ == '__main__':
    main()

