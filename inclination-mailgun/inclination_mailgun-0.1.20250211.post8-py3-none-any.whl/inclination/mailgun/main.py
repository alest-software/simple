from itertools import takewhile
from functools import partial
import os
import re
import signal
import json
from attrs import define
from argparse import ArgumentParser
import asyncio
import aiohttp
from aiohttp import web
from . import mqtt
from pprint import pprint
import logging


logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)-23s - %(levelname).1s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)


routes = web.RouteTableDef()


@routes.view('/')
class HealthCheck(web.View):
    async def options(self):
        #logger.debug('Health-check OPTIONS/...')
        return web.Response()


@routes.view('/mailgun/{message}')
class MailgunNotify(web.View):
    async def get(self):
        headers = {'Content-Type': 'text/html'}
        #text = '<html><body><form method="post" action="mailgun"><textarea name="body-plain">{\r\n"answer":42,\r\n"some":3\r\n}\r\n\r\n--\r\nMore text</textarea><input type="submit" value="Go" /></form></body></html>'
        text = '200 OK'
        return web.Response(text=text, headers=headers)

    async def post(self):
        request = self.request
        message = request.match_info['message']

        print(f'POST /mailgun/{message}')
        for k, v in request.headers.items():
            print(f'{k:>20s}: {v}')

        try:
            data = await request.post()
            print(f'MAIL FROM: {data["sender"]}')
            print(f'RCPT TO: {data["recipient"]}')
            for k, v in data.items():
                if k not in ['sender', 'recipient', 'message-headers']:
                    print(f'{k:>20s}: {v}')

            #print(message)
            #pprint({k: v for k, v in data.items()})
            print(f'Received message "{message}", From: "{data["From"]}", from: "{data["from"]}", sender: "{data["sender"]}", recipient: "{data["recipient"]}", Date: "{data["Date"]}", timestamp: {data["timestamp"]}, Subject: "{data["Subject"]}", subject: "{data["subject"]}"')
            logger.debug(f'{"From":20s}: {data["From"]}')
            if 'stripped-text' not in data:
                logger.debug('No stripped-text')
            else:
                body = data['stripped-text']
                logger.debug(body)
                cmd = json.loads(body)
                #print(cmd)
                async with aiohttp.ClientSession() as session:
                    async with session.post(f'http://localhost:8888/tradingview/{message}', data=body) as resp: #json=cmd) as resp:
                        #print(resp.status)
                        data = await resp.json()
                        #print(data)
                await request.app.main.on_post_maingun_notify(cmd, message)
        except Exception as e:
            print(f'{type(e)}: {e}')
        finally:
            return web.Response(status=201)


@routes.view('/tradingview/{alert}')
class TradingviewNotify(web.View):
    async def get(self):
        #headers = {'Content-Type': 'text/html'}
        #text = '<html><body><form method="post" action="mailgun"><textarea name="body-plain">{\r\n"answer":42,\r\n"some":3\r\n}\r\n\r\n--\r\nMore text</textarea><input type="submit" value="Go" /></form></body></html>'
        text = '200 OK'
        return web.Response(text=text) #, headers=headers)

    async def post(self):
        request = self.request
        alert = request.match_info['alert']

        print(f'POST /tradingview/{alert}')
        for k, v in request.headers.items():
            print(f'{k:>20s}: {v}')

        logger.debug(f'Tradingview "{alert}" alert')
        logger.debug(f'{request.content_type}')

        data = await request.json()
        logger.debug(data)
        await request.app.main.on_post_tradingview_notify(data, alert)
        return web.json_response({}, status=201)


@define
class Main:
    mqtt: int = None

    async def on_post_maingun_notify(self, data, message):
        await self.mqtt.publish(f'inclination/mailgun/{message}', json.dumps(data))

    async def on_post_tradingview_notify(self, data, message):
        await self.mqtt.publish(f'inclination/tradingview/{message}', json.dumps(data))

    async def on_startup(self, app):
        logger.debug('Startup')

    async def on_cleanup(self, app):
        logger.debug('Cleanup')

    async def on_conf_interval(self, payload, *, name):
        logger.debug(payload)
        logger.debug(name)

    async def on_connect(self, client, userdata, flags, rc):
        logger.debug('Connect')
        await self.mqtt.subscribe('inclination/config/mailgun/0/#')
        await self.mqtt.publish(f'inclination/telegram/message', '"Mailgun process restarted"')

    async def on_disconnect(self, client, userdata, rc):
        logger.debug(f'Disconnect {rc}')

    async def on_sigint(self, done):
        print('SIGINT')
        done.set_result(0)

    async def __call__(self, *, mqtt_host, mqtt_port, mqtt_user, mqtt_passwd):
        loop = asyncio.get_event_loop()
        done = loop.create_future()
        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(self.on_sigint)(done)))

        async def run_app():
            app = web.Application()
            app.on_startup.append(self.on_startup)
            app.on_cleanup.append(self.on_cleanup)
            app.add_routes(routes)
            app.main = self

            runner = web.AppRunner(app)
            await runner.setup()
            site = web.TCPSite(runner, '0.0.0.0', 8888)
            await site.start()

            await done

            await runner.cleanup()

        async def run_mqtt():
            class _:
                def __init__(self, handler, regex=None, do_qos=False, do_retain=False):
                    self._handler = handler
                    self._regex = re.compile(regex) if regex else None
                    self._do_qos = do_qos
                    self._do_retain = do_retain
                async def __call__(self, client, userdata, msg):
                    params = {}
                    if self._do_qos:
                        params['qos'] = msg.qos
                    if self._do_retain:
                        params['retain'] = msg.retain
                    instance = self._regex.match(msg.topic).groupdict() if self._regex else {'topic': msg.topic}
                    payload = json.loads(msg.payload) if msg.payload else None
                    await self._handler(payload, **params, **instance)

            self.mqtt = mqtt.Client()
            self.mqtt.username_pw_set(username=mqtt_user, password=mqtt_passwd)
            self.mqtt.on_connect = self.on_connect
            self.mqtt.on_disconnect = self.on_disconnect

            self.mqtt.message_callback_add(
                    'inclination/config/mailgun/0/+/interval',
                    _(self.on_conf_interval, r'inclination/config/mailgun/0/(?P<name>[^/]+)/interval'))

            loop = asyncio.get_running_loop()
            self.mqtt.loop = loop

            await self.mqtt.connect(host=mqtt_host, port=mqtt_port)

            await done

            await self.mqtt.disconnect()

        await asyncio.gather(
                run_app(),
                run_mqtt()
                )

        print('Done.')


def main():
    parser = ArgumentParser()
    parser.add_argument('-H', '--mqtt-host', default=os.environ.get('MQTT_HOST', 'localhost'))
    parser.add_argument('-p', '--mqtt-port', type=int, default=os.environ.get('MQTT_PORT', 1883))
    parser.add_argument('-u', '--mqtt-user', default=os.environ.get('MQTT_USER', None))
    parser.add_argument('-P', '--mqtt-passwd', default=os.environ.get('MQTT_PASSWD', None))
    args = parser.parse_args()

    x = Main()
    asyncio.run(x(**vars(args)))

