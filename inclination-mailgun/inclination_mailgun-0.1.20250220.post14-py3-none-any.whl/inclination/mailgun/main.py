from itertools import takewhile
from functools import partial
import os
import re
import signal
import json
from datetime import datetime, timezone
from attrs import define, field, asdict
from attrs.validators import instance_of
from typing import Optional
from argparse import ArgumentParser
import asyncio
import aiohttp
from aiohttp import web
from . import mqtt
from pprint import pprint
import logging
from functools import singledispatchmethod


logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)-23s - %(levelname).1s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)


def split_condition(s, f=lambda x: not str.isnumeric(x)):
    try:
        z = next(i for i, c in enumerate(s) if f(c))
        return s[:z], s[z:]
    except StopIteration:
        return s, ''


def tv_timeframe(s):
    units = {'S': 1, '': 60, 'D': 24*60*60, 'W': 7*24*60*60}
    m, u = split_condition(s)
    if u in units:
        m = int(m) if m else 1
        return m * units[u]
    return None


routes = web.RouteTableDef()


@routes.view('/')
class HealthCheck(web.View):
    async def options(self):
        #logger.debug('Health-check OPTIONS/...')
        return web.Response()


@routes.view('/mailgun/{message}')
class MailgunNotify(web.View):
    async def get(self):
        headers = {'Content-Type': 'text/html'}
        #text = '<html><body><form method="post" action="mailgun"><textarea name="body-plain">{\r\n"answer":42,\r\n"some":3\r\n}\r\n\r\n--\r\nMore text</textarea><input type="submit" value="Go" /></form></body></html>'
        text = '200 OK'
        return web.Response(text=text, headers=headers)

    async def post(self):
        request = self.request
        message = request.match_info['message']

        #print(f'POST /mailgun/{message}')
        #for k, v in request.headers.items():
        #    print(f'{k:>20s}: {v}')

        try:
            data = await request.post()

            print('========================================')
            print(f'MAIL FROM: {data["sender"]}')
            print(f'RCPT TO: {data["recipient"]}')
            for k, v in data.items():
                if k not in ['sender', 'recipient', 'message-headers']:
                    print(f'{k:>20s}: {v}')
            print('========================================')

            #print(message)
            #pprint({k: v for k, v in data.items()})
            #print(f'Received message "{message}", From: "{data["From"]}", from: "{data["from"]}", sender: "{data["sender"]}", recipient: "{data["recipient"]}", Date: "{data["Date"]}", timestamp: {data["timestamp"]}, Subject: "{data["Subject"]}", subject: "{data["subject"]}"')
            #logger.debug(f'{"From":20s}: {data["From"]}')
            if 'stripped-text' not in data:
                logger.debug('No stripped-text')
            else:
                stripped_text = data['stripped-text']
                logger.debug(stripped_text)
                async with aiohttp.ClientSession() as session:
                    async with session.post(f'http://localhost:8888/tradingview/{message}', data=stripped_text) as resp: #json=cmd) as resp:
                        logger.debug(f'status = {resp.status}')
                        #data = await resp.json()
                        #print(data)
                await request.app.main.on_post_maingun_notify(stripped_text, message)
        except Exception as e:
            print(f'{type(e)}: {e}')
        finally:
            return web.Response(status=201)


time_converter = lambda x: float(x) / 1000.0
float_converter = lambda x: float(x) if x else None

@define
class TradingViewAlert:
    tickerid:          str   = field(validator=instance_of(str))
    period:            str   = field(validator=instance_of(str))
    time:              float = field(default=None, converter=time_converter)
    ht_trend:          float = field(default=None) #, converter=float_converter)
    ht_high_structure: float = field(default=None) #, converter=float_converter)
    ht_low_structure:  float = field(default=None) #, converter=float_converter)
    ht_bull_bos:       float = field(default=None) #, converter=float_converter)
    ht_bull_choch:     float = field(default=None) #, converter=float_converter)
    ht_bear_bos:       float = field(default=None) #, converter=float_converter)
    ht_bear_choch:     float = field(default=None) #, converter=float_converter)
    ht_direction:      float = field(default=None) #, converter=float_converter)
    ht_bottom_val:     float = field(default=None) #, converter=float_converter)
    ht_top_val:        float = field(default=None) #, converter=float_converter)
    pct:               Optional[float] = field(default=None) #, converter=float_converter) #validator=instance_of(Optional[float]))

class HtNewHighTradingViewAlert(TradingViewAlert): pass
class HtNewLowTradingViewAlert(TradingViewAlert): pass
class HtBullBosTradingViewAlert(TradingViewAlert): pass
class HtBullChochTradingViewAlert(TradingViewAlert): pass
class HtBearBosTradingViewAlert(TradingViewAlert): pass
class HtBearChochTradingViewAlert(TradingViewAlert): pass


get_content = '''<!DOCTYPE html>
<html>
  <body>
    <form method="post">
      <table>
        <tr>
          <th><label for="_type">Type:</label></th>
          <!--td><input type="text" id="_type" name="type" value="ht_new_high" /></td-->
          <td>
            <select id="_type" name="type">
              <option value="ht_new_high">ht_new_high</option>
              <option value="ht_new_low">ht_new_low</option>
              <option value="ht_bull_bos">ht_bull_bos</option>
              <option value="ht_bull_choch">ht_bull_choch</option>
              <option value="ht_bear_bos">ht_bear_bos</option>
              <option value="ht_bear_choch">ht_bear_choch</option>
            </select>
          </td>
        </tr>
        <tr>
          <th><label for="_tickerid">Tickerid:</label></th>
          <td><input type="text" id="_tickerid" name="tickerid" value="OKX:BTCUSD" /></td>
        </tr>
        <tr>
          <th><label for="_period">Period:</label></th>
          <td><input type="text" id="_period" name="period" value="60S" /></td>
        </tr>
        <tr>
          <th><label for="_time">Time:</label></th>
          <td><input type="text" id="_time" name="time" value="1700000000000" /></td>
        </tr>
        <tr>
          <th><label for="_ht_trend">HT Trend:</label></th>
          <td><input type="text" id="_ht_trend" name="ht_trend" value="1" /></td>
        </tr>
        <tr>
          <th><label for="_ht_high_structure">HT High Structure:</label></th>
          <td><input type="text" id="_ht_high_structure" name="ht_high_structure" value="0.0" /></td>
        </tr>
        <tr>
          <th><label for="_ht_low_structure">HT Low Structure:</label></th>
          <td><input type="text" id="_ht_low_structure" name="ht_low_structure" value="0.0" /></td>
        </tr>
        <tr>
          <th><label for="_ht_bull_bos">HT Bull BOS:</label></th>
          <td><input type="text" id="_ht_bull_bos" name="ht_bull_bos" value="0.0" /></td>
        </tr>
        <tr>
          <th><label for="_ht_bull_choch">HT Bull CHoCH:</label></th>
          <td><input type="text" id="_ht_bull_choch" name="ht_bull_choch" value="0.0" /></td>
        </tr>
        <tr>
          <th><label for="_ht_bear_bos">HT Bear BOS:</label></th>
          <td><input type="text" id="_ht_bear_bos" name="ht_bear_bos" value="0.0" /></td>
        </tr>
        <tr>
          <th><label for="_ht_bear_choch">HT Bear CHoCH:</label></th>
          <td><input type="text" id="_ht_bear_choch" name="ht_bear_choch" value="0.0" /></td>
        </tr>
        <tr>
          <th><label for="_ht_direction">HT Direction:</label></th>
          <td><input type="text" id="_ht_direction" name="ht_direction" value="0.0" /></td>
        </tr>
        <tr>
          <th><label for="_ht_bottom_val">HT Bottom Val:</label></th>
          <td><input type="text" id="_ht_bottom_val" name="ht_bottom_val" value="0.0" /></td>
        </tr>
        <tr>
          <th><label for="_ht_top_val">HT Top Val:</label></th>
          <td><input type="text" id="_ht_top_val" name="ht_top_val" value="0.0" /></td>
        </tr>
        <tr>
          <th><label for="_pct">Pct:</label></th>
          <td><input type="text" id="_pct" name="pct" value="0.0" /></td>
        </tr>
      </table>
      <input type="submit" value="Go" />
    </form>
  </body>
</html>
'''


@routes.view('/tradingview/{alert}')
class TradingviewNotify(web.View):
    async def get(self):
        headers = {'Content-Type': 'text/html'}
        #text = '<html><body><form method="post" action="mailgun"><textarea name="body-plain">{\r\n"answer":42,\r\n"some":3\r\n}\r\n\r\n--\r\nMore text</textarea><input type="submit" value="Go" /></form></body></html>'
        text = '200 OK'
        return web.Response(text=get_content, headers=headers)

    async def post(self):
        request = self.request
        alert = request.match_info['alert']

        logger.debug('========================================')
        logger.debug(f'POST /tradingview/{alert}')
        for k, v in request.headers.items():
            logger.debug(f'{k:>26s}: {v}')
        logger.debug('========================================')

        logger.debug(f'Tradingview "{alert}" alert')
        logger.debug(f'{request.content_type}')
        is_test_page = (request.content_type == 'application/x-www-form-urlencoded')

        try:
            data = dict(await (request.post() if is_test_page else request.json()))
            #data = await request.json()
            logger.debug(data)
            if type(data) != dict:
                print('Data not dict')
            else:
                if 'type' not in data:
                    print('No type in data')
                else:
                    switcher = {
                        'ht_new_high':    HtNewHighTradingViewAlert,
                        'ht_new_low':     HtNewLowTradingViewAlert,
                        'ht_bull_bos':    HtBullBosTradingViewAlert,
                        'ht_bull_choch':  HtBullChochTradingViewAlert,
                        'ht_bear_bos':    HtBearBosTradingViewAlert,
                        'ht_bear_choch':  HtBearChochTradingViewAlert,
                    }
                    Class = switcher.get(data['type'], TradingViewAlert)
                    if Class is None:
                        print('No class for message type')
                    else:
                        del data['type']
                        msg = Class(**data)

                        await request.app.main.on_post_tradingview_alert(msg, alert)

            await request.app.main.on_post_tradingview_notify(data, alert)
        except Exception as e:
            logger.error(e)

        #return web.json_response({}, status=201)
        if is_test_page:
            #location = request.app.router['/tradingview/{alert}'].url_for()
            location = f'/tradingview/{alert}'
            raise web.HTTPFound(location=location)
        else:
            return web.Response(status=201)


@define
class Main:
    mqtt: int = None

    async def on_post_maingun_notify(self, data, message):
        await self.mqtt.publish(f'inclination/mailgun/{message}', json.dumps(data))

    async def on_post_tradingview_notify(self, data, message):
        await self.mqtt.publish(f'inclination/tradingview/{message}', json.dumps(data))

    @singledispatchmethod
    async def on_post_tradingview_alert(self, alert, alert_type):
        print(alert)
        #await self.mqtt.publish(f'inclination/telegram/nope', json.dumps(asdict(alert)))

    @on_post_tradingview_alert.register
    async def on_post_tradingview_alert(self, alert: TradingViewAlert, alert_type):
        #print(datetime.utcfromtimestamp(msg.time))
        #print(datetime.fromtimestamp(msg.time, tz=timezone.utc))
        #print(datetime.fromtimestamp(msg.time))
        rval = []
        rval.extend([f'{alert.tickerid:s} {alert.period:s}'])
        rval.extend([f'{datetime.utcfromtimestamp(alert.time)} ({alert.time:.3f})'])
        rval.extend([f'         Trend: {alert.ht_trend}']          if alert.ht_trend else [])
        rval.extend([f'High structure: {alert.ht_high_structure}'] if alert.ht_high_structure else [])
        rval.extend([f' Low structure: {alert.ht_low_structure}']  if alert.ht_low_structure else [])
        rval.extend([f'      Bull BOS: {alert.ht_bull_bos}']       if alert.ht_bull_bos else [])
        rval.extend([f'    Bull CHoCH: {alert.ht_bull_choch}']     if alert.ht_bull_choch else [])
        rval.extend([f'      Bear BOS: {alert.ht_bear_bos}']       if alert.ht_bear_bos else [])
        rval.extend([f'    Bear CHoCH: {alert.ht_bear_choch}']     if alert.ht_bear_choch else [])
        rval.extend([f'     Direction: {alert.ht_direction}']      if alert.ht_direction else [])
        rval.extend([f'        Bottom: {alert.ht_bottom_val}']     if alert.ht_bottom_val else [])
        rval.extend([f'           Top: {alert.ht_top_val}']        if alert.ht_top_val else [])
        rval.extend([f'           Pct: {alert.pct}']               if alert.pct else [])
        print('\n'.join(rval))
        print(f'timeframe = {tv_timeframe(alert.period)} [s]')
        await self.mqtt.publish(f'inclination/telegram/message', json.dumps('\n'.join(rval))) #asdict(alert)))

    async def on_startup(self, app):
        logger.debug('Startup')

    async def on_cleanup(self, app):
        logger.debug('Cleanup')

    async def on_conf_interval(self, payload, *, name):
        logger.debug(payload)
        logger.debug(name)

    async def on_connect(self, client, userdata, flags, rc):
        logger.debug('Connect')
        await self.mqtt.subscribe('inclination/config/mailgun/0/#')
        await self.mqtt.publish(f'inclination/telegram/message', '"Mailgun process restarted"')

    async def on_disconnect(self, client, userdata, rc):
        logger.debug(f'Disconnect {rc}')

    async def on_sigint(self, done):
        print('SIGINT')
        done.set_result(0)

    async def __call__(self, *, mqtt_host, mqtt_port, mqtt_user, mqtt_passwd):
        loop = asyncio.get_event_loop()
        done = loop.create_future()
        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(self.on_sigint)(done)))

        async def run_app():
            app = web.Application()
            app.on_startup.append(self.on_startup)
            app.on_cleanup.append(self.on_cleanup)
            app.add_routes(routes)
            app.main = self

            runner = web.AppRunner(app)
            await runner.setup()
            site = web.TCPSite(runner, '0.0.0.0', 8888)
            await site.start()

            await done

            await runner.cleanup()

        async def run_mqtt():
            class _:
                def __init__(self, handler, regex=None, do_qos=False, do_retain=False):
                    self._handler = handler
                    self._regex = re.compile(regex) if regex else None
                    self._do_qos = do_qos
                    self._do_retain = do_retain
                async def __call__(self, client, userdata, msg):
                    params = {}
                    if self._do_qos:
                        params['qos'] = msg.qos
                    if self._do_retain:
                        params['retain'] = msg.retain
                    instance = self._regex.match(msg.topic).groupdict() if self._regex else {'topic': msg.topic}
                    payload = json.loads(msg.payload) if msg.payload else None
                    await self._handler(payload, **params, **instance)

            self.mqtt = mqtt.Client()
            self.mqtt.username_pw_set(username=mqtt_user, password=mqtt_passwd)
            self.mqtt.on_connect = self.on_connect
            self.mqtt.on_disconnect = self.on_disconnect

            self.mqtt.message_callback_add(
                    'inclination/config/mailgun/0/+/interval',
                    _(self.on_conf_interval, r'inclination/config/mailgun/0/(?P<name>[^/]+)/interval'))

            loop = asyncio.get_running_loop()
            self.mqtt.loop = loop

            await self.mqtt.connect(host=mqtt_host, port=mqtt_port)

            await done

            await self.mqtt.disconnect()

        await asyncio.gather(
                run_app(),
                run_mqtt()
                )

        print('Done.')


def main():
    parser = ArgumentParser()
    parser.add_argument('-H', '--mqtt-host', default=os.environ.get('MQTT_HOST', 'localhost'))
    parser.add_argument('-p', '--mqtt-port', type=int, default=os.environ.get('MQTT_PORT', 1883))
    parser.add_argument('-u', '--mqtt-user', default=os.environ.get('MQTT_USER', None))
    parser.add_argument('-P', '--mqtt-passwd', default=os.environ.get('MQTT_PASSWD', None))
    args = parser.parse_args()

    x = Main()
    asyncio.run(x(**vars(args)))

