from aiohttp import web

routes = web.RouteTableDef()

@routes.get('/notify/mailgun')
async def get_mailgun_notification(request):
    print(request)
    return web.Response(text='Gelukt')

@routes.post('/notify/mailgun')
async def post_mailgun_notification(request):
    try:
        data = await request.post()
        body = data['body-plain']
        a = body.split('\r\n')
        print(a)
    except Exception as e:
        print(e)
    return web.Response()

app = web.Application()
app.add_routes(routes)
web.run_app(app, port=8888)

