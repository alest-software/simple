from itertools import takewhile
from functools import partial
import signal
import json
import asyncio
from aiohttp import web


routes = web.RouteTableDef()


@routes.view('/notify/mailgun')
class MailgunNotify(web.View):
    async def get(self):
        headers = {'Content-Type': 'text/html'}
        text = '<html><body><form method="post" action="mailgun"><textarea name="body-plain">{\r\n"answer":42,\r\n"some":3\r\n}\r\n\r\n--\r\nMore text</textarea><input type="submit" value="Go" /></form></body></html>'
        return web.Response(text=text, headers=headers)

    async def post(self):
        try:
            data = await self.request.post()
            if 'body-plain' in data:
                body = data['body-plain']
                part = ''.join(takewhile(lambda x: x != '--', body.split('\r\n')))
                cmd = json.loads(part)
                await self.request.app.main.on_post_maingun_notify(cmd)
        except Exception as e:
            print(e)
        return web.Response(text='Hopla')


class Main:
    async def on_post_maingun_notify(self, data):
        print(data)

    async def on_startup(self, app):
        print('Startup')

    async def on_cleanup(self, app):
        print('Cleanup')

    async def on_sigint(self, done):
        print('SIGINT')
        done.set_result(0)

    async def __call__(self):
        loop = asyncio.get_event_loop()
        done = loop.create_future()
        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(self.on_sigint)(done)))

        app = web.Application()
        app.on_startup.append(self.on_startup)
        app.on_cleanup.append(self.on_cleanup)
        app.add_routes(routes)
        app.main = self

        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, '0.0.0.0', 8888)
        await site.start()

        await done

        await runner.cleanup()


main = lambda: asyncio.run(Main()())

