from itertools import takewhile
from functools import partial
import os
import re
import signal
import json
import math
from datetime import datetime, timezone
from attrs import define, field, asdict
from attrs.validators import instance_of
from typing import Optional
from argparse import ArgumentParser
import asyncio
import aiohttp
from aiohttp import web
from . import mqtt
from pprint import pprint
import logging
from functools import singledispatchmethod


logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)-23s - %(levelname).1s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)


def split_condition(s, f=lambda x: not str.isnumeric(x)):
    try:
        z = next(i for i, c in enumerate(s) if f(c))
        return s[:z], s[z:]
    except StopIteration:
        return s, ''


def tv_timeframe(s):
    units = {'S': 1, '': 60, 'D': 24*60*60, 'W': 7*24*60*60}
    m, u = split_condition(s)
    if u in units:
        m = int(m) if m else 1
        return m * units[u]
    return None


def to_timeframe(n):
    w, n = divmod(n, 7*24*60*60)
    d, n = divmod(n, 24*60*60)
    h, n = divmod(n, 60*60)
    m, n = divmod(n, 60)
    s, n = divmod(n, 1)
    rval = []
    rval.extend([f'{w}w'] if w else [])
    rval.extend([f'{d}d'] if d else [])
    rval.extend([f'{h}h'] if h else [])
    rval.extend([f'{m}m'] if m else [])
    rval.extend([f'{s}s'] if s else [])
    return ''.join(rval)


routes = web.RouteTableDef()


@routes.view('/')
class HealthCheckEndPoint(web.View):
    async def options(self):
        #logger.debug('Health-check OPTIONS/...')
        return web.Response()


@routes.view('/mailgun/{message}')
class MailgunForwardEndPoint(web.View):
    async def post(self):
        request = self.request
        message = request.match_info['message']

        try:
            data = await request.post()

            logger.debug('========================================')
            logger.debug(f'MAIL FROM: {data["sender"]}')
            logger.debug(f'RCPT TO: {data["recipient"]}')
            for k, v in data.items():
                if k not in ['sender', 'recipient', 'message-headers']:
                    logger.debug(f'{k:>20s}: {v}')
            logger.debug('========================================')

            if 'stripped-text' not in data:
                logger.error('No stripped-text')
            else:
                stripped_text = data['stripped-text']
                logger.debug(stripped_text)

                async with aiohttp.ClientSession() as session:
                    async with session.post(f'http://localhost:8888/tradingview/{message}', data=stripped_text) as resp:
                        if resp.status != 201:
                            logger.error(f'status = {resp.status}')
                        else:
                            logger.debug(f'status = {resp.status}')

        except Exception as e:
            logger.error(f'{type(e)}: {e}')
        finally:
            return web.Response(status=201)


time_converter = lambda x: float(x) / 1000.0
int_converter = lambda x: None if (x is None) or ((type(x) is int) and (math.isnan(x))) or ((type(x) is str) and (len(x) == 0)) else int(x)
float_converter = lambda x: None if (x is None) or ((type(x) is float) and (math.isnan(x))) or ((type(x) is str) and (len(x) == 0)) else float(x)


@define
class TradingViewAlert:
    tickerid:          str   = field(validator=instance_of(str))
    period:            str   = field(validator=instance_of(str))
    time:              float = field(default=None, converter=time_converter)
    ht_trend:          float = field(default=None, converter=int_converter)
    ht_high_structure: float = field(default=None, converter=float_converter)
    ht_low_structure:  float = field(default=None, converter=float_converter)
    ht_bull_bos:       float = field(default=None, converter=float_converter)
    ht_bull_choch:     float = field(default=None, converter=float_converter)
    ht_bear_bos:       float = field(default=None, converter=float_converter)
    ht_bear_choch:     float = field(default=None, converter=float_converter)
    ht_direction:      float = field(default=None, converter=int_converter)
    ht_bottom_val:     float = field(default=None, converter=float_converter)
    ht_top_val:        float = field(default=None, converter=float_converter)
    ht_percentage:     Optional[float] = field(default=None, converter=float_converter) #validator=instance_of(Optional[float]))
    ht_margin:         Optional[float] = field(default=None, converter=float_converter) #validator=instance_of(Optional[float]))
    lt_percentage:     Optional[float] = field(default=None, converter=float_converter) #validator=instance_of(Optional[float]))
    lt_margin:         Optional[float] = field(default=None, converter=float_converter) #validator=instance_of(Optional[float]))


class HtNewHighTradingViewAlert(TradingViewAlert): pass
class HtNewLowTradingViewAlert(TradingViewAlert): pass
class HtBullBosTradingViewAlert(TradingViewAlert): pass
class HtBullChochTradingViewAlert(TradingViewAlert): pass
class HtBearBosTradingViewAlert(TradingViewAlert): pass
class HtBearChochTradingViewAlert(TradingViewAlert): pass


get_content = '''<!DOCTYPE html>
<html>
  <body>
    <form method="post">
      <table>
        <tr>
          <th align="right"><label for="_type">Type:</label></th>
          <!--td><input type="text" id="_type" name="type" value="ht_new_high" /></td-->
          <td>
            <select id="_type" name="type">
              <option value="ht_new_high">HT New High</option>
              <option value="ht_new_low">HT New Low</option>
              <option value="ht_bull_bos">HT Bull BoS</option>
              <option value="ht_bull_choch">HT Bull CHoCH</option>
              <option value="ht_bear_bos">HT Bear BoS</option>
              <option value="ht_bear_choch">HT Bear CHoCH</option>
            </select>
          </td>
        </tr>
        <tr>
          <th align="right"><label for="_tickerid">Tickerid:</label></th>
          <!--td><input type="text" id="_tickerid" name="tickerid" value="OKX:BTCUSD" /></td-->
          <td>
            <select id="_tickerid" name="tickerid">
              <option value="OKX:BTCUSD">OKX:BTCUSD</option>
              <option value="OKX:SOLUSD">OKX:SOLUSD</option>
            </select>
          </td>
        </tr>
        <tr>
          <th align="right"><label for="_period">Period:</label></th>
          <td><input type="text" id="_period" name="period" value="60S" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_time">Time:</label></th>
          <td><input type="text" id="_time" name="time" value="1735689600000" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_ht_trend">HT Trend:</label></th>
          <td><input type="text" id="_ht_trend" name="ht_trend" value="1" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_ht_high_structure">HT High Structure:</label></th>
          <td><input type="text" id="_ht_high_structure" name="ht_high_structure" value="0.0" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_ht_low_structure">HT Low Structure:</label></th>
          <td><input type="text" id="_ht_low_structure" name="ht_low_structure" value="0.0" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_ht_bull_bos">HT Bull BOS:</label></th>
          <td><input type="text" id="_ht_bull_bos" name="ht_bull_bos" value="0.0" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_ht_bull_choch">HT Bull CHoCH:</label></th>
          <td><input type="text" id="_ht_bull_choch" name="ht_bull_choch" value="0.0" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_ht_bear_bos">HT Bear BOS:</label></th>
          <td><input type="text" id="_ht_bear_bos" name="ht_bear_bos" value="0.0" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_ht_bear_choch">HT Bear CHoCH:</label></th>
          <td><input type="text" id="_ht_bear_choch" name="ht_bear_choch" value="0.0" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_ht_direction">HT Direction:</label></th>
          <td><input type="text" id="_ht_direction" name="ht_direction" value="1" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_ht_bottom_val">HT Bottom Val:</label></th>
          <td><input type="text" id="_ht_bottom_val" name="ht_bottom_val" value="0.0" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_ht_top_val">HT Top Val:</label></th>
          <td><input type="text" id="_ht_top_val" name="ht_top_val" value="0.0" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_ht_percentage">HT Percentage:</label></th>
          <td><input type="text" id="_ht_percentage" name="ht_percentage" value="1.6" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_ht_margin">HT Margin:</label></th>
          <td><input type="text" id="_ht_margin" name="ht_margin" value="0.1" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_lt_percentage">LT Percentage:</label></th>
          <td><input type="text" id="_lt_percentage" name="lt_percentage" value="0.16" /></td>
        </tr>
        <tr>
          <th align="right"><label for="_lt_margin">LT Margin:</label></th>
          <td><input type="text" id="_lt_margin" name="lt_margin" value="0.01" /></td>
        </tr>
      </table>
      <input type="submit" value="Go" />
    </form>
  </body>
</html>
'''


@routes.view('/tradingview/{alert}')
class TradingViewAlertEndPoint(web.View):
    async def get(self):
        headers = {'Content-Type': 'text/html'}
        return web.Response(text=get_content, headers=headers)

    async def post(self):
        request = self.request
        alert = request.match_info['alert']

        logger.debug('========================================')
        logger.debug(f'POST /tradingview/{alert}')
        for k, v in request.headers.items():
            logger.debug(f'{k:>26s}: {v}')
        logger.debug('========================================')

        try:
            is_test_page = (request.content_type == 'application/x-www-form-urlencoded')
            data = dict(await (request.post() if is_test_page else request.json()))
            logger.debug(data)

            if type(data) != dict:
                logger.error('Data not dict')
            else:
                if 'type' not in data:
                    logger.error('No type in data')
                else:
                    switcher = {
                        'ht_new_high':    TradingViewAlert, #HtNewHighTradingViewAlert,
                        'ht_new_low':     TradingViewAlert, #HtNewLowTradingViewAlert,
                        'ht_bull_bos':    TradingViewAlert, #HtBullBosTradingViewAlert,
                        'ht_bull_choch':  TradingViewAlert, #HtBullChochTradingViewAlert,
                        'ht_bear_bos':    TradingViewAlert, #HtBearBosTradingViewAlert,
                        'ht_bear_choch':  TradingViewAlert, #HtBearChochTradingViewAlert,
                    }
                    Class = switcher.get(data['type'], TradingViewAlert)
                    del data['type']
                    msg = Class(**data)
                    await request.app.main.on_tradingview_alert(msg, alert)

        except Exception as e:
            logger.error(e)

        if is_test_page:
            location = f'/tradingview/{alert}'
            raise web.HTTPFound(location=location)
        else:
            return web.Response(status=201)


@define
class Main:
    mqtt: int = None
    tickerids: dict = field(factory=dict)

    @singledispatchmethod
    async def on_tradingview_alert(self, alert, alert_type):
        raise Exception(f'on_tradingview_alert({alert}, {alert_type})')

    @on_tradingview_alert.register
    async def _(self, alert: HtNewHighTradingViewAlert, alert_type):
        #print('HtNewHighTradingViewAlert')
        return await self.on_tradingview_alert(TradingViewAlert(**asdict(alert)), alert_type)

    @on_tradingview_alert.register
    async def _(self, alert: HtNewLowTradingViewAlert, alert_type):
        #print('HtNewLowTradingViewAlert')
        return await self.on_tradingview_alert(TradingViewAlert(**asdict(alert)), alert_type)

    @on_tradingview_alert.register
    async def _(self, alert: HtBullBosTradingViewAlert, alert_type):
        #print('HtBullBosTradingViewAlert')
        return await self.on_tradingview_alert(TradingViewAlert(**asdict(alert)), alert_type)

    @on_tradingview_alert.register
    async def _(self, alert: HtBullChochTradingViewAlert, alert_type):
        #print('HtBullChochTradingViewAlert')
        return await self.on_tradingview_alert(TradingViewAlert(**asdict(alert)), alert_type)

    @on_tradingview_alert.register
    async def _(self, alert: HtBearBosTradingViewAlert, alert_type):
        #print('HtBearBosTradingViewAlert')
        return await self.on_tradingview_alert(TradingViewAlert(**asdict(alert)), alert_type)

    @on_tradingview_alert.register
    async def _(self, alert: HtBearChochTradingViewAlert, alert_type):
        #print('HtBearChochTradingViewAlert')
        return await self.on_tradingview_alert(TradingViewAlert(**asdict(alert)), alert_type)

    @on_tradingview_alert.register
    async def _(self, alert: TradingViewAlert, alert_type):
        #print(datetime.utcfromtimestamp(msg.time))
        #print(datetime.fromtimestamp(msg.time, tz=timezone.utc))
        #print(datetime.fromtimestamp(msg.time))

        rval = []
        rval.extend([f'<b>{alert.tickerid:s} {to_timeframe(tv_timeframe(alert.period))}</b>'])
        rval.extend([f'{datetime.utcfromtimestamp(alert.time)}'])
        rval.extend([f'<code>'])
        rval.extend([f'         Trend: {alert.ht_trend}']          if alert.ht_trend is not None else [])
        rval.extend([f'High structure: {alert.ht_high_structure}'] if alert.ht_high_structure is not None else [])
        rval.extend([f' Low structure: {alert.ht_low_structure}']  if alert.ht_low_structure is not None else [])
        rval.extend([f'      Bull BOS: {alert.ht_bull_bos}']       if alert.ht_bull_bos is not None else [])
        rval.extend([f'    Bull CHoCH: {alert.ht_bull_choch}']     if alert.ht_bull_choch is not None else [])
        rval.extend([f'      Bear BOS: {alert.ht_bear_bos}']       if alert.ht_bear_bos is not None else [])
        rval.extend([f'    Bear CHoCH: {alert.ht_bear_choch}']     if alert.ht_bear_choch is not None else [])
        rval.extend([f'     Direction: {alert.ht_direction}']      if alert.ht_direction is not None else [])
        rval.extend([f'        Bottom: {alert.ht_bottom_val}']     if alert.ht_bottom_val is not None else [])
        rval.extend([f'           Top: {alert.ht_top_val}']        if alert.ht_top_val is not None else [])
        #rval.extend([f' HT Percentage: {alert.ht_percentage}']     if alert.ht_percentage is not None else [])
        #rval.extend([f'     HT Margin: {alert.ht_margin}']         if alert.ht_margin is not None else [])
        #rval.extend([f' LT Percentage: {alert.lt_percentage}']     if alert.lt_percentage is not None else [])
        #rval.extend([f'     LT Margin: {alert.lt_margin}']         if alert.lt_margin is not None else [])
        rval.extend([f'</code>'])

        print('\n'.join(rval))

        await self.mqtt.publish(f'inclination/telegram/message', json.dumps('\n'.join(rval)))

    async def on_startup(self, app):
        logger.debug('Startup')

    async def on_cleanup(self, app):
        logger.debug('Cleanup')

    async def on_conf_interval(self, payload, *, name):
        if payload == None:
            logger.debug(f'Removing tickerid mapping "{name}"')
            del self.tickerids[name]
        else:
            logger.debug(f'Mapping tickerid "{name}" to "{payload}"')
            self.tickerids[name] = payload

    async def on_connect(self, client, userdata, flags, rc):
        logger.debug('Connect')
        await self.mqtt.subscribe('inclination/config/mailgun/0/#')
        await self.mqtt.publish(f'inclination/telegram/message', '"<b>Mailgun</b> process restarted"')

    async def on_disconnect(self, client, userdata, rc):
        logger.debug(f'Disconnect {rc}')

    async def on_sigint(self, done):
        print('SIGINT')
        done.set_result(0)

    async def __call__(self, *, mqtt_host, mqtt_port, mqtt_user, mqtt_passwd):
        loop = asyncio.get_event_loop()
        done = loop.create_future()
        loop.add_signal_handler(signal.SIGINT, lambda: asyncio.ensure_future(partial(self.on_sigint)(done)))

        async def run_app():
            app = web.Application()
            app.on_startup.append(self.on_startup)
            app.on_cleanup.append(self.on_cleanup)
            app.add_routes(routes)
            app.main = self

            runner = web.AppRunner(app)
            await runner.setup()
            site = web.TCPSite(runner, '0.0.0.0', 8888)
            await site.start()

            await done

            await runner.cleanup()

        async def run_mqtt():
            class _:
                def __init__(self, handler, regex=None, do_qos=False, do_retain=False):
                    self._handler = handler
                    self._regex = re.compile(regex) if regex else None
                    self._do_qos = do_qos
                    self._do_retain = do_retain
                async def __call__(self, client, userdata, msg):
                    params = {}
                    if self._do_qos:
                        params['qos'] = msg.qos
                    if self._do_retain:
                        params['retain'] = msg.retain
                    instance = self._regex.match(msg.topic).groupdict() if self._regex else {'topic': msg.topic}
                    payload = json.loads(msg.payload) if msg.payload else None
                    await self._handler(payload, **params, **instance)

            self.mqtt = mqtt.Client()
            self.mqtt.username_pw_set(username=mqtt_user, password=mqtt_passwd)
            self.mqtt.on_connect = self.on_connect
            self.mqtt.on_disconnect = self.on_disconnect

            self.mqtt.message_callback_add(
                    'inclination/config/mailgun/0/tickerid/+/map',
                    _(self.on_conf_interval, r'inclination/config/mailgun/0/tickerid/(?P<name>[^/]+)/map'))

            loop = asyncio.get_running_loop()
            self.mqtt.loop = loop

            await self.mqtt.connect(host=mqtt_host, port=mqtt_port)

            await done

            await self.mqtt.disconnect()

        await asyncio.gather(
                run_app(),
                run_mqtt()
                )

        print('Done.')


def main():
    parser = ArgumentParser()
    parser.add_argument('-H', '--mqtt-host', default=os.environ.get('MQTT_HOST', 'localhost'))
    parser.add_argument('-p', '--mqtt-port', type=int, default=os.environ.get('MQTT_PORT', 1883))
    parser.add_argument('-u', '--mqtt-user', default=os.environ.get('MQTT_USER', None))
    parser.add_argument('-P', '--mqtt-passwd', default=os.environ.get('MQTT_PASSWD', None))
    args = parser.parse_args()

    x = Main()
    asyncio.run(x(**vars(args)))

